import React from 'react';
import {
  Calendar,
  Download,
  PhoneCall,
  Plus,
  Send,
  Stethoscope,
  TestTube2,
  UserCheck,
} from 'lucide-react';
import { OPDVisit } from '../../types';
import { exportToCSV } from '../../utils/exportCsv';

interface OPDTabProps {
  opdVisits: OPDVisit[];
  onOpenAddOPDModal: () => void;
  shopName: string;
  shopPhone: string;
}

export const OPDTab: React.FC<OPDTabProps> = ({
  opdVisits,
  onOpenAddOPDModal,
  shopName,
  shopPhone,
}) => {
  const handleDirectSMS = (o: OPDVisit) => {
    const msg = `Dear ${o.name}, your follow-up doctor appointment with ${o.doc} at ${shopName} is scheduled for: ${o.rvdate}. Contact: ${shopPhone}`;
    const smsUrl = `sms:${o.phone}?body=${encodeURIComponent(msg)}`;
    window.location.href = smsUrl;
  };

  const handleExportCSV = () => {
    exportToCSV(
      'opd_revisit_register',
      ['Patient Name', 'Phone', 'Age & Sex', 'Assigned Doctor', 'Visit Date', 'Next Re-visit Date', 'Blood / Lab Tests Advised', 'Status Alert'],
      opdVisits.map(o => [
        o.name,
        o.phone,
        o.ageSex,
        o.doc,
        o.vdate,
        o.rvdate,
        o.btest,
        o.reminder,
      ])
    );
  };

  return (
    <div className="space-y-6">
      <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl flex justify-between items-center flex-wrap gap-4 text-slate-100">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Stethoscope className="w-4 h-4" />
            </div>
            <span>OPD & Lab Clinical Re-visit Register</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Doctor consultation logs and automatic 3-4 days advance follow-up revisit reminders with direct SMS & Call triggers.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-2xl text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>

          <button
            id="btn-add-opd-patient"
            onClick={onOpenAddOPDModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add OPD Patient</span>
          </button>
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-xl overflow-hidden text-xs text-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white/10 border-b border-white/10 text-[11px] font-semibold text-slate-300 uppercase backdrop-blur-md">
              <tr>
                <th className="p-3.5">Patient Details</th>
                <th className="p-3.5">Doctor Assigned</th>
                <th className="p-3.5">Visit Date</th>
                <th className="p-3.5 text-indigo-300 font-bold">Next Re-Visit Date</th>
                <th className="p-3.5 text-rose-400 font-bold">Tests Advised</th>
                <th className="p-3.5">Alert Status</th>
                <th className="p-3.5 text-center">SMS & Phone Call</th>
              </tr>
            </thead>
            <tbody id="opd-table-rows" className="divide-y divide-white/5 text-slate-200">
              {opdVisits.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No OPD consultation visits recorded.
                  </td>
                </tr>
              ) : (
                opdVisits.map(o => (
                  <tr key={o.id} className="hover:bg-white/5 transition">
                    <td className="p-3.5">
                      <span className="font-bold text-white block">{o.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {o.ageSex} • {o.phone}
                      </span>
                    </td>
                    <td className="p-3.5 font-medium text-slate-200 flex items-center gap-1.5 mt-1">
                      <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{o.doc}</span>
                    </td>
                    <td className="p-3.5 font-mono text-slate-400">{o.vdate}</td>
                    <td className="p-3.5 font-bold text-indigo-300 font-mono">
                      {o.rvdate || 'N/A'}
                    </td>
                    <td className="p-3.5 text-rose-300 font-semibold flex items-center gap-1 mt-1">
                      <TestTube2 className="w-3.5 h-3.5 text-rose-400" />
                      <span>{o.btest}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full text-[10px] font-bold">
                        3-4 Days Advance
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleDirectSMS(o)}
                          className="px-3 py-1.5 bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 rounded-xl text-xs font-semibold flex items-center gap-1 transition backdrop-blur-sm cursor-pointer"
                        >
                          <Send className="w-3 h-3" /> Auto SMS
                        </button>
                        <a
                          href={`tel:${o.phone}`}
                          className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center gap-1 transition backdrop-blur-sm"
                        >
                          <PhoneCall className="w-3 h-3" /> Call
                        </a>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
