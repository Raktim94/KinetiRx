import { MedicineGroup } from '../types';

export const initialMedicineGroups: MedicineGroup[] = [];

const LOCAL_STORAGE_KEY = 'pcp_direct_medicine_groups_v2';

export function loadMedicineGroups(): MedicineGroup[] {
  try {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load medicine groups from localStorage:', err);
  }
  return [];
}

export function saveMedicineGroups(groups: MedicineGroup[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(groups));
  } catch (err) {
    console.error('Failed to save medicine groups to localStorage:', err);
  }
}

// Backward compatibility exports
export const initialDoctorGroups = initialMedicineGroups;
export const loadDoctorMedicineGroups = loadMedicineGroups;
export const saveDoctorMedicineGroups = saveMedicineGroups;
