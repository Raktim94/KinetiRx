import React, { useState } from 'react';
import {
  AlertTriangle,
  Boxes,
  Check,
  CheckCircle2,
  ChevronRight,
  Filter,
  MessageCircle,
  Package,
  Pill,
  Phone,
  Plus,
  Search,
  ShoppingCart,
  Sparkles,
  Truck,
  X,
} from 'lucide-react';
import { Distributor, Medicine, NeededMedItem, NeededMedOrder } from '../../types';
import { formatWhatsAppPhone } from '../../utils/exportCsv';

interface LowStockReorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  medicines: Medicine[];
  distributors: Distributor[];
  setDistributors?: React.Dispatch<React.SetStateAction<Distributor[]>>;
  onSaveNeedMed?: (order: NeededMedOrder) => void;
  onBulkCreateSpecialOrders?: (orders: NeededMedOrder[]) => void;
  shopName?: string;
  shopPhone?: string;
}

interface ReorderRow {
  medicine: Medicine;
  selected: boolean;
  orderQty: number;
  assignedDistributor: string;
}

export const LowStockReorderModal: React.FC<LowStockReorderModalProps> = ({
  isOpen,
  onClose,
  medicines,
  distributors,
  setDistributors,
  onSaveNeedMed,
  onBulkCreateSpecialOrders,
  shopName = 'MEDIX SMART PHARMACY',
  shopPhone = '9876543210',
}) => {
  const [search, setSearch] = useState('');
  const [stockThreshold, setStockThreshold] = useState<number>(10);
  const [selectedDistributorFilter, setSelectedDistributorFilter] = useState<string>('all');
  const [batchAssignedDistributor, setBatchAssignedDistributor] = useState<string>(
    distributors.length > 0 ? distributors[0].name : ''
  );

  // Filter low stock medicines
  const lowStockMeds = medicines.filter(m => {
    if (m.isLabTest || m.itemType === 'lab_test') return false;
    return (m.stock || 0) <= stockThreshold;
  });

  // Reorder state table
  const [reorderRows, setReorderRows] = useState<ReorderRow[]>(() => {
    return lowStockMeds.map(m => ({
      medicine: m,
      selected: true,
      orderQty: Math.max(10, (15 - (m.stock || 0))),
      assignedDistributor: m.dist || (distributors.length > 0 ? distributors[0].name : 'General Supplier'),
    }));
  });

  // Keep in sync when lowStockMeds change or modal reopens
  React.useEffect(() => {
    if (isOpen) {
      setReorderRows(
        lowStockMeds.map(m => ({
          medicine: m,
          selected: true,
          orderQty: Math.max(10, (15 - (m.stock || 0))),
          assignedDistributor: m.dist || (distributors.length > 0 ? distributors[0].name : 'General Supplier'),
        }))
      );
    }
  }, [isOpen, medicines, stockThreshold]);

  if (!isOpen) return null;

  const handleToggleSelectAll = (checked: boolean) => {
    setReorderRows(prev => prev.map(r => ({ ...r, selected: checked })));
  };

  const handleToggleRow = (medId: string) => {
    setReorderRows(prev =>
      prev.map(r => (r.medicine.id === medId ? { ...r, selected: !r.selected } : r))
    );
  };

  const handleUpdateRowQty = (medId: string, qty: number) => {
    setReorderRows(prev =>
      prev.map(r => (r.medicine.id === medId ? { ...r, orderQty: Math.max(1, qty) } : r))
    );
  };

  const handleUpdateRowDistributor = (medId: string, dist: string) => {
    setReorderRows(prev =>
      prev.map(r => (r.medicine.id === medId ? { ...r, assignedDistributor: dist } : r))
    );
  };

  const handleApplyBatchDistributor = () => {
    if (!batchAssignedDistributor) return;
    setReorderRows(prev =>
      prev.map(r => (r.selected ? { ...r, assignedDistributor: batchAssignedDistributor } : r))
    );
  };

  const getDistributorInfo = (distName: string): Distributor | undefined => {
    return distributors.find(
      d =>
        d.name.toLowerCase() === distName.toLowerCase() ||
        distName.toLowerCase().includes(d.name.toLowerCase()) ||
        d.name.toLowerCase().includes(distName.toLowerCase())
    );
  };

  const selectedRows = reorderRows.filter(r => r.selected);

  // Group selected items by assigned distributor
  const groupedByDistributor = selectedRows.reduce((acc, row) => {
    const dName = row.assignedDistributor || 'General Supplier';
    if (!acc[dName]) acc[dName] = [];
    acc[dName].push(row);
    return acc;
  }, {} as Record<string, ReorderRow[]>);

  const distributorGroups = Object.keys(groupedByDistributor);

  // Send WhatsApp Purchase Order to a specific distributor group
  const handleSendWhatsAppOrder = (distName: string) => {
    const rows = groupedByDistributor[distName] || [];
    if (rows.length === 0) return;

    const distInfo = getDistributorInfo(distName);
    const distPhone = distInfo?.phone && distInfo.phone !== 'N/A' ? distInfo.phone : '';
    const formattedPhone = formatWhatsAppPhone(distPhone);

    const itemsText = rows
      .map(
        (r, idx) =>
          `${idx + 1}. *${r.medicine.name}* (Current Stock: ${r.medicine.stock} | *Order Qty: ${r.orderQty} Strips/Packs*)${
            r.medicine.pack ? ` [Pack: ${r.medicine.pack}]` : ''
          }${r.medicine.company ? ` - ${r.medicine.company}` : ''}`
      )
      .join('\n');

    const msg =
      `*📦 URGENT LOW-STOCK PURCHASE REQUISITION / ওষুধের স্টক অর্ডার*\n\n` +
      `🏢 *To Distributor:* ${distName}\n` +
      `📅 *Date:* ${new Date().toLocaleDateString('en-GB')}\n` +
      `🔢 *Total Items Requested:* ${rows.length} SKU(s)\n\n` +
      `*ORDER ITEMS LIST:*\n` +
      `${itemsText}\n\n` +
      `🏥 *Order Placed By:* ${shopName}\n` +
      `📞 *Shop Helpline:* ${shopPhone}\n` +
      `📍 *Status:* Ready for fast delivery & billing\n\n` +
      `_Please confirm receipt and dispatch schedule at the earliest. Thank you!_`;

    if (formattedPhone && formattedPhone.length >= 10) {
      const url = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');
    } else {
      const inputPhone = prompt(
        `Distributor "${distName}" mobile number not found in registry.\nEnter 10-digit mobile number to send WhatsApp purchase order:`,
        ''
      );
      if (inputPhone) {
        const cleaned = formatWhatsAppPhone(inputPhone);
        if (cleaned) {
          if (setDistributors && distInfo) {
            setDistributors(prev => {
              const updated = prev.map(d =>
                d.id === distInfo.id ? { ...d, phone: inputPhone.trim() } : d
              );
              try {
                localStorage.setItem('pcp_distributors_v2', JSON.stringify(updated));
              } catch (err) {}
              return updated;
            });
          }

          const url = `https://api.whatsapp.com/send?phone=${cleaned}&text=${encodeURIComponent(msg)}`;
          window.open(url, '_blank');
        }
      }
    }
  };

  // Convert selected low stock items into Special Need Orders in the system
  const handleSaveToSpecialNeedOrders = () => {
    if (selectedRows.length === 0) {
      alert('Please select at least one low-stock medicine to order');
      return;
    }

    const createdOrders: NeededMedOrder[] = [];

    // Create consolidated orders per distributor
    distributorGroups.forEach(dName => {
      const items = groupedByDistributor[dName];
      const multiItems: NeededMedItem[] = items.map(r => ({
        id: r.medicine.id,
        med: r.medicine.name,
        qty: r.orderQty,
        pack: r.medicine.pack,
        salt: r.medicine.salt,
        mrp: r.medicine.mrp,
        stock: r.medicine.stock,
      }));

      const primaryMed = items[0].medicine.name + (items.length > 1 ? ` (+${items.length - 1} more items)` : '');
      const totalUnits = items.reduce((sum, i) => sum + i.orderQty, 0);

      const newOrder: NeededMedOrder = {
        id: 'LOW-STOCK-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        med: primaryMed,
        name: 'Inventory Stock Replenishment (Low Stock Auto-Order)',
        phone: shopPhone || 'N/A',
        dist: dName,
        time: 'Urgent Dispatch (জরুরি স্টক)',
        qty: totalUnits,
        items: multiItems,
        notes: `Low Stock replenishment order containing ${items.length} medicines`,
        status: 'Distributor Ordered',
      };

      createdOrders.push(newOrder);
    });

    if (onBulkCreateSpecialOrders) {
      onBulkCreateSpecialOrders(createdOrders);
    } else if (onSaveNeedMed) {
      createdOrders.forEach(o => onSaveNeedMed(o));
    }

    alert(`Successfully registered ${createdOrders.length} supplier orders (${selectedRows.length} total medicine SKUs) under Special Need Medicine Orders!`);
    onClose();
  };

  const filteredDisplayRows = reorderRows.filter(r => {
    const q = search.toLowerCase();
    const matchesSearch =
      !search ||
      r.medicine.name.toLowerCase().includes(q) ||
      (r.medicine.company && r.medicine.company.toLowerCase().includes(q)) ||
      (r.medicine.dist && r.medicine.dist.toLowerCase().includes(q)) ||
      (r.medicine.salt && r.medicine.salt.toLowerCase().includes(q));

    const matchesDist =
      selectedDistributorFilter === 'all' || r.assignedDistributor === selectedDistributorFilter;

    return matchesSearch && matchesDist;
  });

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-5xl w-full p-5 sm:p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95 max-h-[94vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  Low Stock Medicines & Direct Supplier Re-order
                </h3>
                <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2.5 py-0.5 rounded-full font-mono text-[11px] font-bold">
                  {lowStockMeds.length} Low Stock SKUs
                </span>
              </div>
              <p className="text-xs text-slate-400">
                View low-stock medicines, customize reorder quantities, assign registered distributors, and dispatch purchase orders via WhatsApp with 1-click.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter and threshold bar */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 bg-white/5 p-3 rounded-2xl border border-white/10">
          {/* Threshold selector */}
          <div>
            <label className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">
              Low Stock Level (&le; Units)
            </label>
            <div className="flex items-center gap-1.5">
              {[5, 10, 20, 50].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setStockThreshold(val)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                    stockThreshold === val
                      ? 'bg-rose-600 text-white shadow'
                      : 'bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  &le;{val}
                </button>
              ))}
            </div>
          </div>

          {/* Search bar */}
          <div className="sm:col-span-2">
            <label className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">
              Search Medicine / Company
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search low stock medicines by name, salt, or brand..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-950/80 border border-white/15 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-rose-400 text-xs"
              />
            </div>
          </div>

          {/* Batch Distributor assignment */}
          <div>
            <label className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1">
              Assign Distributor to Selected
            </label>
            <div className="flex gap-1">
              <select
                value={batchAssignedDistributor}
                onChange={e => setBatchAssignedDistributor(e.target.value)}
                className="flex-1 p-1.5 bg-slate-950/80 border border-white/15 rounded-xl text-white font-bold text-xs outline-none"
              >
                {distributors.map(d => (
                  <option key={d.id} value={d.name}>
                    {d.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleApplyBatchDistributor}
                title="Apply to all selected"
                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs cursor-pointer"
              >
                Apply
              </button>
            </div>
          </div>
        </div>

        {/* Low stock medicines table */}
        <div className="flex-1 overflow-y-auto min-h-[220px] max-h-[360px] border border-white/10 rounded-2xl bg-slate-950/60">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-white/10 border-b border-white/10 text-[11px] font-bold text-slate-300 uppercase sticky top-0 backdrop-blur-md z-10">
              <tr>
                <th className="p-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={
                      filteredDisplayRows.length > 0 &&
                      filteredDisplayRows.every(r => r.selected)
                    }
                    onChange={e => handleToggleSelectAll(e.target.checked)}
                    className="rounded border-white/20 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                  />
                </th>
                <th className="p-3">Medicine & Salt Info</th>
                <th className="p-3 text-center">Current Stock</th>
                <th className="p-3 text-center">Re-order Qty</th>
                <th className="p-3">Assigned Distributor / Supplier</th>
                <th className="p-3 text-right">Unit MRP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredDisplayRows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                    <p className="font-semibold text-white">No low-stock medicines found!</p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      All physical stock items have more than {stockThreshold} units in inventory.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredDisplayRows.map(row => {
                  const m = row.medicine;
                  const distInfo = getDistributorInfo(row.assignedDistributor);

                  return (
                    <tr
                      key={m.id}
                      className={`hover:bg-white/5 transition ${
                        row.selected ? 'bg-indigo-950/20' : 'opacity-60'
                      }`}
                    >
                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={row.selected}
                          onChange={() => handleToggleRow(m.id)}
                          className="rounded border-white/20 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                        />
                      </td>

                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Pill className="w-4 h-4 text-indigo-400 shrink-0" />
                          <div>
                            <span className="font-bold text-white block">{m.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {m.company ? `${m.company} • ` : ''}
                              {m.pack ? `Pack: ${m.pack} • ` : ''}
                              {m.salt || 'General Formulation'}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full font-mono text-[11px] font-bold border ${
                            m.stock === 0
                              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          }`}
                        >
                          {m.stock} Units
                        </span>
                      </td>

                      <td className="p-3 text-center">
                        <div className="inline-flex items-center gap-1.5 bg-slate-900 border border-white/15 px-2 py-1 rounded-xl">
                          <input
                            type="number"
                            min="1"
                            value={row.orderQty}
                            onChange={e =>
                              handleUpdateRowQty(m.id, parseInt(e.target.value, 10) || 1)
                            }
                            className="w-14 bg-transparent font-bold font-mono text-center text-white outline-none"
                          />
                          <span className="text-[10px] text-slate-400">Pks</span>
                        </div>
                      </td>

                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <Truck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          <select
                            value={row.assignedDistributor}
                            onChange={e => handleUpdateRowDistributor(m.id, e.target.value)}
                            className="bg-slate-900 border border-white/15 text-white font-semibold rounded-lg px-2 py-1 text-xs outline-none focus:border-indigo-400 max-w-[200px]"
                          >
                            {distributors.map(d => (
                              <option key={d.id} value={d.name}>
                                {d.name} {d.phone && d.phone !== 'N/A' ? `(Ph: ${d.phone})` : ''}
                              </option>
                            ))}
                            {!distributors.some(d => d.name === row.assignedDistributor) && (
                              <option value={row.assignedDistributor}>
                                {row.assignedDistributor}
                              </option>
                            )}
                          </select>
                        </div>
                        {distInfo?.phone && distInfo.phone !== 'N/A' && (
                          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-0.5 ml-5">
                            <Phone className="w-2.5 h-2.5" />
                            <span>{distInfo.phone}</span>
                          </span>
                        )}
                      </td>

                      <td className="p-3 text-right font-mono font-bold text-white">
                        ₹ {m.mrp.toFixed(2)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Distributor WhatsApp Dispatch Summary Cards */}
        {distributorGroups.length > 0 && (
          <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-indigo-200 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-indigo-400" />
                <span>Supplier Direct Requisitions ({distributorGroups.length} Distributors Grouped):</span>
              </span>
              <span className="text-[11px] text-slate-300 font-mono">
                <b>{selectedRows.length}</b> total medicine items selected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {distributorGroups.map(dName => {
                const groupItems = groupedByDistributor[dName];
                const distInfo = getDistributorInfo(dName);
                const hasPhone = distInfo?.phone && distInfo.phone !== 'N/A';

                return (
                  <div
                    key={dName}
                    className="p-2.5 rounded-xl bg-slate-900 border border-white/10 flex justify-between items-center text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block truncate max-w-[180px]">{dName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {groupItems.length} items &bull; {groupItems.reduce((s, i) => s + i.orderQty, 0)} units
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSendWhatsAppOrder(dName)}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2.5 py-1.5 rounded-xl text-[11px] flex items-center gap-1 transition shadow cursor-pointer shrink-0 ml-2"
                      title="Send WhatsApp Purchase Order"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Order WhatsApp</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex justify-between items-center pt-2 border-t border-white/10 flex-wrap gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition cursor-pointer"
          >
            Close
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSaveToSpecialNeedOrders}
              disabled={selectedRows.length === 0}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl shadow-lg shadow-indigo-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Save {selectedRows.length} Items to Special Need Orders</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
