import React, { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Eye, EyeOff, KeyRound, Lock, Plus, ShieldCheck, Users, X } from 'lucide-react';
import { Employee, TabType } from '../../types';

const allAvailableModules: { id: TabType; label: string }[] = [
  { id: 'dashboard', label: 'Overview Analytics (ড্যাশবোর্ড)' },
  { id: 'pos', label: 'POS Billing Counter (বিলিং)' },
  { id: 'daily-sales', label: 'Daily Sales Register (দৈনিক খাতা)' },
  { id: 'due-khata', label: 'Due Khata (বাকির খাতা)' },
  { id: 'medicine-orders', label: 'Special Medicine Orders (ওষুধ অর্ডার)' },
  { id: 'inventory', label: 'Medicine Stock ERP (স্টক)' },
  { id: 'inward-ocr', label: 'OCR Invoice Auto-Scan (চালান স্ক্যান)' },
  { id: 'opd', label: 'OPD & Patient Re-visits (ওপিডি)' },
  { id: 'patients', label: 'Patient Master Database (রোগী ডাটা)' },
  { id: 'expenses', label: 'Daily Expenditures (দৈনিক খরচ)' },
  { id: 'business-dev', label: 'Doctor Campaign & Tasks (প্রচার)' },
  { id: 'employee-mgmt', label: 'Employee Access Control (কর্মচারী)' },
  { id: 'invoice-settings', label: 'Invoice & WhatsApp (বিল সেটিংস)' },
];

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveEmployee: (emp: Employee) => void;
}

export const AddEmployeeModal: React.FC<AddEmployeeModalProps> = ({
  isOpen,
  onClose,
  onSaveEmployee,
}) => {
  const [name, setName] = useState('');
  const [desig, setDesig] = useState('Pharmacist / Staff');
  const [pass, setPass] = useState('1234');
  const [selectedPermissions, setSelectedPermissions] = useState<TabType[]>([
    'dashboard',
    'pos',
    'daily-sales',
    'inventory',
  ]);

  if (!isOpen) return null;

  const togglePermission = (tab: TabType) => {
    if (selectedPermissions.includes(tab)) {
      setSelectedPermissions(selectedPermissions.filter(t => t !== tab));
    } else {
      setSelectedPermissions([...selectedPermissions, tab]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter employee name');
      return;
    }

    const newEmp: Employee = {
      id: 'EMP-' + Date.now(),
      name: name.trim(),
      desig: desig.trim(),
      pass: pass.trim() || '1234',
      permissions: selectedPermissions,
    };

    onSaveEmployee(newEmp);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/90 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-pink-400">
              <Users className="w-4 h-4" />
            </div>
            <span>Add New Staff / Employee (নতুন কর্মচারী)</span>
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="font-medium text-slate-300 block mb-1">Employee Full Name</label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Rahul Sen"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10 font-medium"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 block mb-1">Designation / Role</label>
              <input
                type="text"
                value={desig}
                onChange={e => setDesig(e.target.value)}
                placeholder="e.g. Dispensing Pharmacist"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10"
              />
            </div>
            <div>
              <label className="font-medium text-slate-300 block mb-1">Login PIN / Password</label>
              <input
                type="text"
                value={pass}
                onChange={e => setPass(e.target.value)}
                placeholder="4-digit PIN"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10"
                required
              />
            </div>
          </div>

          <div>
            <label className="font-medium text-slate-300 block mb-2">
              Allowed Modules & Tabs (অনুমোদিত মেনুসমূহ):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto border border-white/10 p-3 rounded-2xl bg-white/5 backdrop-blur-md">
              {allAvailableModules.map(m => (
                <label
                  key={m.id}
                  className="flex items-center gap-2 p-2 hover:bg-white/5 rounded-xl cursor-pointer text-[11px] transition text-slate-200"
                >
                  <input
                    type="checkbox"
                    checked={selectedPermissions.includes(m.id)}
                    onChange={() => togglePermission(m.id)}
                    className="rounded text-pink-500 focus:ring-pink-500"
                  />
                  <span className="font-medium text-slate-200">{m.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-2xl font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-pink-600 hover:bg-pink-500 text-white font-bold rounded-2xl shadow-lg shadow-pink-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save Employee</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface EditEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  emp: Employee | null;
  onUpdateEmployee: (emp: Employee) => void;
}

export const EditEmployeeModal: React.FC<EditEmployeeModalProps> = ({
  isOpen,
  onClose,
  emp,
  onUpdateEmployee,
}) => {
  const [desig, setDesig] = useState('');
  const [pass, setPass] = useState('');
  const [permissions, setPermissions] = useState<TabType[]>([]);

  React.useEffect(() => {
    if (emp) {
      setDesig(emp.desig);
      setPass(emp.pass);
      setPermissions(emp.permissions);
    }
  }, [emp, isOpen]);

  if (!isOpen || !emp) return null;

  const togglePermission = (tab: TabType) => {
    if (permissions.includes(tab)) {
      setPermissions(permissions.filter(t => t !== tab));
    } else {
      setPermissions([...permissions, tab]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateEmployee({
      ...emp,
      desig,
      pass,
      permissions,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/90 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span>Edit Permissions for {emp.name}</span>
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 block mb-1">Designation</label>
              <input
                type="text"
                value={desig}
                onChange={e => setDesig(e.target.value)}
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10"
              />
            </div>
            <div>
              <label className="font-medium text-slate-300 block mb-1">PIN Password</label>
              <input
                type="text"
                value={pass}
                onChange={e => setPass(e.target.value)}
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10"
              />
            </div>
          </div>

          <div>
            <label className="font-medium text-slate-300 block mb-2">Permitted Modules:</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto border border-white/10 p-3 rounded-2xl bg-white/5 backdrop-blur-md">
              {allAvailableModules.map(m => (
                <label
                  key={m.id}
                  className="flex items-center gap-2 p-2 hover:bg-white/5 rounded-xl cursor-pointer text-[11px] transition text-slate-200"
                >
                  <input
                    type="checkbox"
                    checked={permissions.includes(m.id)}
                    onChange={() => togglePermission(m.id)}
                    className="rounded text-sky-500 focus:ring-sky-500"
                  />
                  <span className="font-medium text-slate-200">{m.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-2xl font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-2xl shadow-lg shadow-sky-950/40 transition cursor-pointer"
            >
              Update Permissions
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface ChangeAdminPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPass: string;
  onSaveNewPass: (newPass: string) => void;
}

export const ChangeAdminPassModal: React.FC<ChangeAdminPassModalProps> = ({
  isOpen,
  onClose,
  currentPass,
  onSaveNewPass,
}) => {
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setOldPass('');
      setNewPass('');
      setConfirmPass('');
      setError(null);
      setSuccess(null);
      setShowOld(false);
      setShowNew(false);
      setShowConfirm(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (oldPass.trim() !== currentPass.trim()) {
      setError('Current admin password does not match. Please verify your existing password.');
      return;
    }
    if (newPass.trim().length < 4) {
      setError('New password must be at least 4 characters long.');
      return;
    }
    if (newPass.trim() !== confirmPass.trim()) {
      setError('New password confirmation does not match.');
      return;
    }

    const cleanNewPass = newPass.trim();
    onSaveNewPass(cleanNewPass);
    setSuccess('Admin master password updated and saved automatically! The new password will be required next time.');

    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-sm w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <span>Change Admin Master Password</span>
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Current Password */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Current Admin Password</label>
            <div className="relative">
              <input
                type={showOld ? 'text' : 'password'}
                value={oldPass}
                onChange={e => {
                  setOldPass(e.target.value);
                  setError(null);
                }}
                placeholder="Enter current password"
                className="w-full pl-3 pr-10 py-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10 text-xs"
                required
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowOld(!showOld)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                title={showOld ? 'Hide password' : 'Show password'}
              >
                {showOld ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* New Password */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1">New Password (min. 4 characters)</label>
            <div className="relative">
              <input
                type={showNew ? 'text' : 'password'}
                value={newPass}
                onChange={e => {
                  setNewPass(e.target.value);
                  setError(null);
                }}
                placeholder="Enter new password"
                className="w-full pl-3 pr-10 py-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10 text-xs"
                required
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                title={showNew ? 'Hide password' : 'Show password'}
              >
                {showNew ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Confirm New Password */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Confirm New Password</label>
            <div className="relative">
              <input
                type={showConfirm ? 'text' : 'password'}
                value={confirmPass}
                onChange={e => {
                  setConfirmPass(e.target.value);
                  setError(null);
                }}
                placeholder="Re-enter new password"
                className="w-full pl-3 pr-10 py-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10 text-xs"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                title={showConfirm ? 'Hide password' : 'Show password'}
              >
                {showConfirm ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Error message */}
          {error && (
            <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Success message */}
          {success && (
            <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <div className="flex justify-end gap-2.5 pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-950/40 transition cursor-pointer flex items-center gap-1.5"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Save & Update</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
