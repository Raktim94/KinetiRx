import React, { useState } from 'react';
import {
  Header,
} from './components/Header';
import {
  Sidebar,
} from './components/Sidebar';
import {
  AddExpenseModal,
} from './components/modals/AddExpenseModal';
import {
  AddLabStockModal,
} from './components/modals/AddLabStockModal';
import {
  AddNeedMedModal,
} from './components/modals/AddNeedMedModal';
import {
  AddOPDModal,
} from './components/modals/AddOPDModal';
import {
  AddStockModal,
} from './components/modals/AddStockModal';
import {
  AIFinderModal,
} from './components/modals/AIFinderModal';
import {
  DistributorModal,
} from './components/modals/DistributorModal';
import {
  AddEmployeeModal,
  ChangeAdminPassModal,
  EditEmployeeModal,
} from './components/modals/EmployeeModals';
import {
  InvoicePrintModal,
} from './components/modals/InvoicePrintModal';
import {
  LoginModal,
} from './components/modals/LoginModal';
import {
  MarketingModal,
  WorksheetModal,
} from './components/modals/MarketingWorksheetModals';
import {
  ModalType,
  UniversalDetailsModal,
} from './components/modals/UniversalDetailsModal';
import {
  BusinessDevTab,
} from './components/tabs/BusinessDevTab';
import {
  DailySalesTab,
} from './components/tabs/DailySalesTab';
import {
  DashboardTab,
} from './components/tabs/DashboardTab';
import {
  DueKhataTab,
} from './components/tabs/DueKhataTab';
import {
  EmployeeMgmtTab,
} from './components/tabs/EmployeeMgmtTab';
import {
  ExpensesTab,
} from './components/tabs/ExpensesTab';
import {
  InventoryTab,
} from './components/tabs/InventoryTab';
import {
  InvoiceSettingsTab,
} from './components/tabs/InvoiceSettingsTab';
import {
  SystemResetTab,
} from './components/tabs/SystemResetTab';
import {
  InwardOCRTab,
} from './components/tabs/InwardOCRTab';
import {
  MedicineOrdersTab,
} from './components/tabs/MedicineOrdersTab';
import {
  OPDTab,
} from './components/tabs/OPDTab';
import {
  PatientsTab,
} from './components/tabs/PatientsTab';
import {
  POSTab,
} from './components/tabs/POSTab';
import { getTodayISODate } from './utils/dateUtils';
import {
  initialDailyRegister,
  initialDistributors,
  initialEmployees,
  initialExpenses,
  initialInvoiceConfig,
  initialMarketingCampaigns,
  initialMedicines,
  initialNeededMeds,
  initialOPDVisits,
  initialPatients,
  initialPatientsDue,
  initialSalesHistory,
  initialWorksheetTasks,
} from './data/initialData';
import {
  CartItem,
  DailyRegister,
  Distributor,
  Employee,
  ExpenseRecord,
  InvoiceConfig,
  InvoicePrintData,
  MarketingCampaign,
  Medicine,
  NeededMedOrder,
  OPDVisit,
  OrganizationOnboardingData,
  PatientDue,
  PatientRecord,
  SalesRecord,
  SystemBackupSnapshot,
  TabType,
  WorksheetTask,
} from './types';

export function App() {
  // Current active navigation tab
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');

  // User and Auth State
  const [currentUser, setCurrentUser] = useState<{
    id: string;
    name: string;
    role: 'admin' | string;
    permissions: TabType[];
  }>({
    id: 'admin',
    name: 'Admin (Director)',
    role: 'admin',
    permissions: [
      'dashboard',
      'pos',
      'daily-sales',
      'due-khata',
      'medicine-orders',
      'inventory',
      'inward-ocr',
      'opd',
      'patients',
      'expenses',
      'business-dev',
      'employee-mgmt',
      'invoice-settings',
    ],
  });
  const [adminPass, setAdminPass] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('pcp_admin_pass');
      if (saved && saved.trim()) {
        return saved.trim();
      }
    } catch (e) {
      console.error('Error loading admin password from storage', e);
    }
    return '1234';
  });

  // Automatically synchronize admin password to localStorage
  React.useEffect(() => {
    try {
      if (adminPass) {
        localStorage.setItem('pcp_admin_pass', adminPass.trim());
      }
    } catch (e) {
      console.error('Failed to save admin password to storage', e);
    }
  }, [adminPass]);

  // Core Data Stores with persistent localStorage synchronization
  const [medicines, setMedicines] = useState<Medicine[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_medicines_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialMedicines;
  });

  const [patientsDue, setPatientsDue] = useState<PatientDue[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_patients_due_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialPatientsDue;
  });

  const [salesHistory, setSalesHistory] = useState<SalesRecord[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_sales_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialSalesHistory;
  });

  const [dailyRegister, setDailyRegister] = useState<DailyRegister>(() => {
    try {
      const saved = localStorage.getItem('pcp_register_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialDailyRegister;
  });

  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_expenses_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialExpenses;
  });

  const [neededMeds, setNeededMeds] = useState<NeededMedOrder[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_needed_meds_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialNeededMeds;
  });

  const [opdVisits, setOpdVisits] = useState<OPDVisit[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_opd_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialOPDVisits;
  });

  const [patients, setPatients] = useState<PatientRecord[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_patients_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialPatients;
  });

  const [distributors, setDistributors] = useState<Distributor[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_distributors_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialDistributors;
  });

  const [marketingCampaigns, setMarketingCampaigns] = useState<MarketingCampaign[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_campaigns_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialMarketingCampaigns;
  });

  const [worksheetTasks, setWorksheetTasks] = useState<WorksheetTask[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_worksheet_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialWorksheetTasks;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_employees_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialEmployees;
  });

  const [invoiceConfig, setInvoiceConfig] = useState<InvoiceConfig>(() => {
    try {
      const saved = localStorage.getItem('pcp_invoice_config_v2');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return initialInvoiceConfig;
  });

  // Multi-Device Server Synchronization Refs
  const lastKnownServerVersion = React.useRef<number>(0);
  const isSyncingFromServer = React.useRef<boolean>(false);

  // Apply state received from server
  const applyServerState = (s: any, version: number) => {
    isSyncingFromServer.current = true;
    lastKnownServerVersion.current = version;
    if (Array.isArray(s.medicines)) setMedicines(s.medicines);
    if (Array.isArray(s.distributors)) setDistributors(s.distributors);
    if (Array.isArray(s.salesHistory)) setSalesHistory(s.salesHistory);
    if (s.dailyRegister) setDailyRegister(s.dailyRegister);
    if (Array.isArray(s.expenses)) setExpenses(s.expenses);
    if (Array.isArray(s.patients)) setPatients(s.patients);
    if (Array.isArray(s.patientsDue)) setPatientsDue(s.patientsDue);
    if (Array.isArray(s.neededMeds)) setNeededMeds(s.neededMeds);
    if (Array.isArray(s.opdVisits)) setOpdVisits(s.opdVisits);
    if (Array.isArray(s.marketingCampaigns)) setMarketingCampaigns(s.marketingCampaigns);
    if (Array.isArray(s.worksheetTasks)) setWorksheetTasks(s.worksheetTasks);
    if (Array.isArray(s.employees)) setEmployees(s.employees);
    if (s.invoiceConfig) setInvoiceConfig(s.invoiceConfig);
    if (s.adminPass) setAdminPass(s.adminPass);

    setTimeout(() => {
      isSyncingFromServer.current = false;
    }, 150);
  };

  // Initial Server State Fetch on Mount & Periodic Multi-Device Polling
  React.useEffect(() => {
    let isMounted = true;

    async function syncFromServer() {
      try {
        const res = await fetch('/api/state/sync');
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.state) {
            if (json.version > lastKnownServerVersion.current || lastKnownServerVersion.current === 0) {
              if (isMounted) {
                applyServerState(json.state, json.version);
              }
            }
          }
        }
      } catch (err) {
        // Silently continue if network briefly drops
      }
    }

    syncFromServer();
    const interval = setInterval(syncFromServer, 3000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Persistent storage and Real-Time Multi-Device push
  React.useEffect(() => {
    // Save to local cache
    try {
      localStorage.setItem('pcp_medicines_v2', JSON.stringify(medicines));
      localStorage.setItem('pcp_distributors_v2', JSON.stringify(distributors));
      localStorage.setItem('pcp_sales_v2', JSON.stringify(salesHistory));
      localStorage.setItem('pcp_register_v2', JSON.stringify(dailyRegister));
      localStorage.setItem('pcp_expenses_v2', JSON.stringify(expenses));
      localStorage.setItem('pcp_patients_v2', JSON.stringify(patients));
      localStorage.setItem('pcp_patients_due_v2', JSON.stringify(patientsDue));
      localStorage.setItem('pcp_needed_meds_v2', JSON.stringify(neededMeds));
      localStorage.setItem('pcp_opd_v2', JSON.stringify(opdVisits));
      localStorage.setItem('pcp_campaigns_v2', JSON.stringify(marketingCampaigns));
      localStorage.setItem('pcp_worksheet_v2', JSON.stringify(worksheetTasks));
      localStorage.setItem('pcp_employees_v2', JSON.stringify(employees));
      localStorage.setItem('pcp_invoice_config_v2', JSON.stringify(invoiceConfig));
    } catch (e) {}

    // If incoming update from server is actively applying, do not push echo back
    if (isSyncingFromServer.current) return;

    const timeout = setTimeout(async () => {
      try {
        const payload = {
          medicines,
          distributors,
          salesHistory,
          dailyRegister,
          expenses,
          patients,
          patientsDue,
          neededMeds,
          opdVisits,
          marketingCampaigns,
          worksheetTasks,
          employees,
          invoiceConfig,
          adminPass,
        };

        const res = await fetch('/api/state/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ state: payload, clientVersion: lastKnownServerVersion.current }),
        });

        if (res.ok) {
          const json = await res.json();
          if (json.version) {
            lastKnownServerVersion.current = json.version;
          }
        }
      } catch (err) {
        console.error('State push to server failed:', err);
      }
    }, 400);

    return () => clearTimeout(timeout);
  }, [
    medicines,
    distributors,
    salesHistory,
    dailyRegister,
    expenses,
    patients,
    patientsDue,
    neededMeds,
    opdVisits,
    marketingCampaigns,
    worksheetTasks,
    employees,
    invoiceConfig,
    adminPass,
  ]);

  // POS Cart State
  const [cart, setCart] = useState<CartItem[]>([
    {
      cartId: 'c-101',
      id: '101',
      itemId: '101',
      medicineId: '101',
      name: 'Dolo 650mg',
      pack: '15*T',
      batch: 'DL-6501',
      rack: 'RACK-A3',
      mrp: 30.0,
      price: 30.0,
      rate: 21.5,
      gst: 12.0,
      stock: 15,
      qty: 1,
      quantity: 1,
      unitType: 'strip',
      isLoose: false,
      looseUnits: 0,
      tabsPerStrip: 15,
      totalPrice: 30.0,
    },
  ]);

  // Modal Management States
  const [invoicePrintData, setInvoicePrintData] = useState<InvoicePrintData | null>(null);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [aiFinderOpen, setAiFinderOpen] = useState(false);
  const [aiFinderQuery, setAiFinderQuery] = useState('');
  const [distributorModalOpen, setDistributorModalOpen] = useState(false);
  const [addStockModalOpen, setAddStockModalOpen] = useState(false);
  const [addLabStockModalOpen, setAddLabStockModalOpen] = useState(false);
  const [addNeedMedModalOpen, setAddNeedMedModalOpen] = useState(false);
  const [prefillNeedMed, setPrefillNeedMed] = useState('');
  const [addExpenseModalOpen, setAddExpenseModalOpen] = useState(false);
  const [addOPDModalOpen, setAddOPDModalOpen] = useState(false);
  const [marketingModalOpen, setMarketingModalOpen] = useState(false);
  const [campaignToEdit, setCampaignToEdit] = useState<MarketingCampaign | null>(null);
  const [worksheetModalOpen, setWorksheetModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<WorksheetTask | null>(null);
  const [addEmployeeModalOpen, setAddEmployeeModalOpen] = useState(false);
  const [editEmployeeModalOpen, setEditEmployeeModalOpen] = useState(false);
  const [empToEdit, setEmpToEdit] = useState<Employee | null>(null);
  const [changeAdminPassModalOpen, setChangeAdminPassModalOpen] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [universalModalType, setUniversalModalType] = useState<ModalType>(null);
  const [selectedPatientForCV, setSelectedPatientForCV] = useState<PatientRecord | null>(null);

  // 6-Month Invoice Retention & Auto-Purge Manager
  const calculateCutoffDate = (months: number = 6) => {
    const d = new Date();
    d.setMonth(d.getMonth() - months);
    return d.toISOString().slice(0, 10);
  };

  const handlePurgeOldInvoices = () => {
    const months = invoiceConfig.retentionMonths || 6;
    const cutoff = calculateCutoffDate(months);
    const expiredCount = salesHistory.filter(s => s.date < cutoff).length;
    if (expiredCount === 0) {
      alert(`All invoices are currently active within the ${months}-month retention window (after ${cutoff}).`);
      return;
    }
    if (confirm(`Found ${expiredCount} invoices older than 6 months (dated before ${cutoff}). Confirm deletion?`)) {
      setSalesHistory(prev => prev.filter(s => s.date >= cutoff));
      setInvoiceConfig(prev => ({
        ...prev,
        lastPurgeDate: new Date().toISOString().slice(0, 10),
      }));
      alert(`Successfully deleted ${expiredCount} invoices older than 6 months.`);
    }
  };

  // 5-Day Rolling Backup Snapshots State
  const [backupSnapshots, setBackupSnapshots] = useState<SystemBackupSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem('pcp_backup_snapshots_v1');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Error loading backup snapshots', e);
    }
    return [];
  });

  // Save backup snapshots to localStorage
  React.useEffect(() => {
    try {
      localStorage.setItem('pcp_backup_snapshots_v1', JSON.stringify(backupSnapshots));
    } catch (e) {
      console.error('Failed to save backup snapshots to localStorage', e);
    }
  }, [backupSnapshots]);

  // Create Manual or Automatic Snapshot
  const handleCreateSnapshot = (
    label?: string,
    reason: 'pre_reset_auto' | 'manual_snapshot' | 'user_backup' = 'manual_snapshot'
  ) => {
    const now = new Date();
    const expires = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000);
    const snapLabel =
      label ||
      `Snapshot (${now.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
      })} ${now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })})`;

    const newSnapshot: SystemBackupSnapshot = {
      id: `snap_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: now.toISOString(),
      expiresAt: expires.toISOString(),
      label: snapLabel,
      reason,
      counts: {
        medicines: medicines.length,
        sales: salesHistory.length,
        patients: patients.length,
        expenses: expenses.length,
        opdVisits: opdVisits.length,
        neededMeds: neededMeds.length,
        campaigns: marketingCampaigns.length,
      },
      payload: {
        medicines,
        salesHistory,
        dailyRegister,
        expenses,
        patients,
        patientsDue,
        neededMeds,
        opdVisits,
        marketingCampaigns,
        worksheetTasks,
        employees,
        invoiceConfig,
        distributors,
        adminPass,
      },
    };

    setBackupSnapshots(prev => [newSnapshot, ...prev]);
    return newSnapshot;
  };

  // Factory Reset Handler - 100% Comprehensive Data Clear Across All Modules & Central Server Sync
  const handleExecuteFactoryReset = async (
    onboardingData: OrganizationOnboardingData,
    newAdminPass: string
  ) => {
    const finalAdminPass = (newAdminPass && newAdminPass.trim()) ? newAdminPass.trim() : adminPass;
    const finalDirectorName = onboardingData.directorName?.trim() || 'Admin (Director)';
    const finalStoreName = onboardingData.storeName?.trim() || 'NEW HEALTHCARE & PHARMACY CENTRE';

    // 1. Auto-save 5-day safety snapshot before wipe
    handleCreateSnapshot(
      `Pre-Reset Automatic Backup (${new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
      })} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })})`,
      'pre_reset_auto'
    );

    // 2. Execute authoritative backend factory reset
    try {
      const res = await fetch('/api/state/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          organizationData: onboardingData,
          adminPass: finalAdminPass,
        }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.state) {
          applyServerState(json.state, json.version);
        }
      }
    } catch (err) {
      console.error('Backend reset API call failed, applying client reset:', err);
    }

    // 3. Wipe demo/test transaction, clinical, inventory, cart & distributor data locally
    setMedicines([]);
    setSalesHistory([]);
    setExpenses([]);
    setPatients([]);
    setPatientsDue([]);
    setNeededMeds([]);
    setOpdVisits([]);
    setMarketingCampaigns([]);
    setWorksheetTasks([]);
    setCart([]);
    setDistributors([]);

    // 4. Initialize fresh default Single Administrator Employee
    const freshAdminEmployee: Employee = {
      id: 'emp-admin-1',
      name: finalDirectorName,
      desig: 'Director & Admin',
      pass: finalAdminPass,
      phone: onboardingData.phone || '9876543210',
      role: 'admin',
      pin: finalAdminPass,
      permissions: [
        'dashboard',
        'pos',
        'daily-sales',
        'due-khata',
        'medicine-orders',
        'inventory',
        'inward-ocr',
        'opd',
        'patients',
        'expenses',
        'business-dev',
        'employee-mgmt',
        'invoice-settings',
        'system-reset',
      ],
    };
    setEmployees([freshAdminEmployee]);

    // 5. Reset Current User Session to the new Admin
    setCurrentUser({
      id: freshAdminEmployee.id,
      name: freshAdminEmployee.name,
      role: 'admin',
      permissions: freshAdminEmployee.permissions,
    });

    // 6. Initialize clean Daily Register with 0s and new opening cash
    setDailyRegister({
      date: getTodayISODate(),
      prevBD: 0,
      todaySell: 0,
      phonePe: 0,
      expenses: 0,
      bankShift: 0,
      isLocked: false,
      openingCash: onboardingData.openingCash || 0,
      totalSales: 0,
      cashSales: 0,
      upiSales: 0,
      cardSales: 0,
      totalExpenses: 0,
      denominations: { 2000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0 },
      closingPhysicalCash: 0,
      cashDifference: 0,
      isDrawerClosed: false,
    });

    // 7. Completely reset Invoice Settings to new organization details
    setInvoiceConfig({
      name: finalStoreName,
      storeName: finalStoreName,
      subtitle: onboardingData.subtitle?.trim() || 'Complete Healthcare, Pharmacy & Diagnostic Solution',
      phone: onboardingData.phone?.trim() || '',
      addr: onboardingData.address?.trim() || '',
      gstin: onboardingData.gstin?.trim() || '',
      dl: onboardingData.dlNo?.trim() || '',
      director: finalDirectorName,
      pharmacist: onboardingData.pharmacistName?.trim() || 'Registered Pharmacist',
      currency: onboardingData.currency?.trim() || '₹',
      waGroup: '',
      terms:
        onboardingData.welcomeNotes?.trim() ||
        'Goods once sold cannot be returned without original cash receipt. Computerized invoice.',
      retentionMonths: 6,
      autoPurgeOldInvoices: true,
      logoUrl: '',
      printerType: 'thermal_80mm',
      headerTheme: 'modern_minimal',
    });

    // 8. Update Admin Master Password
    setAdminPass(finalAdminPass);

    // 9. Clear legacy localStorage keys
    try {
      localStorage.setItem('pcp_medicines_v2', JSON.stringify([]));
      localStorage.setItem('pcp_sales_v2', JSON.stringify([]));
      localStorage.setItem('pcp_expenses_v2', JSON.stringify([]));
      localStorage.setItem('pcp_patients_v2', JSON.stringify([]));
      localStorage.setItem('pcp_patients_due_v2', JSON.stringify([]));
      localStorage.setItem('pcp_needed_meds_v2', JSON.stringify([]));
      localStorage.setItem('pcp_opd_v2', JSON.stringify([]));
      localStorage.setItem('pcp_campaigns_v2', JSON.stringify([]));
      localStorage.setItem('pcp_worksheet_v2', JSON.stringify([]));
      localStorage.setItem('pcp_distributors_v2', JSON.stringify([]));
      localStorage.setItem('pcp_employees_v2', JSON.stringify([freshAdminEmployee]));
    } catch (e) {}

    // 10. Navigate to fresh clean Dashboard
    setCurrentTab('dashboard');
  };

  // Restore from Snapshot Handler
  const handleRestoreSnapshot = (snapshot: SystemBackupSnapshot) => {
    if (!snapshot || !snapshot.payload) return;
    const p = snapshot.payload;
    if (Array.isArray(p.medicines)) setMedicines(p.medicines);
    if (Array.isArray(p.salesHistory)) setSalesHistory(p.salesHistory);
    if (p.dailyRegister) setDailyRegister(p.dailyRegister);
    if (Array.isArray(p.expenses)) setExpenses(p.expenses);
    if (Array.isArray(p.patients)) setPatients(p.patients);
    if (Array.isArray(p.patientsDue)) setPatientsDue(p.patientsDue);
    if (Array.isArray(p.neededMeds)) setNeededMeds(p.neededMeds);
    if (Array.isArray(p.opdVisits)) setOpdVisits(p.opdVisits);
    if (Array.isArray(p.marketingCampaigns)) setMarketingCampaigns(p.marketingCampaigns);
    if (Array.isArray(p.worksheetTasks)) setWorksheetTasks(p.worksheetTasks);
    if (Array.isArray(p.employees)) setEmployees(p.employees);
    if (Array.isArray(p.distributors)) setDistributors(p.distributors);
    if (p.invoiceConfig) setInvoiceConfig(p.invoiceConfig);
    if (p.adminPass) setAdminPass(p.adminPass);
    setCurrentTab('dashboard');
  };

  // Restore from JSON file string
  const handleRestoreFromFile = (fileContent: string): boolean => {
    try {
      const data = JSON.parse(fileContent);
      if (data.medicines || data.salesHistory || data.invoiceConfig) {
        if (Array.isArray(data.medicines)) setMedicines(data.medicines);
        if (Array.isArray(data.salesHistory)) setSalesHistory(data.salesHistory);
        if (data.dailyRegister) setDailyRegister(data.dailyRegister);
        if (Array.isArray(data.expenses)) setExpenses(data.expenses);
        if (Array.isArray(data.patients)) setPatients(data.patients);
        if (Array.isArray(data.patientsDue)) setPatientsDue(data.patientsDue);
        if (Array.isArray(data.neededMeds)) setNeededMeds(data.neededMeds);
        if (Array.isArray(data.opdVisits)) setOpdVisits(data.opdVisits);
        if (Array.isArray(data.marketingCampaigns)) setMarketingCampaigns(data.marketingCampaigns);
        if (Array.isArray(data.worksheetTasks)) setWorksheetTasks(data.worksheetTasks);
        if (Array.isArray(data.employees)) setEmployees(data.employees);
        if (Array.isArray(data.distributors)) setDistributors(data.distributors);
        if (data.invoiceConfig) setInvoiceConfig(data.invoiceConfig);
        if (data.adminPass) setAdminPass(data.adminPass);
        setCurrentTab('dashboard');
        return true;
      }
    } catch (e) {
      console.error('Failed to parse backup JSON file', e);
    }
    return false;
  };

  const handleDeleteSnapshot = (snapshotId: string) => {
    setBackupSnapshots(prev => prev.filter(s => s.id !== snapshotId));
  };

  // Dedicated handler to save admin password with persistent storage & employee sync
  const handleSaveAdminPassword = (newP: string) => {
    const cleanPass = newP.trim();
    setAdminPass(cleanPass);
    try {
      localStorage.setItem('pcp_admin_pass', cleanPass);
    } catch (e) {
      console.error('Failed to persist admin password to localStorage', e);
    }
    // Also synchronize PIN / password for the administrator employee record
    setEmployees(prev =>
      prev.map(emp =>
        emp.role === 'admin' || emp.id === 'admin' || emp.id === 'emp-admin-1'
          ? { ...emp, pass: cleanPass, pin: cleanPass }
          : emp
      )
    );
  };

  // Automatic 6-month purge routine
  React.useEffect(() => {
    if (invoiceConfig.autoPurgeOldInvoices !== false) {
      const months = invoiceConfig.retentionMonths || 6;
      const cutoff = calculateCutoffDate(months);
      setSalesHistory(prev => {
        const filtered = prev.filter(s => s.date >= cutoff);
        return filtered.length !== prev.length ? filtered : prev;
      });
    }
  }, [invoiceConfig.autoPurgeOldInvoices, invoiceConfig.retentionMonths]);

  // Tab switching with permission check
  const handleSelectTab = (tab: TabType) => {
    if (currentUser.role === 'admin' || currentUser.permissions.includes(tab)) {
      setCurrentTab(tab);
    } else {
      alert(`Access Restricted: You do not have permission for the "${tab}" module.`);
    }
  };

  // Add to cart helper (from AI Finder or other tabs)
  const handleAddToCart = (medicine: Medicine) => {
    setCart(prev => {
      const existsIndex = prev.findIndex(
        item => item.medicineId === medicine.id || item.itemId === medicine.id
      );
      if (existsIndex >= 0) {
        return prev.map((item, idx) =>
          idx === existsIndex
            ? {
                ...item,
                qty: (item.qty || 1) + 1,
                quantity: (item.qty || 1) + 1,
                totalPrice: ((item.qty || 1) + 1) * (item.price || item.mrp || medicine.mrp),
              }
            : item
        );
      }
      return [
        ...prev,
        {
          cartId: `${medicine.id}-${Date.now()}`,
          id: medicine.id,
          itemId: medicine.id,
          medicineId: medicine.id,
          name: medicine.name,
          pack: medicine.pack,
          batch: medicine.batch,
          rack: medicine.rack,
          mrp: medicine.mrp,
          price: medicine.mrp,
          unitPrice: medicine.mrp,
          rate: medicine.rate,
          gst: medicine.gst,
          stock: medicine.stock,
          qty: 1,
          quantity: 1,
          unitType: 'strip',
          isLoose: false,
          looseUnits: 0,
          tabsPerStrip: medicine.tabsPerStrip || 10,
          totalPrice: medicine.mrp,
        },
      ];
    });
    setCurrentTab('pos');
  };

  // Handle special need ordering
  const handleOrderSpecial = (medName: string) => {
    setPrefillNeedMed(medName);
    setAddNeedMedModalOpen(true);
  };

  // Login handler
  const handleLoginSuccess = (userRoleId: 'admin' | string) => {
    if (userRoleId === 'admin') {
      setCurrentUser({
        id: 'admin',
        name: 'Admin (Director)',
        role: 'admin',
        permissions: [
          'dashboard',
          'pos',
          'daily-sales',
          'due-khata',
          'medicine-orders',
          'inventory',
          'inward-ocr',
          'opd',
          'patients',
          'expenses',
          'business-dev',
          'employee-mgmt',
          'invoice-settings',
        ],
      });
    } else {
      const emp = employees.find(e => e.id === userRoleId);
      if (emp) {
        setCurrentUser({
          id: emp.id,
          name: emp.name,
          role: emp.id,
          permissions: emp.permissions,
        });
        if (!emp.permissions.includes(currentTab)) {
          setCurrentTab(emp.permissions[0] || 'pos');
        }
      }
    }
  };

  return (
    <div className="relative flex h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100 antialiased selection:bg-indigo-500 selection:text-white">
      {/* Frosted Glass Ambient Lighting Backdrops */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/30 blur-[130px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-fuchsia-600/20 blur-[130px]" />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[40%] rounded-full bg-blue-500/20 blur-[110px]" />
        <div className="absolute bottom-[20%] left-[10%] w-[35%] h-[35%] rounded-full bg-indigo-500/15 blur-[120px]" />
      </div>

      {/* Dark Frosted Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={handleSelectTab}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
        dueKhataCount={patientsDue.length}
        neededMedsCount={neededMeds.length}
        opdCount={opdVisits.length}
        userPermissions={currentUser.permissions}
      />

      {/* Main Container Area */}
      <div className="relative z-10 flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Frosted Header Bar */}
        <Header
          currentTab={currentTab}
          onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
          onOpenAIFinder={() => {
            setAiFinderQuery('');
            setAiFinderOpen(true);
          }}
          onOpenLoginModal={() => setLoginModalOpen(true)}
          currentUserName={currentUser.name}
        />

        {/* Dynamic Scrollable Body Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-transparent">
          <div className="max-w-7xl mx-auto space-y-5">
            {/* 1. DASHBOARD OVERVIEW */}
            {currentTab === 'dashboard' && (
              <DashboardTab
                medicines={medicines}
                salesHistory={salesHistory}
                dailyRegister={dailyRegister}
                expenses={expenses}
                patientsDue={patientsDue}
                neededMeds={neededMeds}
                opdVisits={opdVisits}
                marketingCampaigns={marketingCampaigns}
                onOpenUniversalModal={type => setUniversalModalType(type)}
                onOpenAIFinder={() => {
                  setAiFinderQuery('');
                  setAiFinderOpen(true);
                }}
                onNavigateTab={tab => handleSelectTab(tab)}
              />
            )}

            {/* 2. POS BILLING COUNTER */}
            {currentTab === 'pos' && (
              <POSTab
                medicines={medicines}
                setMedicines={setMedicines}
                cart={cart}
                setCart={setCart}
                invoiceConfig={invoiceConfig}
                salesHistory={salesHistory}
                setSalesHistory={setSalesHistory}
                dailyRegister={dailyRegister}
                setDailyRegister={setDailyRegister}
                patientsDue={patientsDue}
                setPatientsDue={setPatientsDue}
                patients={patients}
                setPatients={setPatients}
                onPrintInvoice={data => setInvoicePrintData(data)}
                onOpenAIFinderWithQuery={q => {
                  setAiFinderQuery(q);
                  setAiFinderOpen(true);
                }}
              />
            )}

            {/* 3. DAILY SALES REGISTER */}
            {currentTab === 'daily-sales' && (
              <DailySalesTab
                currentUser={currentUser}
                dailyRegister={dailyRegister}
                setDailyRegister={setDailyRegister}
                salesHistory={salesHistory}
                expenses={expenses}
                setExpenses={setExpenses}
                onPrintInvoice={data => setInvoicePrintData(data)}
                onOpenAddExpenseModal={() => setAddExpenseModalOpen(true)}
              />
            )}

            {/* 4. DUE KHATA MANAGEMENT */}
            {currentTab === 'due-khata' && (
              <DueKhataTab
                patientsDue={patientsDue}
                setPatientsDue={setPatientsDue}
                setSalesHistory={setSalesHistory}
                setDailyRegister={setDailyRegister}
              />
            )}

            {/* 5. SPECIAL MEDICINE ORDERS */}
            {currentTab === 'medicine-orders' && (
              <MedicineOrdersTab
                neededMeds={neededMeds}
                setNeededMeds={setNeededMeds}
                patients={patients}
                onViewPatientProfile={p => {
                  setSelectedPatientForCV(p);
                  setUniversalModalType('patient_cv');
                }}
                onOpenAddNeedModal={() => {
                  setPrefillNeedMed('');
                  setAddNeedMedModalOpen(true);
                }}
              />
            )}

            {/* 6. MEDICINE STOCK ERP INVENTORY */}
            {currentTab === 'inventory' && (
              <InventoryTab
                medicines={medicines}
                setMedicines={setMedicines}
                onOpenAddStockModal={() => setAddStockModalOpen(true)}
                onOpenAddLabStockModal={() => setAddLabStockModalOpen(true)}
                onOpenDistributorsModal={() => setDistributorModalOpen(true)}
              />
            )}

            {/* 7. OCR INWARD INVOICE AUTO-SCAN */}
            {currentTab === 'inward-ocr' && (
              <InwardOCRTab
                distributors={distributors}
                setDistributors={setDistributors}
                medicines={medicines}
                setMedicines={setMedicines}
                invoiceConfig={invoiceConfig}
                expenses={expenses}
                setExpenses={setExpenses}
              />
            )}

            {/* 8. OPD & RE-VISITS */}
            {currentTab === 'opd' && (
              <OPDTab
                opdVisits={opdVisits}
                setOpdVisits={setOpdVisits}
                onOpenAddOPDModal={() => setAddOPDModalOpen(true)}
              />
            )}

            {/* 9. PATIENT MASTER DATABASE */}
            {currentTab === 'patients' && (
              <PatientsTab
                patientsDue={patients}
                setPatients={setPatients}
                onViewPatientProfile={p => {
                  setSelectedPatientForCV(p);
                  setUniversalModalType('patient_cv');
                }}
                shopName={invoiceConfig.name}
                waGroupLink={invoiceConfig.waGroup}
              />
            )}

            {/* 10. DAILY EXPENDITURES REGISTER */}
            {currentTab === 'expenses' && (
              <ExpensesTab
                expenses={expenses}
                setExpenses={setExpenses}
                onOpenAddExpenseModal={() => setAddExpenseModalOpen(true)}
              />
            )}

            {/* 11. DOCTOR CAMPAIGN & WORKSHEET */}
            {currentTab === 'business-dev' && (
              <BusinessDevTab
                marketingCampaigns={marketingCampaigns}
                worksheetTasks={worksheetTasks}
                onOpenMarketingModal={campaign => {
                  setCampaignToEdit(campaign || null);
                  setMarketingModalOpen(true);
                }}
                onOpenWorksheetModal={task => {
                  setTaskToEdit(task || null);
                  setWorksheetModalOpen(true);
                }}
              />
            )}

            {/* 12. EMPLOYEE ACCESS MANAGEMENT */}
            {currentTab === 'employee-mgmt' && (
              <EmployeeMgmtTab
                employees={employees}
                adminPass={adminPass}
                onOpenAddEmployeeModal={() => setAddEmployeeModalOpen(true)}
                onOpenEditEmployeeModal={emp => {
                  setEmpToEdit(emp);
                  setEditEmployeeModalOpen(true);
                }}
                onOpenChangeAdminPassModal={() => setChangeAdminPassModalOpen(true)}
                onDeleteEmployee={id => {
                  if (confirm('Are you sure you want to remove this employee?')) {
                    setEmployees(prev => prev.filter(e => e.id !== id));
                  }
                }}
              />
            )}

            {/* 13. INVOICE & WHATSAPP SETTINGS */}
            {currentTab === 'invoice-settings' && (
              <InvoiceSettingsTab
                invoiceConfig={invoiceConfig}
                setInvoiceConfig={setInvoiceConfig}
                salesHistory={salesHistory}
                onPurgeOldInvoices={handlePurgeOldInvoices}
                onPrintInvoice={data => setInvoicePrintData(data)}
                onNavigateToReset={() => handleSelectTab('system-reset')}
              />
            )}

            {/* 14. SYSTEM FACTORY RESET & 5-DAY BACKUP */}
            {currentTab === 'system-reset' && (
              <SystemResetTab
                currentUser={currentUser}
                adminPass={adminPass}
                invoiceConfig={invoiceConfig}
                medicines={medicines}
                salesHistory={salesHistory}
                dailyRegister={dailyRegister}
                expenses={expenses}
                patients={patients}
                neededMeds={neededMeds}
                opdVisits={opdVisits}
                marketingCampaigns={marketingCampaigns}
                worksheetTasks={worksheetTasks}
                employees={employees}
                distributors={distributors}
                backupSnapshots={backupSnapshots}
                onExecuteFactoryReset={handleExecuteFactoryReset}
                onRestoreSnapshot={handleRestoreSnapshot}
                onCreateManualSnapshot={handleCreateSnapshot}
                onDeleteSnapshot={handleDeleteSnapshot}
                onRestoreFromFile={handleRestoreFromFile}
              />
            )}
          </div>
        </main>
      </div>

      {/* MODALS LAYER */}
      {/* 1. Tax Invoice Print / PDF Modal */}
      <InvoicePrintModal
        invoice={invoicePrintData}
        onClose={() => setInvoicePrintData(null)}
        config={invoiceConfig}
      />

      {/* 2. AI Generic Finder & Live Market Modal */}
      <AIFinderModal
        isOpen={aiFinderOpen}
        onClose={() => setAiFinderOpen(false)}
        initialQuery={aiFinderQuery}
        medicines={medicines}
        onAddToCart={handleAddToCart}
        onOrderSpecial={handleOrderSpecial}
      />

      {/* 3. Manage Distributors Directory Modal */}
      <DistributorModal
        isOpen={distributorModalOpen}
        onClose={() => setDistributorModalOpen(false)}
        distributors={distributors}
        setDistributors={setDistributors}
      />

      {/* 4. Add Medicine Stock Modal */}
      <AddStockModal
        isOpen={addStockModalOpen}
        onClose={() => setAddStockModalOpen(false)}
        distributors={distributors}
        setDistributors={setDistributors}
        onSaveMedicine={m => setMedicines(prev => [m, ...prev])}
      />

      {/* 4B. Add New Lab Stock / Test Modal */}
      <AddLabStockModal
        isOpen={addLabStockModalOpen}
        onClose={() => setAddLabStockModalOpen(false)}
        onSaveLabStock={labItem => setMedicines(prev => [labItem, ...prev])}
      />

      {/* 5. Add Special Need Medicine Modal */}
      <AddNeedMedModal
        isOpen={addNeedMedModalOpen}
        onClose={() => setAddNeedMedModalOpen(false)}
        distributors={distributors}
        patients={patients}
        medicines={medicines}
        prefillMedName={prefillNeedMed}
        onSaveNeedMed={order => setNeededMeds(prev => [order, ...prev])}
        onQuickAddPatient={p => setPatients(prev => [p, ...prev])}
      />

      {/* 6. Log Daily Expense Modal */}
      <AddExpenseModal
        isOpen={addExpenseModalOpen}
        onClose={() => setAddExpenseModalOpen(false)}
        onSaveExpense={expense => {
          setExpenses(prev => [expense, ...prev]);
          setDailyRegister(prev => {
            const currentRegDate = prev.date || getTodayISODate();
            if (expense.date === currentRegDate) {
              const updatedExpenses = Number(((prev.expenses || 0) + expense.amt).toFixed(2));
              return {
                ...prev,
                expenses: updatedExpenses,
              };
            }
            return prev;
          });
        }}
      />

      {/* 7. Record OPD Patient Consultation Modal */}
      <AddOPDModal
        isOpen={addOPDModalOpen}
        onClose={() => setAddOPDModalOpen(false)}
        onSaveOPD={visit => setOpdVisits(prev => [visit, ...prev])}
      />

      {/* 8. Doctor Campaign Modal */}
      <MarketingModal
        isOpen={marketingModalOpen}
        onClose={() => {
          setMarketingModalOpen(false);
          setCampaignToEdit(null);
        }}
        campaignToEdit={campaignToEdit}
        onSaveCampaign={campaign => {
          setMarketingCampaigns(prev => {
            const exists = prev.some(c => c.id === campaign.id);
            if (exists) {
              return prev.map(c => (c.id === campaign.id ? campaign : c));
            }
            return [campaign, ...prev];
          });
        }}
      />

      {/* 9. Monthly Maintenance Worksheet Modal */}
      <WorksheetModal
        isOpen={worksheetModalOpen}
        onClose={() => {
          setWorksheetModalOpen(false);
          setTaskToEdit(null);
        }}
        taskToEdit={taskToEdit}
        onSaveTask={task => {
          setWorksheetTasks(prev => {
            const exists = prev.some(t => t.id === task.id);
            if (exists) {
              return prev.map(t => (t.id === task.id ? task : t));
            }
            return [task, ...prev];
          });
        }}
      />

      {/* 10. Employee Add / Edit Modals */}
      <AddEmployeeModal
        isOpen={addEmployeeModalOpen}
        onClose={() => setAddEmployeeModalOpen(false)}
        onSaveEmployee={emp => setEmployees(prev => [emp, ...prev])}
      />

      <EditEmployeeModal
        isOpen={editEmployeeModalOpen}
        onClose={() => {
          setEditEmployeeModalOpen(false);
          setEmpToEdit(null);
        }}
        emp={empToEdit}
        onUpdateEmployee={emp => {
          setEmployees(prev => prev.map(e => (e.id === emp.id ? emp : e)));
        }}
      />

      {/* 11. Change Admin Password Modal */}
      <ChangeAdminPassModal
        isOpen={changeAdminPassModalOpen}
        onClose={() => setChangeAdminPassModalOpen(false)}
        currentPass={adminPass}
        onSaveNewPass={handleSaveAdminPassword}
      />

      {/* 12. Switch User / Login Modal */}
      <LoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        employees={employees}
        adminPass={adminPass}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* 13. Universal Interactive KPI & Breakdown Modal */}
      <UniversalDetailsModal
        type={universalModalType}
        onClose={() => setUniversalModalType(null)}
        medicines={medicines}
        opdVisits={opdVisits}
        patientsDue={patientsDue}
        salesHistory={salesHistory}
        dailyRegister={dailyRegister}
        expenses={expenses}
        selectedPatient={selectedPatientForCV}
      />
    </div>
  );
}

export default App;
