import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  LogIn,
  ShieldAlert,
  ShieldCheck,
  User,
  Users,
  X,
} from 'lucide-react';
import { Employee } from '../../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  adminPass?: string;
  onLoginSuccess: (userRole: 'admin' | string, userName: string) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  employees,
  adminPass = '1122',
  onLoginSuccess,
}) => {
  const [selectedRole, setSelectedRole] = useState<'admin' | string>('admin');
  const [enteredPass, setEnteredPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const passInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setEnteredPass('');
      setErrorMsg(null);
      setShowPass(false);
      setTimeout(() => {
        passInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, selectedRole]);

  if (!isOpen) return null;

  const selectedEmployee = employees.find(e => e.id === selectedRole);
  const isMasterAdmin = selectedRole === 'admin';
  const currentDisplayName = isMasterAdmin ? 'Admin (Director)' : (selectedEmployee?.name || 'Employee');
  const currentDesig = isMasterAdmin ? 'Master Administrator (Full Access)' : (selectedEmployee?.desig || 'Staff');

  const handleSwitchUser = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanInput = enteredPass.trim();
    if (!cleanInput) {
      setErrorMsg('Please enter the login password or PIN.');
      return;
    }

    if (isMasterAdmin) {
      const correctAdminPass = (adminPass || '1122').trim();
      if (cleanInput === correctAdminPass) {
        onLoginSuccess('admin', 'Admin (Director)');
        onClose();
      } else {
        setErrorMsg('Incorrect Master Admin password. Please verify and retry.');
      }
    } else {
      const emp = employees.find(e => e.id === selectedRole);
      if (emp) {
        const correctEmpPass = (emp.pass || emp.pin || '1234').trim();
        if (cleanInput === correctEmpPass) {
          onLoginSuccess(emp.id, emp.name);
          onClose();
        } else {
          setErrorMsg(`Incorrect password for ${emp.name}. Please enter valid staff credentials.`);
        }
      } else {
        setErrorMsg('Selected staff profile not found.');
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        {/* Modal Header */}
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Switch User / Login</h3>
              <p className="text-[11px] text-slate-400">Authenticate profile with security password</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSwitchUser} className="space-y-4">
          {/* User Selection Dropdown */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1.5 flex items-center justify-between">
              <span>Select Profile / Staff</span>
              <span className="text-[10px] text-indigo-400 font-normal">
                {employees.length + 1} Profile{employees.length > 0 ? 's' : ''} available
              </span>
            </label>
            <select
              id="switch-user-select-role"
              value={selectedRole}
              onChange={e => {
                setSelectedRole(e.target.value);
                setEnteredPass('');
                setErrorMsg(null);
              }}
              className="w-full p-3 bg-white/5 border border-white/15 rounded-2xl outline-none text-white focus:border-indigo-400 font-medium backdrop-blur-md cursor-pointer transition"
            >
              <option value="admin" className="bg-slate-900 text-white font-semibold">
                👑 Admin / Director (Full Authority)
              </option>
              {employees
                .filter(e => e.role !== 'admin' && e.id !== 'admin')
                .map(emp => (
                  <option key={emp.id} value={emp.id} className="bg-slate-900 text-white">
                    👤 {emp.name} — {emp.desig}
                  </option>
                ))}
            </select>
          </div>

          {/* Active Profile Info Banner */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shadow-inner ${
                  isMasterAdmin
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                }`}
              >
                {isMasterAdmin ? '👑' : currentDisplayName.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-bold text-white text-xs">{currentDisplayName}</p>
                <p className="text-[10px] text-slate-400 font-medium">{currentDesig}</p>
              </div>
            </div>

            <span
              className={`text-[10px] font-semibold px-2.5 py-1 rounded-xl border ${
                isMasterAdmin
                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                  : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20'
              }`}
            >
              {isMasterAdmin ? 'All 14 Modules' : `${selectedEmployee?.permissions?.length || 0} Modules`}
            </span>
          </div>

          {/* Password / PIN Input Field */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-indigo-400" />
                <span>Password / PIN for {currentDisplayName}</span>
              </label>
              <span className="text-[10px] text-slate-400">Required for login</span>
            </div>

            <div className="relative">
              <input
                ref={passInputRef}
                id="switch-user-pass-input"
                type={showPass ? 'text' : 'password'}
                value={enteredPass}
                onChange={e => {
                  setEnteredPass(e.target.value);
                  if (errorMsg) setErrorMsg(null);
                }}
                placeholder="Enter login password or 4-digit PIN"
                className="w-full pl-3.5 pr-10 py-3 bg-white/5 border border-white/15 rounded-2xl font-mono text-sm font-bold text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 focus:bg-white/10 transition shadow-inner tracking-wider"
                required
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1 transition"
                title={showPass ? 'Hide password' : 'Show password'}
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Error Message Toast */}
          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-2 flex gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-2xl font-semibold border border-white/10 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="switch-user-submit-btn"
              className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-lg shadow-indigo-950/40 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Log In & Switch</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
