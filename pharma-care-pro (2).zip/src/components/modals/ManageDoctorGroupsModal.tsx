export * from './ManageMedicineGroupsModal';
export { ManageMedicineGroupsModal as ManageDoctorGroupsModal } from './ManageMedicineGroupsModal';
