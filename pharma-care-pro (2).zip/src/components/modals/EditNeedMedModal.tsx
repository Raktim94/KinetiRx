import React, { useState, useEffect, useRef } from 'react';
import {
  Building2,
  Check,
  Clock,
  Edit3,
  FileCheck2,
  Package,
  Pill,
  Phone,
  Plus,
  Save,
  ShieldCheck,
  Trash2,
  Truck,
  User,
  X,
} from 'lucide-react';
import { Distributor, NeededMedItem, NeededMedOrder } from '../../types';
import { getTodayISODate } from '../../utils/dateUtils';

interface EditNeedMedModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: NeededMedOrder | null;
  distributors: Distributor[];
  setDistributors?: React.Dispatch<React.SetStateAction<Distributor[]>>;
  onUpdateOrder: (updated: NeededMedOrder) => void;
}

export const EditNeedMedModal: React.FC<EditNeedMedModalProps> = ({
  isOpen,
  onClose,
  order,
  distributors,
  setDistributors,
  onUpdateOrder,
}) => {
  const [patientId, setPatientId] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [dist, setDist] = useState('');
  const [time, setTime] = useState('');
  const [status, setStatus] = useState<NeededMedOrder['status']>('Distributor Ordered');
  const [notes, setNotes] = useState('');

  // Multi-item medicines array
  const [medItems, setMedItems] = useState<NeededMedItem[]>([]);

  const [isDistDropdownOpen, setIsDistDropdownOpen] = useState(false);
  const [showDistRegisterDrawer, setShowDistRegisterDrawer] = useState(false);

  // New Distributor Registration Form
  const [newDistName, setNewDistName] = useState('');
  const [newDistPhone, setNewDistPhone] = useState('');
  const [newDistGstin, setNewDistGstin] = useState('');
  const [newDistDlNo, setNewDistDlNo] = useState('');
  const [newDistAddr, setNewDistAddr] = useState('');

  const distDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (order) {
      setPatientId(order.patientId || '');
      setName(order.name || '');
      setPhone(order.phone || '');
      setDist(order.dist || '');
      setTime(order.time || '');
      setStatus(order.status || 'Distributor Ordered');
      setNotes(order.notes || '');

      if (order.items && order.items.length > 0) {
        setMedItems(order.items);
      } else {
        setMedItems([
          {
            id: 'item-1',
            med: order.med || '',
            qty: order.qty || 1,
            unit: 'Strips',
          },
        ]);
      }
    }
  }, [order, isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (distDropdownRef.current && !distDropdownRef.current.contains(event.target as Node)) {
        setIsDistDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!isOpen || !order) return null;

  // Matched distributor from database
  const matchedDistributor = distributors.find(
    d =>
      d.name.toLowerCase() === dist.trim().toLowerCase() ||
      d.name.toLowerCase().includes(dist.trim().toLowerCase()) ||
      (dist.trim().length > 3 && dist.toLowerCase().includes(d.name.toLowerCase()))
  );

  const filteredDistributors = distributors.filter(d => {
    if (!dist.trim()) return true;
    const q = dist.toLowerCase().trim();
    return (
      d.name.toLowerCase().includes(q) ||
      (d.phone && d.phone.includes(q)) ||
      (d.gstin && d.gstin.toLowerCase().includes(q))
    );
  });

  const handleAddMedicineRow = () => {
    setMedItems(prev => [
      ...prev,
      {
        id: 'item-' + Date.now(),
        med: '',
        qty: 1,
        unit: 'Strips',
      },
    ]);
  };

  const handleRemoveMedicineRow = (index: number) => {
    if (medItems.length <= 1) {
      setMedItems([{ id: 'item-1', med: '', qty: 1, unit: 'Strips' }]);
      return;
    }
    setMedItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleUpdateItemMed = (index: number, medName: string) => {
    setMedItems(prev =>
      prev.map((item, idx) => (idx === index ? { ...item, med: medName } : item))
    );
  };

  const handleUpdateItemQty = (index: number, quantity: number) => {
    setMedItems(prev =>
      prev.map((item, idx) => (idx === index ? { ...item, qty: Math.max(1, quantity) } : item))
    );
  };

  const handleUpdateItemUnit = (index: number, unit: string) => {
    setMedItems(prev =>
      prev.map((item, idx) => (idx === index ? { ...item, unit } : item))
    );
  };

  const handleQuickRegisterDistributor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDistName.trim()) {
      alert('Please enter Distributor Name');
      return;
    }

    const createdDist: Distributor = {
      id: 'DIST-' + Date.now(),
      name: newDistName.trim().toUpperCase(),
      phone: newDistPhone.trim() || 'N/A',
      gstin: newDistGstin.trim() || 'N/A',
      dlNo: newDistDlNo.trim() || undefined,
      addr: newDistAddr.trim() || 'Local Pharma Market',
      registeredDate: getTodayISODate(),
      source: 'Manual Registration',
    };

    if (setDistributors) {
      setDistributors(prev => {
        const updated = [createdDist, ...prev];
        try {
          localStorage.setItem('pcp_distributors_v2', JSON.stringify(updated));
        } catch (err) {}
        return updated;
      });
    }

    setDist(createdDist.name);
    setShowDistRegisterDrawer(false);
    setNewDistName('');
    setNewDistPhone('');
    setNewDistGstin('');
    setNewDistDlNo('');
    setNewDistAddr('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validItems = medItems.filter(i => i.med.trim().length > 0);
    if (validItems.length === 0) {
      alert('Please specify at least one medicine name');
      return;
    }

    const finalDist = dist.trim() || 'General Distributor';

    const primaryMedTitle =
      validItems.length === 1
        ? validItems[0].med
        : `${validItems[0].med} (+${validItems.length - 1} more items)`;

    const totalQty = validItems.reduce((sum, i) => sum + (i.qty || 1), 0);

    const updatedOrder: NeededMedOrder = {
      ...order,
      med: primaryMedTitle,
      patientId: patientId.trim() || undefined,
      name: name.trim() || 'Walk-in Customer',
      phone: phone.trim() || 'N/A',
      dist: finalDist,
      time: time.trim() || 'Tomorrow Afternoon',
      qty: totalQty,
      items: validItems,
      notes: notes.trim() || undefined,
      status,
    };

    onUpdateOrder(updatedOrder);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-2xl w-full p-5 sm:p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95 max-h-[92vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Edit3 className="w-4 h-4" />
            </div>
            <span>Edit Special Medicine Order (জরুরি অর্ডার সংশোধন)</span>
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Multiple Medicines List */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
            <div className="flex justify-between items-center">
              <label className="font-bold text-white flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-indigo-400" />
                <span>Medicines & Quantities Required (ওষুধের তালিকা ও পরিমাণ):</span>
                <span className="text-rose-400">*</span>
              </label>
              <button
                type="button"
                onClick={handleAddMedicineRow}
                className="text-[11px] bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 px-2 py-0.5 rounded-lg flex items-center gap-1 transition cursor-pointer font-bold"
              >
                <Plus className="w-3 h-3" />
                <span>Add Medicine</span>
              </button>
            </div>

            <div className="space-y-2">
              {medItems.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="p-2 rounded-xl bg-slate-950/70 border border-white/10 flex items-center gap-2 flex-wrap sm:flex-nowrap"
                >
                  <span className="w-5 h-5 rounded-md bg-indigo-500/20 text-indigo-300 font-mono font-bold flex items-center justify-center text-[11px] shrink-0">
                    {idx + 1}
                  </span>

                  <input
                    type="text"
                    value={item.med}
                    onChange={e => handleUpdateItemMed(idx, e.target.value)}
                    placeholder="Medicine Name (e.g. Augmentin 625 Duo)"
                    className="flex-1 min-w-[180px] p-2 bg-slate-900 border border-white/15 rounded-xl font-bold text-white outline-none focus:border-indigo-400 text-xs"
                    required
                  />

                  <div className="flex items-center gap-1 shrink-0">
                    <label className="text-[10px] text-slate-400">Qty:</label>
                    <input
                      type="number"
                      min="1"
                      value={item.qty}
                      onChange={e =>
                        handleUpdateItemQty(idx, parseInt(e.target.value, 10) || 1)
                      }
                      className="w-14 p-2 bg-slate-900 border border-white/15 rounded-xl font-mono font-bold text-center text-white outline-none text-xs"
                      required
                    />
                    <select
                      value={item.unit || 'Strips'}
                      onChange={e => handleUpdateItemUnit(idx, e.target.value)}
                      className="p-2 bg-slate-900 border border-white/15 rounded-xl text-slate-300 text-xs font-semibold outline-none"
                    >
                      <option value="Strips">Strips</option>
                      <option value="Packs">Packs</option>
                      <option value="Bottles">Bottles</option>
                      <option value="Vials">Vials</option>
                      <option value="Boxes">Boxes</option>
                      <option value="Units">Units</option>
                    </select>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleRemoveMedicineRow(idx)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-300 hover:bg-rose-500/20 transition cursor-pointer shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Patient Details */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Patient ID</label>
              <input
                type="text"
                value={patientId}
                onChange={e => setPatientId(e.target.value)}
                placeholder="101"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-teal-300 outline-none focus:border-indigo-400 text-xs font-bold"
              />
            </div>
            <div className="col-span-2">
              <label className="font-semibold text-slate-300 block mb-1">Patient Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Customer Name"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Mobile Number</label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="Phone number"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white outline-none focus:border-indigo-400 text-xs"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Order Status</label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as NeededMedOrder['status'])}
                className="w-full p-2.5 bg-slate-900 border border-white/15 rounded-xl font-bold text-indigo-300 outline-none focus:border-indigo-400 text-xs"
              >
                <option value="Distributor Ordered">Distributor Ordered</option>
                <option value="Processing">Processing</option>
                <option value="Pending">Pending</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {/* DISTRIBUTOR SELECTION / TYPING / AUTOCOMPLETE */}
          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-white/10 space-y-2 relative" ref={distDropdownRef}>
            <div className="flex justify-between items-center flex-wrap gap-2">
              <label className="font-bold text-slate-200 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-indigo-400" />
                <span>Distributor / Supplier Name:</span>
              </label>

              <button
                type="button"
                onClick={() => setShowDistRegisterDrawer(!showDistRegisterDrawer)}
                className="text-[11px] text-indigo-300 hover:text-white font-semibold flex items-center gap-1 bg-indigo-600/25 hover:bg-indigo-600/40 border border-indigo-500/40 px-2 py-0.5 rounded-lg transition cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>+ Register New Supplier</span>
              </button>
            </div>

            <div className="relative">
              <Truck className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                list="edit-distributors-datalist"
                value={dist}
                onChange={e => {
                  setDist(e.target.value);
                  setIsDistDropdownOpen(true);
                }}
                onFocus={() => setIsDistDropdownOpen(true)}
                placeholder="Type or select distributor..."
                className="w-full pl-9 pr-8 py-2.5 bg-slate-900 border border-white/15 rounded-xl font-bold text-white placeholder:text-slate-500 outline-none focus:border-indigo-400 text-xs"
                required
              />
              <datalist id="edit-distributors-datalist">
                {distributors.map(d => (
                  <option key={d.id} value={d.name}>
                    {d.phone && d.phone !== 'N/A' ? `Ph: ${d.phone}` : ''}
                  </option>
                ))}
              </datalist>

              {/* Suggestions */}
              {isDistDropdownOpen && filteredDistributors.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-white/20 rounded-2xl shadow-2xl max-h-40 overflow-y-auto z-50 divide-y divide-white/10 backdrop-blur-xl">
                  {filteredDistributors.map(d => (
                    <div
                      key={d.id}
                      onClick={() => {
                        setDist(d.name);
                        setIsDistDropdownOpen(false);
                      }}
                      className="p-2.5 hover:bg-indigo-600/30 cursor-pointer flex justify-between items-center text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{d.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {d.phone && d.phone !== 'N/A' ? `📞 ${d.phone} • ` : ''}
                          {d.addr || 'Registered Supplier'}
                        </span>
                      </div>
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-md font-mono">
                        Select
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {matchedDistributor ? (
              <div className="p-2 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-200 flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{matchedDistributor.name}</span>
                  {matchedDistributor.phone && matchedDistributor.phone !== 'N/A' && (
                    <span className="text-emerald-300 font-mono font-normal ml-2 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      <span>{matchedDistributor.phone}</span>
                    </span>
                  )}
                </div>
              </div>
            ) : null}

            {/* Quick Supplier Register Form */}
            {showDistRegisterDrawer && (
              <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/40 space-y-2 mt-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-xs">Register New Supplier:</span>
                  <button
                    type="button"
                    onClick={() => setShowDistRegisterDrawer(false)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    ✕
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Distributor Name"
                    value={newDistName}
                    onChange={e => setNewDistName(e.target.value)}
                    className="col-span-2 p-2 bg-slate-900 border border-white/15 rounded-lg text-white text-xs font-bold"
                  />
                  <input
                    type="text"
                    placeholder="Mobile / WhatsApp"
                    value={newDistPhone}
                    onChange={e => setNewDistPhone(e.target.value)}
                    className="p-2 bg-slate-900 border border-white/15 rounded-lg text-white font-mono text-xs"
                  />
                  <input
                    type="text"
                    placeholder="GSTIN Number"
                    value={newDistGstin}
                    onChange={e => setNewDistGstin(e.target.value)}
                    className="p-2 bg-slate-900 border border-white/15 rounded-lg text-white font-mono text-xs"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowDistRegisterDrawer(false)}
                    className="px-2.5 py-1 text-slate-400 text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleQuickRegisterDistributor}
                    className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs"
                  >
                    Save & Link
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Promise Delivery Time
              </label>
              <input
                type="text"
                value={time}
                onChange={e => setTime(e.target.value)}
                placeholder="e.g. Tomorrow Afternoon"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs"
                required
              />
            </div>
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Remarks / Notes</label>
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Optional notes"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Update Order</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
