import React, { useState } from 'react';
import {
  AlertCircle,
  Building2,
  Check,
  CheckCircle2,
  Crown,
  Edit3,
  Eye,
  EyeOff,
  History,
  KeyRound,
  Lock,
  Phone,
  Plus,
  RotateCcw,
  Save,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import { Employee } from '../../types';

interface EmployeeMgmtTabProps {
  employees: Employee[];
  adminPass?: string;
  adminName?: string;
  onOpenAddEmployeeModal: () => void;
  onOpenEditEmployeeModal: (emp: Employee) => void;
  onDeleteEmployee: (empId: string) => void;
  onSaveAdminPassword?: (newPass: string) => void;
  onNavigateToReset?: () => void;
}

export const EmployeeMgmtTab: React.FC<EmployeeMgmtTabProps> = ({
  employees,
  adminPass = '1122',
  adminName = 'Director & Admin',
  onOpenAddEmployeeModal,
  onOpenEditEmployeeModal,
  onDeleteEmployee,
  onSaveAdminPassword,
  onNavigateToReset,
}) => {
  // Admin password change state
  const [isEditingAdminPass, setIsEditingAdminPass] = useState(false);
  const [newAdminPass, setNewAdminPass] = useState('');
  const [confirmAdminPass, setConfirmAdminPass] = useState('');
  const [showAdminPass, setShowAdminPass] = useState(false);
  const [adminPassMessage, setAdminPassMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Staff password preview toggles (empId -> boolean)
  const [revealedStaffPasses, setRevealedStaffPasses] = useState<Record<string, boolean>>({});

  const toggleRevealStaffPass = (empId: string) => {
    setRevealedStaffPasses(prev => ({
      ...prev,
      [empId]: !prev[empId],
    }));
  };

  const handleUpdateAdminPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminPassMessage(null);

    const cleanPass = newAdminPass.trim();
    if (!cleanPass) {
      setAdminPassMessage({ text: 'Please enter a valid new password / PIN.', type: 'error' });
      return;
    }

    if (cleanPass !== confirmAdminPass.trim()) {
      setAdminPassMessage({ text: 'Passwords do not match. Please re-type identically.', type: 'error' });
      return;
    }

    if (cleanPass.length < 2) {
      setAdminPassMessage({ text: 'Password should be at least 2 characters long.', type: 'error' });
      return;
    }

    if (onSaveAdminPassword) {
      onSaveAdminPassword(cleanPass);
    }

    setAdminPassMessage({ text: 'Master Admin password successfully updated!', type: 'success' });
    setNewAdminPass('');
    setConfirmAdminPass('');
    setIsEditingAdminPass(false);
    setTimeout(() => setAdminPassMessage(null), 4000);
  };

  return (
    <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl space-y-6 text-slate-100">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-white/10 pb-4 flex-wrap gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center text-pink-400">
              <Users className="w-4 h-4" />
            </div>
            <span>Staff & Employee Access Control</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Manage pharmacy staff accounts, individual login passwords, role permissions, and Master Admin credentials.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {onNavigateToReset && (
            <button
              id="btn-employee-open-reset-backup"
              onClick={onNavigateToReset}
              className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/40 px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 backdrop-blur-md transition shadow-md cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
              <span>5-Day Backup & Reset Hub</span>
            </button>
          )}

          <button
            id="btn-add-new-employee"
            onClick={onOpenAddEmployeeModal}
            className="bg-pink-600 hover:bg-pink-500 text-white px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-pink-600/30 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add New Employee</span>
          </button>
        </div>
      </div>

      {/* Success / Error Notification */}
      {adminPassMessage && (
        <div
          className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between gap-3 animate-in fade-in ${
            adminPassMessage.type === 'success'
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {adminPassMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{adminPassMessage.text}</span>
          </div>
          <button
            onClick={() => setAdminPassMessage(null)}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. MASTER ADMIN / DIRECT ADMIN PASSWORD CONTROL CARD */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-amber-500/10 via-slate-900/60 to-purple-500/10 backdrop-blur-2xl border border-amber-500/30 shadow-2xl space-y-4">
        <div className="flex justify-between items-center flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-lg shadow-amber-500/20">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-bold text-white">Direct / Main Admin Credentials</h4>
                <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                  Full Authority (14 Modules)
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Master password used for administrative login, settings override, and system management.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-2xl">
              <KeyRound className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs font-mono font-bold text-amber-300">
                {showAdminPass ? adminPass : '••••••••'}
              </span>
              <button
                type="button"
                onClick={() => setShowAdminPass(!showAdminPass)}
                className="text-slate-400 hover:text-white p-0.5 transition"
                title={showAdminPass ? 'Hide password' : 'Show password'}
              >
                {showAdminPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>

            {!isEditingAdminPass && (
              <button
                id="btn-edit-admin-password"
                type="button"
                onClick={() => {
                  setIsEditingAdminPass(true);
                  setNewAdminPass('');
                  setConfirmAdminPass('');
                }}
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 px-3.5 py-1.5 rounded-2xl text-xs font-bold flex items-center gap-1.5 backdrop-blur-md transition shadow-md cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Change Admin Password</span>
              </button>
            )}
          </div>
        </div>

        {/* Change Admin Password Inline Form */}
        {isEditingAdminPass && (
          <form
            onSubmit={handleUpdateAdminPassword}
            className="p-4 rounded-2xl bg-black/40 border border-amber-500/20 space-y-3 animate-in fade-in"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5" />
                Set New Master Admin Password / PIN
              </span>
              <button
                type="button"
                onClick={() => setIsEditingAdminPass(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-300 block mb-1">New Password / PIN</label>
                <input
                  type="password"
                  id="input-new-admin-pass"
                  value={newAdminPass}
                  onChange={e => setNewAdminPass(e.target.value)}
                  placeholder="Enter new Master password"
                  className="w-full p-2.5 bg-slate-900 border border-amber-500/30 rounded-xl text-white font-mono text-xs outline-none focus:border-amber-400"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Confirm New Password</label>
                <input
                  type="password"
                  id="input-confirm-admin-pass"
                  value={confirmAdminPass}
                  onChange={e => setConfirmAdminPass(e.target.value)}
                  placeholder="Re-enter new Master password"
                  className="w-full p-2.5 bg-slate-900 border border-amber-500/30 rounded-xl text-white font-mono text-xs outline-none focus:border-amber-400"
                  required
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsEditingAdminPass(false)}
                className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-medium transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="btn-save-new-admin-pass"
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-amber-900/40 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save New Admin Password</span>
              </button>
            </div>
          </form>
        )}
      </div>

      {/* 2. EMPLOYEE ROSTER & CREDENTIALS TABLE */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Users className="w-3.5 h-3.5 text-pink-400" />
            Registered Staff & Employee Profiles ({employees.length})
          </h4>
          <span className="text-[11px] text-slate-400">
            Each staff member logs in with their unique password or PIN
          </span>
        </div>

        <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-white/10 border-b border-white/10 font-semibold text-slate-300 text-[11px] uppercase">
              <tr>
                <th className="p-3.5">Employee / Staff Name</th>
                <th className="p-3.5">Designation / Role</th>
                <th className="p-3.5">Contact Phone</th>
                <th className="p-3.5">Login Password / PIN</th>
                <th className="p-3.5">Permitted Modules</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody id="employee-table-rows" className="divide-y divide-white/5 text-slate-200">
              {employees.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No staff members added yet. Click "+ Add New Employee" to register staff and set passwords.
                  </td>
                </tr>
              ) : (
                employees.map(e => {
                  const isRevealed = !!revealedStaffPasses[e.id];
                  const rawPass = e.pass || e.pin || '1234';

                  return (
                    <tr key={e.id} className="hover:bg-white/5 transition">
                      <td className="p-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg bg-pink-500/20 text-pink-300 font-bold flex items-center justify-center text-xs">
                            {e.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-white block">{e.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono">ID: {e.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-300 font-medium">{e.desig}</td>
                      <td className="p-3.5">
                        {e.phone ? (
                          <span className="text-slate-200 font-mono flex items-center gap-1.5">
                            <Phone className="w-3 h-3 text-pink-400" />
                            <span>{e.phone}</span>
                          </span>
                        ) : (
                          <span className="text-slate-500 italic">--</span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-2.5 py-1 rounded-xl w-fit">
                          <KeyRound className="w-3 h-3 text-amber-400" />
                          <span className="font-mono text-xs font-bold text-amber-300">
                            {isRevealed ? rawPass : '••••'}
                          </span>
                          <button
                            type="button"
                            onClick={() => toggleRevealStaffPass(e.id)}
                            className="text-slate-400 hover:text-white p-0.5 ml-1 transition"
                            title={isRevealed ? 'Hide password' : 'Show password'}
                          >
                            {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span className="bg-white/10 text-slate-200 border border-white/10 px-3 py-1 rounded-full font-medium text-[11px]">
                          {e.permissions.length} Modules Assigned
                        </span>
                      </td>
                      <td className="p-3.5 text-center space-x-2">
                        <button
                          onClick={() => onOpenEditEmployeeModal(e)}
                          className="text-indigo-300 font-semibold hover:text-white bg-indigo-500/20 hover:bg-indigo-500/30 px-3 py-1.5 rounded-xl border border-indigo-500/30 transition backdrop-blur-sm cursor-pointer"
                        >
                          Edit & Password
                        </button>
                        <button
                          onClick={() => onDeleteEmployee(e.id)}
                          className="text-rose-300 font-semibold hover:text-white bg-rose-500/20 hover:bg-rose-500/30 px-3 py-1.5 rounded-xl border border-rose-500/30 transition backdrop-blur-sm cursor-pointer"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
