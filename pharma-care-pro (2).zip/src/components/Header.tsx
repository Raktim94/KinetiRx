import React from 'react';
import { Calendar, Menu, PlusCircle, Sparkles, User, Zap } from 'lucide-react';
import { CurrentUser, TabId } from '../types';

interface HeaderProps {
  currentTab: TabId;
  currentUser?: CurrentUser;
  currentUserName?: string;
  onOpenMobileMenu?: () => void;
  onOpenNewBill?: () => void;
  onOpenAddStock?: () => void;
  onOpenAIFinder?: () => void;
  onOpenLoginModal?: () => void;
  todayDate?: string;
}

const tabTitles: Record<string, { title: string; subtitle: string }> = {
  dashboard: { title: 'Dashboard & Analytics', subtitle: 'ড্যাশবোর্ড ও সতর্কতা' },
  'daily-calc': { title: 'Daily Sales & Drawer Register', subtitle: 'দৈনিক সেলস ও ক্যাশ ড্রয়ার' },
  'daily-sales': { title: 'Daily Sales & Drawer Register', subtitle: 'দৈনিক সেলস ও ক্যাশ ড্রয়ার' },
  pos: { title: 'Smart Pharmacy & Lab POS', subtitle: 'কাউন্টার বিলিং ও ইনভয়েস' },
  'due-khata': { title: 'Patient Due Register', subtitle: 'রোগীদের বাকি খাতা ও রিমাইন্ডার' },
  opd: { title: 'OPD & Re-visit Clinical Register', subtitle: 'ওপিডি ভিজিট ও ফলো-আপ' },
  patients: { title: 'Patient Database Profiles', subtitle: 'রোগী ডেটাবেস ও হিস্ট্রি' },
  'medicine-orders': { title: 'Special Medicine Need Orders', subtitle: 'জরুরি ওষুধ সংগ্রহ খাতা' },
  inventory: { title: 'Medicine Stock Management', subtitle: 'ওষুধের স্টক, র্যাক ও ডিস্ট্রিবিউটর' },
  inward: { title: 'Supplier Purchase Bill Auto-Scan (OCR)', subtitle: 'ডিলার চালান স্ক্যান ও অটো-স্টক' },
  'inward-ocr': { title: 'Supplier Purchase Bill Auto-Scan (OCR)', subtitle: 'ডিলার চালান স্ক্যান ও অটো-স্টক' },
  expenses: { title: 'Daily Expenditure Register', subtitle: 'দৈনিক খরচ ও ভাউচার' },
  'business-dev': { title: 'Business Dev & Doctor Marketing', subtitle: 'ডাক্তার প্রচার ও কাজের তালিকা' },
  'employee-mgmt': { title: 'Employee Control & Module Access', subtitle: 'কর্মচারী ও পারমিশন কন্ট্রোল' },
  'invoice-settings': { title: 'Invoice & WhatsApp Settings', subtitle: 'দোকানের নাম ও বিল সেটিংস' },
  'system-reset': { title: 'System Factory Reset & 5-Day Backup', subtitle: 'সিস্টেম রিসেট ও ৫ দিনের ব্যাকআপ' },
};

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  currentUser,
  currentUserName,
  onOpenMobileMenu,
  onOpenNewBill,
  onOpenAddStock,
  onOpenAIFinder,
  onOpenLoginModal,
  todayDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }),
}) => {
  const currentInfo = tabTitles[currentTab] || { title: 'Pharma Care Pro', subtitle: '' };
  const displayName = currentUser?.name || currentUserName || 'Admin (Director)';
  const isSuperAdmin = currentUser ? currentUser.role === 'admin' : true;

  return (
    <header
      id="app-header"
      className="bg-white/5 backdrop-blur-2xl border-b border-white/10 px-4 sm:px-6 py-3 flex justify-between items-center shadow-lg shrink-0 z-20 text-slate-100"
    >
      <div className="flex items-center space-x-3">
        {onOpenMobileMenu && (
          <button
            id="open-mobile-menu-btn"
            onClick={onOpenMobileMenu}
            className="p-2 rounded-xl text-slate-300 hover:bg-white/10 lg:hidden transition border border-white/10"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2 tracking-tight">
            <span>{currentInfo.title}</span>
            <span className="text-xs text-slate-400 font-normal hidden sm:inline">
              ({currentInfo.subtitle})
            </span>
          </h2>
          <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
            <User className="w-3 h-3 text-indigo-400" />
            <span>
              Active User:{' '}
              <strong className="text-indigo-300 font-medium">
                {displayName} ({isSuperAdmin ? 'Super Admin' : 'Staff'})
              </strong>
            </span>
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* AI Generic Finder */}
        {onOpenAIFinder && (
          <button
            id="header-ai-finder-btn"
            onClick={onOpenAIFinder}
            className="flex items-center gap-1.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 border border-indigo-500/40 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-900/30 backdrop-blur-md cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span className="hidden sm:inline">AI Medicine Finder</span>
            <span className="sm:hidden">AI Finder</span>
          </button>
        )}

        {/* Quick Action POS Bill */}
        {onOpenNewBill && (
          <button
            id="quick-new-bill-btn"
            onClick={onOpenNewBill}
            className="hidden md:flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-2.5 py-1.5 rounded-xl text-xs font-bold transition shadow-md backdrop-blur-md cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-emerald-400" />
            <span>+ Quick POS Bill</span>
          </button>
        )}

        {/* Quick Action Add Stock */}
        {onOpenAddStock && (
          <button
            id="quick-add-stock-btn"
            onClick={onOpenAddStock}
            className="hidden md:flex items-center gap-1.5 bg-white/10 hover:bg-white/15 text-slate-200 border border-white/15 px-2.5 py-1.5 rounded-xl text-xs font-bold transition backdrop-blur-md cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-indigo-300" />
            <span>+ Add Stock</span>
          </button>
        )}

        {/* Switch User Login Button */}
        {onOpenLoginModal && (
          <button
            id="header-switch-user-btn"
            onClick={onOpenLoginModal}
            className="text-xs text-slate-300 hover:text-white border border-white/10 px-2.5 py-1.5 rounded-xl font-medium hover:bg-white/10 transition backdrop-blur-md cursor-pointer"
          >
            Switch User
          </button>
        )}

        {/* Live Date Badge */}
        <div className="bg-white/5 border border-white/10 px-2.5 sm:px-3 py-1 rounded-xl text-xs font-medium text-slate-300 flex items-center gap-1.5 backdrop-blur-md">
          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-mono text-slate-200">{todayDate}</span>
        </div>
      </div>
    </header>
  );
};
