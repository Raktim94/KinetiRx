import React, { useState } from 'react';
import { Eye, EyeOff, Lock, LogIn, ShieldAlert, User, X } from 'lucide-react';
import { Employee } from '../../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  adminPass: string;
  onLoginSuccess: (userRole: 'admin' | string, userName: string) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  employees,
  adminPass,
  onLoginSuccess,
}) => {
  const [selectedRole, setSelectedRole] = useState<'admin' | string>('admin');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (selectedRole === 'admin') {
      if (password.trim() === adminPass.trim()) {
        onLoginSuccess('admin', 'Admin (Director)');
        onClose();
        setPassword('');
      } else {
        setError('Invalid Admin Master Password. Please enter the current saved password.');
      }
    } else {
      const emp = employees.find(e => e.id === selectedRole);
      if (emp && emp.pass.trim() === password.trim()) {
        onLoginSuccess(emp.id, emp.name);
        onClose();
        setPassword('');
      } else {
        setError('Invalid Employee PIN / Password. Please try again.');
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-sm w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Lock className="w-4 h-4" />
            </div>
            <span>Switch Active User / Terminal</span>
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="font-semibold text-slate-300 block mb-1.5">Select User Profile</label>
            <select
              value={selectedRole}
              onChange={e => {
                setSelectedRole(e.target.value);
                setError('');
              }}
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-2xl outline-none text-white focus:border-indigo-400 font-medium backdrop-blur-md"
            >
              <option value="admin" className="bg-slate-900 text-white">Admin / Pharmacy Owner (Full Access)</option>
              {employees.map(emp => (
                <option key={emp.id} value={emp.id} className="bg-slate-900 text-white">
                  {emp.name} ({emp.desig})
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="font-semibold text-slate-300">
                Enter Password / PIN
              </label>
              <span className="text-slate-400 text-[10px] font-mono">
                {selectedRole === 'admin'
                  ? adminPass === '1234'
                    ? '(Default: 1234)'
                    : '(Custom Admin Pass)'
                  : '(Staff PIN)'}
              </span>
            </div>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={e => {
                  setPassword(e.target.value);
                  setError('');
                }}
                placeholder="••••"
                className="w-full pl-4 pr-10 py-3 bg-white/5 border border-white/10 rounded-2xl font-mono text-center text-base font-bold text-white placeholder:text-slate-600 outline-none focus:border-indigo-400 focus:bg-white/10 tracking-widest backdrop-blur-md"
                autoFocus
                required
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                title={showPass ? 'Hide password' : 'Show password'}
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium rounded-2xl text-xs flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-lg shadow-indigo-950/40 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Authorize & Sign In</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
