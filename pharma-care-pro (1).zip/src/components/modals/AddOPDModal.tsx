import React, { useState, useEffect } from 'react';
import { Plus, Stethoscope, X } from 'lucide-react';
import { OPDVisit, PatientRecord } from '../../types';
import {
  findPatientById,
  findPatientByPhone,
  getNextSequentialPatientId,
} from '../../utils/patientUtils';

interface AddOPDModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveOPD: (visit: OPDVisit) => void;
  patients?: PatientRecord[];
  onQuickAddPatient?: (patient: PatientRecord) => void;
}

export const AddOPDModal: React.FC<AddOPDModalProps> = ({
  isOpen,
  onClose,
  onSaveOPD,
  patients = [],
  onQuickAddPatient,
}) => {
  const [patientId, setPatientId] = useState(() => getNextSequentialPatientId(patients));
  const [name, setName] = useState('');
  const [ageSex, setAgeSex] = useState('45 / Male');
  const [phone, setPhone] = useState('');
  const [doc, setDoc] = useState('Dr. Sayan Majumdar');
  const [vdate, setVdate] = useState(() => new Date().toISOString().slice(0, 10));
  const [rvdate, setRvdate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  });
  const [btest, setBtest] = useState('CBC + Blood Sugar (F/PP)');
  const [matchedPatient, setMatchedPatient] = useState<PatientRecord | null>(null);

  // Sync next sequential patient ID whenever the modal opens
  useEffect(() => {
    if (isOpen) {
      if (!phone.trim() && !matchedPatient) {
        setPatientId(getNextSequentialPatientId(patients));
      }
    }
  }, [isOpen, patients]);

  if (!isOpen) return null;

  // Auto-fetch patient info when mobile number changes
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPhone(val);

    const match = findPatientByPhone(val, patients);
    if (match) {
      setMatchedPatient(match);
      setPatientId(match.id || getNextSequentialPatientId(patients));
      setName(match.name || '');
      if (match.age || match.gender) {
        setAgeSex(`${match.age || 45} / ${match.gender || 'Male'}`);
      } else if (match.ageGender) {
        setAgeSex(match.ageGender);
      }
      if (match.doc && match.doc !== 'Self Prescribed / OTC') {
        setDoc(match.doc);
      } else if (match.doctor && match.doctor !== 'Self Prescribed / OTC') {
        setDoc(match.doctor);
      }
    } else {
      setMatchedPatient(null);
      // Automatically assign next sequential series ID for new mobile
      setPatientId(getNextSequentialPatientId(patients));
    }
  };

  // Auto-fetch patient info if Patient ID is entered or altered
  const handlePatientIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPatientId(val);

    const match = findPatientById(val, patients);
    if (match) {
      setMatchedPatient(match);
      setName(match.name || '');
      if (match.phone && match.phone !== 'N/A') setPhone(match.phone);
      if (match.age || match.gender) {
        setAgeSex(`${match.age || 45} / ${match.gender || 'Male'}`);
      } else if (match.ageGender) {
        setAgeSex(match.ageGender);
      }
      if (match.doc && match.doc !== 'Self Prescribed / OTC') {
        setDoc(match.doc);
      } else if (match.doctor && match.doctor !== 'Self Prescribed / OTC') {
        setDoc(match.doctor);
      }
    } else {
      setMatchedPatient(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (!phone.trim()) {
      alert('Please enter patient mobile number');
      return;
    }

    const finalPatientId = patientId.trim() || getNextSequentialPatientId(patients);

    const newVisit: OPDVisit = {
      id: 'OPD-' + Date.now(),
      patientId: finalPatientId,
      name: name.trim(),
      phone: phone.trim(),
      ageSex: ageSex.trim(),
      doc,
      vdate,
      rvdate,
      btest: btest.trim() || 'None',
      reminder: '3-4 Days Advance',
    };

    // If new patient profile does not already exist in master registry, register it
    if (!matchedPatient && onQuickAddPatient) {
      const parts = ageSex.split('/');
      const parsedAge = parseInt(parts[0], 10) || 45;
      const parsedGender = parts[1] ? parts[1].trim() : 'Male';

      const newPatientRec: PatientRecord = {
        id: finalPatientId,
        name: name.trim(),
        phone: phone.trim(),
        age: parsedAge,
        gender: parsedGender,
        ageGender: ageSex.trim(),
        addr: 'Local Area',
        address: 'Local Area',
        doc,
        doctor: doc,
        reason: `OPD Consultation: ${doc} (${vdate})`,
        totalDue: 0,
        dueAmount: 0,
        lastDate: vdate,
        lastVisitDate: vdate,
        totalVisits: 1,
      };

      onQuickAddPatient(newPatientRec);
    }

    onSaveOPD(newVisit);
    onClose();
    setName('');
    setPhone('');
    setMatchedPatient(null);
    setPatientId(getNextSequentialPatientId(patients));
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Stethoscope className="w-4 h-4" />
            </div>
            <span>Record OPD Patient Consultation (ওপিডি রোগী)</span>
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Row 1: Mobile & Patient ID (Auto-Sequential & Auto-Fetch) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="font-medium text-slate-300 block mb-1">
                Patient Mobile Number <span className="text-slate-500 font-normal">(মোবাইল)</span> *
              </label>
              <input
                type="text"
                id="opd-patient-phone"
                value={phone}
                onChange={handlePhoneChange}
                placeholder="10-digit mobile number"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-white placeholder:text-slate-500 outline-none focus:border-sky-400 focus:bg-white/10"
                required
                autoFocus
              />
            </div>

            <div>
              <label className="font-medium text-slate-300 block mb-1">
                Patient ID <span className="text-slate-500 font-normal">(অটো আইডি)</span>
              </label>
              <input
                type="text"
                id="opd-patient-id"
                value={patientId}
                onChange={handlePatientIdChange}
                placeholder="101"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-teal-300 placeholder:text-slate-500 outline-none focus:border-teal-400 focus:bg-white/10"
                title="Auto-generated sequential series Patient ID"
              />
            </div>
          </div>

          {/* Row 2: Name & Age/Gender */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="font-medium text-slate-300 block mb-1">
                Patient Full Name <span className="text-slate-500 font-normal">(রোগীর নাম)</span> *
              </label>
              <input
                type="text"
                id="opd-patient-name"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Kasida Bibi"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-sky-400 focus:bg-white/10 font-medium"
                required
              />
            </div>

            <div>
              <label className="font-medium text-slate-300 block mb-1">Age & Sex</label>
              <input
                type="text"
                id="opd-patient-agesex"
                value={ageSex}
                onChange={e => setAgeSex(e.target.value)}
                placeholder="e.g. 52 / Female"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-sky-400 focus:bg-white/10"
              />
            </div>
          </div>

          {/* Row 3: Assigned Doctor */}
          <div>
            <label className="font-medium text-slate-300 block mb-1">Assigned Doctor (ডাক্তার)</label>
            <select
              id="opd-doctor-select"
              value={doc}
              onChange={e => setDoc(e.target.value)}
              className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-sky-400 font-medium"
            >
              <option value="Dr. Sayan Majumdar">Dr. Sayan Majumdar (General Medicine)</option>
              <option value="Dr. T.K. Khan">Dr. T.K. Khan (Cardiologist)</option>
              <option value="Dr. Subhash Bose">Dr. Subhash Bose (Pediatrician)</option>
            </select>
          </div>

          {/* Row 4: Consultation Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 block mb-1">Visit Date</label>
              <input
                type="date"
                value={vdate}
                onChange={e => setVdate(e.target.value)}
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white outline-none focus:border-sky-400 focus:bg-white/10"
                required
              />
            </div>
            <div>
              <label className="font-medium text-slate-300 block mb-1">Next Re-visit Date</label>
              <input
                type="date"
                value={rvdate}
                onChange={e => setRvdate(e.target.value)}
                className="w-full p-2.5 bg-sky-500/10 border border-sky-500/30 rounded-xl font-mono font-bold text-sky-300 outline-none focus:border-sky-400"
                required
              />
            </div>
          </div>

          {/* Row 5: Tests Advised */}
          <div>
            <label className="font-medium text-slate-300 block mb-1">Blood / Lab Tests Advised</label>
            <input
              type="text"
              id="opd-tests-input"
              value={btest}
              onChange={e => setBtest(e.target.value)}
              placeholder="e.g. CBC, Sugar Fasting/PP, Lipid Profile"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-sky-400 focus:bg-white/10"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-2xl font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-2xl shadow-lg shadow-sky-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save OPD Patient</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
