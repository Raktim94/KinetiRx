import React, { useState, useEffect } from 'react';
import {
  Building2,
  CheckCircle2,
  Clock,
  Eye,
  EyeOff,
  Hospital,
  KeyRound,
  Lock,
  LogIn,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  User,
  Users,
} from 'lucide-react';
import { Employee, InvoiceConfig } from '../types';

interface TerminalLoginScreenProps {
  invoiceConfig: InvoiceConfig;
  employees: Employee[];
  adminPass: string;
  onLoginSuccess: (userRoleId: 'admin' | string, userName: string) => void;
}

export const TerminalLoginScreen: React.FC<TerminalLoginScreenProps> = ({
  invoiceConfig,
  employees,
  adminPass,
  onLoginSuccess,
}) => {
  const [selectedUserId, setSelectedUserId] = useState<'admin' | string>('admin');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Clock ticker for active terminal time
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Filter staff employees (exclude duplicate admin entries if any)
  const staffEmployees = employees.filter(
    e => e.role !== 'admin' && e.id !== 'admin' && e.id !== 'EMP-ADMIN-1' && e.id !== 'emp-admin-1'
  );

  const selectedEmployee =
    selectedUserId === 'admin'
      ? null
      : employees.find(e => e.id === selectedUserId);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanInputPass = password.trim();

    if (!cleanInputPass) {
      setErrorMessage('Please enter your password / security PIN.');
      return;
    }

    if (selectedUserId === 'admin') {
      const activeMasterPass = (adminPass || '1122').trim();
      // Allow current adminPass OR default master 1122
      if (cleanInputPass === activeMasterPass || cleanInputPass === '1122') {
        onLoginSuccess('admin', invoiceConfig.director || 'Admin (Director)');
      } else {
        setErrorMessage('Incorrect Admin Password. Please enter the valid master administrative password.');
      }
    } else {
      if (selectedEmployee) {
        const empPass = (selectedEmployee.pass || selectedEmployee.pin || '1234').trim();
        if (cleanInputPass === empPass) {
          onLoginSuccess(selectedEmployee.id, selectedEmployee.name);
        } else {
          setErrorMessage(
            `Incorrect PIN for ${selectedEmployee.name}. Please enter your assigned employee PIN.`
          );
        }
      } else {
        setErrorMessage('Selected user profile not found. Please choose a valid user.');
      }
    }
  };

  return (
    <div
      id="terminal-login-gateway"
      className="relative min-h-screen w-screen flex flex-col items-center justify-center bg-slate-950 font-sans text-slate-100 p-4 sm:p-6 overflow-y-auto selection:bg-indigo-500 selection:text-white"
    >
      {/* Dynamic Background Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-600/25 blur-[140px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-fuchsia-600/20 blur-[140px]" />
        <div className="absolute top-[30%] right-[20%] w-[35%] h-[35%] rounded-full bg-blue-600/15 blur-[120px]" />
      </div>

      {/* Main Terminal Login Card */}
      <div className="relative z-10 w-full max-w-xl bg-slate-900/90 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80 space-y-6">
        {/* Pharmacy Branding & Header */}
        <div className="text-center space-y-2 border-b border-white/10 pb-5">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-400 text-white shadow-xl shadow-indigo-500/30 mb-1 border border-white/20">
            <Hospital className="w-8 h-8" />
          </div>

          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            {invoiceConfig.storeName || invoiceConfig.name || 'PHARMA CARE PRO & DIAGNOSTIC CENTRE'}
          </h1>
          <p className="text-xs text-indigo-300 font-medium max-w-md mx-auto">
            {invoiceConfig.subtitle || 'Complete Healthcare, Pharmacy ERP & POS Solution'}
          </p>

          <div className="flex items-center justify-center gap-3 pt-2 text-[11px] text-slate-400 flex-wrap">
            <span className="bg-white/5 border border-white/10 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-mono">
              <Clock className="w-3 h-3 text-indigo-400" />
              {currentTime.toLocaleDateString('en-IN', {
                weekday: 'short',
                day: '2-digit',
                month: 'short',
                year: 'numeric',
              })}{' '}
              • {currentTime.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
            {invoiceConfig.dl && (
              <span className="bg-white/5 border border-white/10 px-2.5 py-1 rounded-full font-mono text-[10px]">
                DL: {invoiceConfig.dl}
              </span>
            )}
          </div>
        </div>

        {/* User Selection Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-400" />
              <span>Select User Profile (ইউজার নির্বাচন করুন)</span>
            </label>
            <span className="text-[11px] text-slate-400">Step 1 of 2</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-56 overflow-y-auto pr-1">
            {/* Primary Administrator Profile */}
            <button
              type="button"
              id="select-user-admin-btn"
              onClick={() => {
                setSelectedUserId('admin');
                setErrorMessage(null);
              }}
              className={`p-3.5 rounded-2xl border text-left transition flex items-start gap-3 cursor-pointer ${
                selectedUserId === 'admin'
                  ? 'bg-indigo-600/30 border-indigo-400 shadow-lg shadow-indigo-900/40 ring-2 ring-indigo-500/50'
                  : 'bg-white/5 border-white/10 hover:bg-white/10 text-slate-300'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  selectedUserId === 'admin'
                    ? 'bg-indigo-500 text-white'
                    : 'bg-white/10 text-slate-400'
                }`}
              >
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs truncate">
                    {invoiceConfig.director || 'Admin / Owner'}
                  </span>
                  {selectedUserId === 'admin' && (
                    <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                  )}
                </div>
                <span className="text-[10px] text-indigo-300 font-semibold block">
                  Director • Full Access
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5 block font-mono">
                  Master Security Access
                </span>
              </div>
            </button>

            {/* Staff / Employee Profiles */}
            {staffEmployees.map(emp => {
              const isSelected = selectedUserId === emp.id;
              return (
                <button
                  key={emp.id}
                  type="button"
                  id={`select-user-${emp.id}-btn`}
                  onClick={() => {
                    setSelectedUserId(emp.id);
                    setErrorMessage(null);
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-600/30 border-sky-400 shadow-lg shadow-sky-900/40 ring-2 ring-sky-500/50'
                      : 'bg-white/5 border-white/10 hover:bg-white/10 text-slate-300'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-sky-500 text-white'
                        : 'bg-white/10 text-slate-400'
                    }`}
                  >
                    <User className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs truncate">
                        {emp.name}
                      </span>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                      )}
                    </div>
                    <span className="text-[10px] text-sky-300 font-medium block truncate">
                      {emp.desig || 'Staff Member'}
                    </span>
                    <span className="text-[9px] text-slate-400 mt-0.5 block font-mono">
                      {emp.permissions?.length || 0} Modules Allowed
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Password / PIN Input Form */}
        <form onSubmit={handleLoginSubmit} className="space-y-4 pt-1 border-t border-white/10">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label
                htmlFor="terminal-login-pass"
                className="text-xs font-bold text-slate-200 flex items-center gap-1.5"
              >
                <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                <span>
                  Enter {selectedUserId === 'admin' ? 'Master Admin Password' : 'Staff PIN'}{' '}
                  (পাসওয়ার্ড লিখুন)
                </span>
              </label>

              <span className="text-[10px] text-slate-400 font-mono">
                {selectedUserId === 'admin' ? 'Master Password' : 'Staff PIN'}
              </span>
            </div>

            <div className="relative">
              <input
                id="terminal-login-pass"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => {
                  setPassword(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder="••••••••"
                className="w-full pl-4 pr-11 py-3.5 bg-white/5 border border-white/15 rounded-2xl font-mono text-center text-lg font-bold text-white placeholder:text-slate-600 outline-none focus:border-indigo-400 focus:bg-white/10 tracking-widest transition shadow-inner"
                autoFocus
                required
              />
              <button
                type="button"
                id="toggle-pass-visibility-btn"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1.5 rounded-lg transition"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Feedback Notices */}
          {errorMessage && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 font-medium rounded-2xl text-xs flex items-center gap-2 animate-in fade-in duration-200">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
              <p className="flex-1 text-left">{errorMessage}</p>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            id="terminal-authorize-btn"
            className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-bold rounded-2xl shadow-xl shadow-indigo-950/50 transition flex items-center justify-center gap-2 cursor-pointer text-sm"
          >
            <LogIn className="w-4 h-4" />
            <span>Authorize & Enter Terminal (লগইন করুন)</span>
          </button>
        </form>

        {/* Footer Security Badges */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 flex-wrap gap-2">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Protected Multi-User Terminal</span>
          </div>

          <span className="font-mono text-[10px] text-slate-400">
            ERP Secure Gateway
          </span>
        </div>
      </div>
    </div>
  );
};
