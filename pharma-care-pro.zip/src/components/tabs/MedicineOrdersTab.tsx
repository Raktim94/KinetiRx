import React, { useState } from 'react';
import {
  Clock,
  Download,
  FileCheck2,
  Phone,
  Plus,
  Search,
  Truck,
  User,
  UserCheck,
} from 'lucide-react';
import { NeededMedOrder, PatientRecord } from '../../types';
import { exportToCSV } from '../../utils/exportCsv';

interface MedicineOrdersTabProps {
  neededMeds: NeededMedOrder[];
  setNeededMeds: React.Dispatch<React.SetStateAction<NeededMedOrder[]>>;
  onOpenAddNeedModal: () => void;
  patients?: PatientRecord[];
  onViewPatientProfile?: (p: PatientRecord) => void;
}

export const MedicineOrdersTab: React.FC<MedicineOrdersTabProps> = ({
  neededMeds,
  setNeededMeds,
  onOpenAddNeedModal,
  patients = [],
  onViewPatientProfile,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const handleUpdateStatus = (id: string, newStatus: NeededMedOrder['status']) => {
    setNeededMeds(prev =>
      prev.map(item => (item.id === id ? { ...item, status: newStatus } : item))
    );
  };

  const filteredOrders = neededMeds.filter(n => {
    const q = search.toLowerCase();
    const matchesSearch =
      !search ||
      n.med.toLowerCase().includes(q) ||
      n.name.toLowerCase().includes(q) ||
      (n.patientId && n.patientId.toLowerCase().includes(q)) ||
      n.phone.includes(search) ||
      n.dist.toLowerCase().includes(q);

    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleExportCSV = () => {
    exportToCSV(
      'special_medicine_orders',
      [
        'Order ID',
        'Patient ID',
        'Medicine Required',
        'Patient Name',
        'Phone Number',
        'Supplier / Distributor',
        'Quantity',
        'Commitment Delivery Time',
        'Order Status',
      ],
      neededMeds.map(n => [
        n.id,
        n.patientId || 'N/A',
        n.med,
        n.name,
        n.phone,
        n.dist,
        n.qty,
        n.time,
        n.status,
      ])
    );
  };

  const handlePatientClick = (patientId?: string) => {
    if (!patientId || !onViewPatientProfile) return;
    const found = patients.find(p => p.id === patientId);
    if (found) {
      onViewPatientProfile(found);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="p-6 rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-white/15 shadow-2xl flex justify-between items-center flex-wrap gap-4 text-slate-100">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <span>Special Medicine Need Orders (জরুরি ওষুধ বুকিং)</span>
            </h2>
            <span className="bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-mono px-3 py-0.5 rounded-full font-bold">
              {neededMeds.length} Orders
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Manage out-of-stock emergency patient prescriptions linked with Patient Profiles and assigned to distributors with promised delivery deadlines.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-semibold px-3.5 py-2 rounded-2xl text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export Excel</span>
          </button>

          <button
            id="btn-add-need-order"
            onClick={onOpenAddNeedModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Note Special Medicine Order</span>
          </button>
        </div>
      </div>

      {/* SEARCH & FILTERS */}
      <div className="flex justify-between items-center gap-3 flex-wrap bg-white/5 p-3 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by Patient ID (e.g. P/101), Patient Name, Medicine, Phone, or Distributor..."
            className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-white/10 rounded-xl text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-medium">Status:</label>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="p-2 rounded-xl text-xs font-semibold bg-slate-900 border border-white/15 text-white outline-none focus:border-indigo-400"
          >
            <option value="all">All Statuses</option>
            <option value="Distributor Ordered">Distributor Ordered</option>
            <option value="Processing">Processing</option>
            <option value="Pending">Pending</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* ORDERS TABLE */}
      <div className="bg-slate-900/90 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-2xl overflow-hidden text-xs text-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white/10 border-b border-white/10 text-[11px] font-bold text-slate-300 uppercase backdrop-blur-md">
              <tr>
                <th className="p-3.5">Medicine Required</th>
                <th className="p-3.5">Patient Details (রোগীর তথ্য)</th>
                <th className="p-3.5">Distributor Assigned</th>
                <th className="p-3.5 text-emerald-400 font-bold">Commitment Delivery Time</th>
                <th className="p-3.5 text-center">Quantity</th>
                <th className="p-3.5">Order Status</th>
              </tr>
            </thead>
            <tbody id="need-med-rows" className="divide-y divide-white/5 text-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No special need medicine orders found. Click "+ Note Special Medicine Order" to create one.
                  </td>
                </tr>
              ) : (
                filteredOrders.map(n => (
                  <tr key={n.id} className="hover:bg-white/5 transition">
                    <td className="p-3.5 font-bold text-white text-sm">
                      {n.med}
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {n.patientId ? (
                          <button
                            onClick={() => handlePatientClick(n.patientId)}
                            className="font-mono text-xs font-bold text-teal-300 bg-teal-500/15 border border-teal-500/30 px-1.5 py-0.5 rounded hover:bg-teal-500/25 transition cursor-pointer"
                            title="Click to view Patient Profile CV"
                          >
                            {n.patientId}
                          </button>
                        ) : (
                          <span className="font-mono text-[10px] text-slate-400 bg-white/10 px-1.5 py-0.5 rounded">
                            Walk-in
                          </span>
                        )}
                        <span className="font-bold text-slate-200">{n.name}</span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                        Ph: {n.phone}
                      </span>
                    </td>
                    <td className="p-3.5 font-semibold text-indigo-300">
                      <div className="flex items-center gap-1.5">
                        <Truck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span>{n.dist}</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-emerald-300 font-bold">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{n.time}</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-center font-bold font-mono">
                      <span className="bg-white/10 text-slate-200 px-2.5 py-1 rounded-lg border border-white/10">
                        {n.qty} Units
                      </span>
                    </td>
                    <td className="p-3.5">
                      <select
                        value={n.status}
                        onChange={e =>
                          handleUpdateStatus(
                            n.id,
                            e.target.value as NeededMedOrder['status']
                          )
                        }
                        className={`p-2 rounded-xl font-bold text-xs bg-slate-900 border text-white outline-none focus:border-indigo-400 ${
                          n.status === 'Delivered'
                            ? 'border-emerald-500/40 text-emerald-300'
                            : n.status === 'Processing'
                            ? 'border-amber-500/40 text-amber-300'
                            : n.status === 'Cancelled'
                            ? 'border-rose-500/40 text-rose-300'
                            : 'border-white/15'
                        }`}
                      >
                        <option value="Distributor Ordered">Distributor Ordered</option>
                        <option value="Processing">Processing</option>
                        <option value="Pending">Pending</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
