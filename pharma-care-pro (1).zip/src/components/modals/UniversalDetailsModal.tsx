import React, { useState } from 'react';
import {
  AlertTriangle,
  Banknote,
  Boxes,
  Calendar,
  CheckCircle2,
  Clock,
  Coins,
  DollarSign,
  Edit3,
  FileSpreadsheet,
  FileText,
  Filter,
  HandCoins,
  MessageCircle,
  Package,
  Phone,
  Printer,
  Receipt,
  Search,
  Stethoscope,
  TrendingUp,
  Truck,
  User,
  Users,
  Vault,
  Wallet,
  X,
} from 'lucide-react';
import {
  DailyRegister,
  ExpenseRecord,
  Medicine,
  OPDVisit,
  PatientDue,
  PatientRecord,
  SalesRecord,
} from '../../types';
import { formatWhatsAppPhone } from '../../utils/exportCsv';

export type ModalType =
  | 'expiry'
  | 'revisit'
  | 'revisits'
  | 'due_list'
  | 'total_due'
  | 'sales_list'
  | 'today_sales'
  | 'cash_drawer'
  | 'drawer_cash'
  | 'stock_skus'
  | 'patient_cv'
  | null;

interface UniversalDetailsModalProps {
  type: ModalType;
  onClose: () => void;
  medicines: Medicine[];
  opdVisits: OPDVisit[];
  patientsDue: (PatientDue | PatientRecord)[];
  salesHistory: SalesRecord[];
  dailyRegister: DailyRegister;
  expenses: ExpenseRecord[];
  selectedPatient?: PatientRecord | null;
  onSelectPatientById?: (patientId: string) => void;
  onEditPatient?: (patient: PatientRecord) => void;
  onCollectDue?: (patientId: string) => void;
}

export const UniversalDetailsModal: React.FC<UniversalDetailsModalProps> = ({
  type,
  onClose,
  medicines,
  opdVisits,
  patientsDue,
  salesHistory,
  dailyRegister,
  expenses,
  selectedPatient,
  onSelectPatientById,
  onEditPatient,
  onCollectDue,
}) => {
  if (!type) return null;

  const [searchTerm, setSearchTerm] = useState('');

  // 1. Short expiry list (<= 6 months from mid-2026, e.g. <= 2026-12)
  const expiringMeds = medicines
    .filter(m => m.expiry && m.expiry <= '2026-12')
    .filter(m => m.name.toLowerCase().includes(searchTerm.toLowerCase()) || (m.batch || '').toLowerCase().includes(searchTerm.toLowerCase()));

  // 2. OPD revisits
  const upcomingRevisits = opdVisits
    .filter(v => v.rvdate && v.rvdate >= '2026-08-17')
    .filter(v => v.name.toLowerCase().includes(searchTerm.toLowerCase()) || (v.doc || '').toLowerCase().includes(searchTerm.toLowerCase()));

  // 3. Due list
  const dueList = patientsDue
    .map((p: any) => ({
      id: p.id,
      name: p.name || 'Unknown Patient',
      phone: p.phone || 'N/A',
      addr: p.addr || p.address || 'Local',
      doc: p.doc || 'General OPD',
      due: Number(p.dueAmount !== undefined ? p.dueAmount : (p.totalDue !== undefined ? p.totalDue : (p.due || 0))),
    }))
    .filter(p => p.due > 0)
    .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.phone.includes(searchTerm));

  const totalDueSum = dueList.reduce((sum, p) => sum + p.due, 0);

  // 4. Sales list
  const salesList = salesHistory
    .filter(s => {
      const q = searchTerm.toLowerCase();
      return (
        (s.inv || s.invoiceNo || '').toLowerCase().includes(q) ||
        (s.cust || s.patient || s.name || '').toLowerCase().includes(q) ||
        (s.items || '').toLowerCase().includes(q)
      );
    });

  const totalSalesSum = salesList.reduce((sum, s) => sum + (Number(s.total || s.amt) || 0), 0);

  // 5. Cash drawer calculations
  const openingBD = dailyRegister.prevBD ?? dailyRegister.openingCash ?? 1200;
  const grossTodaySales = dailyRegister.todaySell ?? totalSalesSum;
  const phonePeOnline = dailyRegister.phonePe ?? dailyRegister.upiSales ?? 225;
  const recordedExpenses = dailyRegister.expenses ?? 640;
  const bankDeposit = dailyRegister.bankShift ?? 600;

  const totalCashSales = salesHistory
    .filter(s => s.mode === 'Cash' || s.mode.toLowerCase().includes('cash'))
    .reduce((sum, s) => sum + (Number(s.paidAmount !== undefined ? s.paidAmount : (s.total || s.amt)) || 0), 0);

  const totalUpiSales = salesHistory
    .filter(s => s.mode === 'PhonePe' || s.mode.toLowerCase().includes('upi') || s.mode.toLowerCase().includes('online'))
    .reduce((sum, s) => sum + (Number(s.paidAmount !== undefined ? s.paidAmount : (s.total || s.amt)) || 0), 0);

  const totalExpenseSum = expenses.reduce((sum, e) => sum + (Number(e.amt) || 0), 0);
  const netDrawerCash = Math.max(0, openingBD + grossTodaySales - phonePeOnline - recordedExpenses - bankDeposit);

  // 6. Stock SKUs
  const filteredMeds = medicines.filter(
    m =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.generic || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.category || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.rack || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-3xl w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 max-h-[90vh] flex flex-col justify-between animate-in zoom-in-95">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-white/10 pb-3 flex-wrap gap-2">
          {type === 'expiry' && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Short Expiry Batches Alert (≤ 6 Months)</h3>
                <p className="text-[11px] text-slate-400">
                  {expiringMeds.length} medicines expiring before December 2026.
                </p>
              </div>
            </div>
          )}

          {(type === 'revisit' || type === 'revisits') && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Upcoming OPD Clinical Re-visits</h3>
                <p className="text-[11px] text-slate-400">
                  {upcomingRevisits.length} scheduled patients for clinical follow-up.
                </p>
              </div>
            </div>
          )}

          {(type === 'due_list' || type === 'total_due') && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Receipt className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Customer Due Khata Ledger (বাকির তালিকা)</h3>
                <p className="text-[11px] text-rose-300 font-bold">
                  Total Outstanding Balance: ₹ {totalDueSum.toFixed(2)} ({dueList.length} Patients)
                </p>
              </div>
            </div>
          )}

          {(type === 'sales_list' || type === 'today_sales') && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Coins className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Itemized Sales History & Invoices</h3>
                <p className="text-[11px] text-indigo-300 font-bold">
                  Total Billed Revenue: ₹ {totalSalesSum.toFixed(2)} ({salesList.length} Transactions)
                </p>
              </div>
            </div>
          )}

          {(type === 'cash_drawer' || type === 'drawer_cash') && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Vault className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Daily Cash Drawer Reconciliation</h3>
                <p className="text-[11px] text-emerald-300 font-bold">
                  Closing Cash In Drawer: ₹ {netDrawerCash.toFixed(2)}
                </p>
              </div>
            </div>
          )}

          {type === 'stock_skus' && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Boxes className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Pharmacy Stock SKUs & Inventory</h3>
                <p className="text-[11px] text-blue-300 font-bold">
                  {medicines.length} Registered Pharmaceutical Products
                </p>
              </div>
            </div>
          )}

          {type === 'patient_cv' && selectedPatient && (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Patient Medical Profile: {selectedPatient.name}</h3>
                <p className="text-[11px] text-slate-400 font-mono">
                  ID: {selectedPatient.id} • Phone: {selectedPatient.phone}
                </p>
              </div>
            </div>
          )}

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar for tabular views */}
        {type !== 'cash_drawer' && type !== 'drawer_cash' && type !== 'patient_cv' && (
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search by name, invoice #, phone, batch, or doctor..."
              className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-2xl text-xs text-white outline-none focus:border-indigo-400 transition"
            />
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto pr-1">
          {/* 1. EXPIRY LIST */}
          {type === 'expiry' && (
            <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/10 text-amber-300 font-bold border-b border-white/10 sticky top-0 text-[11px]">
                  <tr>
                    <th className="p-3">Medicine Name</th>
                    <th className="p-3">Distributor</th>
                    <th className="p-3">Batch / Rack</th>
                    <th className="p-3">Stock Units</th>
                    <th className="p-3 font-bold text-rose-400">Expiry Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {expiringMeds.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">
                        No short-expiry medicines found matching your search.
                      </td>
                    </tr>
                  ) : (
                    expiringMeds.map(m => (
                      <tr key={m.id} className="hover:bg-white/5 transition">
                        <td className="p-3 font-bold text-white">{m.name}</td>
                        <td className="p-3 text-indigo-300">{m.dist || 'Local Agency'}</td>
                        <td className="p-3 font-mono">
                          <span className="text-sky-300 font-bold">{m.batch}</span>
                          <span className="block text-slate-400 text-[10px]">{m.rack}</span>
                        </td>
                        <td className="p-3 font-bold font-mono text-slate-200">{m.stock} Units</td>
                        <td className="p-3 font-mono font-bold text-rose-400 bg-rose-500/10">
                          {m.expiry}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* 2. OPD REVISITS */}
          {(type === 'revisit' || type === 'revisits') && (
            <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/10 text-emerald-300 font-bold border-b border-white/10 sticky top-0 text-[11px]">
                  <tr>
                    <th className="p-3">Patient Name</th>
                    <th className="p-3">Doctor Assigned</th>
                    <th className="p-3">Phone Number</th>
                    <th className="p-3">Next Re-visit</th>
                    <th className="p-3">Tests Advised</th>
                    <th className="p-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {upcomingRevisits.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        No upcoming OPD patient revisit records found.
                      </td>
                    </tr>
                  ) : (
                    upcomingRevisits.map(v => (
                      <tr key={v.id} className="hover:bg-white/5 transition">
                        <td className="p-3">
                          <span className="font-bold text-white block">{v.name}</span>
                          <span className="text-[10px] text-slate-400">{v.ageSex}</span>
                        </td>
                        <td className="p-3 font-semibold text-slate-200">{v.doc}</td>
                        <td className="p-3 font-mono text-slate-300">{v.phone}</td>
                        <td className="p-3 font-mono font-bold text-emerald-400 bg-emerald-500/10">
                          {v.rvdate}
                        </td>
                        <td className="p-3 text-slate-300 text-[11px]">{v.btest || 'None'}</td>
                        <td className="p-3 text-center">
                          <a
                            href={`https://wa.me/${v.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `Hello ${v.name}, this is a gentle reminder from Pharma Care Pro for your OPD clinical revisit with ${v.doc} scheduled on ${v.rvdate}. Recommended Tests: ${v.btest || 'Routine Checkup'}.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-[10px] inline-flex items-center gap-1 shadow-md shadow-emerald-950/40 transition"
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </a>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* 3. DUE LIST */}
          {(type === 'due_list' || type === 'total_due') && (
            <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/10 text-rose-300 font-bold border-b border-white/10 sticky top-0 text-[11px]">
                  <tr>
                    <th className="p-3">Patient Name</th>
                    <th className="p-3">Phone Number</th>
                    <th className="p-3">Address</th>
                    <th className="p-3 font-bold text-rose-400 text-right">Outstanding Due</th>
                    <th className="p-3 text-center">Reminder</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {dueList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400">
                        No outstanding patient dues recorded.
                      </td>
                    </tr>
                  ) : (
                    dueList.map(p => (
                      <tr key={p.id} className="hover:bg-white/5 transition">
                        <td className="p-3 font-bold text-white">{p.name}</td>
                        <td className="p-3 font-mono text-slate-300">{p.phone}</td>
                        <td className="p-3 text-slate-400">{p.addr}</td>
                        <td className="p-3 font-mono font-bold text-rose-400 text-right text-sm">
                          ₹ {p.due.toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <a
                            href={`https://wa.me/${p.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `Dear ${p.name}, greeting from Pharma Care Pro. Your pending medical due balance is Rs. ${p.due.toFixed(2)}. Kindly clear at your convenience.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-[10px] inline-flex items-center gap-1 shadow-md shadow-emerald-950/40 transition"
                          >
                            <MessageCircle className="w-3 h-3" />
                            <span>WhatsApp</span>
                          </a>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* 4. SALES LIST */}
          {(type === 'sales_list' || type === 'today_sales') && (
            <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/10 text-slate-300 font-bold border-b border-white/10 sticky top-0 text-[11px]">
                  <tr>
                    <th className="p-3">Inv #</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Customer / Patient</th>
                    <th className="p-3">Items Sold</th>
                    <th className="p-3">Payment Mode</th>
                    <th className="p-3 font-bold text-white text-right">Bill Total (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {salesList.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        No sales transactions recorded matching your search.
                      </td>
                    </tr>
                  ) : (
                    salesList.map(s => (
                      <tr key={s.id} className="hover:bg-white/5 transition">
                        <td className="p-3 font-mono font-bold text-indigo-300">
                          {s.inv || s.invoiceNo || `#${s.id}`}
                        </td>
                        <td className="p-3 font-mono text-slate-400">{s.date}</td>
                        <td className="p-3">
                          <span className="font-bold text-white block">{s.cust || s.patient || s.name || 'Walk-in'}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{s.phone || 'N/A'}</span>
                        </td>
                        <td className="p-3 text-slate-300 max-w-[200px] truncate">{s.items || s.name}</td>
                        <td className="p-3">
                          <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full text-[10px] font-semibold">
                            {s.mode}
                          </span>
                        </td>
                        <td className="p-3 font-mono font-bold text-white text-right">
                          ₹ {Number(s.total || s.amt || 0).toFixed(2)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* 5. CASH DRAWER BREAKDOWN */}
          {(type === 'cash_drawer' || type === 'drawer_cash') && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white/5 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Opening Cash Float (B/D)</span>
                  <h4 className="text-base font-bold text-white font-mono mt-1">
                    ₹ {openingBD.toFixed(2)}
                  </h4>
                </div>
                <div className="bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/20 backdrop-blur-md">
                  <span className="text-[10px] text-emerald-300 uppercase font-bold">+ Gross Sales Inflow</span>
                  <h4 className="text-base font-bold text-emerald-400 font-mono mt-1">
                    ₹ {grossTodaySales.toFixed(2)}
                  </h4>
                </div>
                <div className="bg-orange-500/10 p-4 rounded-2xl border border-orange-500/20 backdrop-blur-md">
                  <span className="text-[10px] text-orange-300 uppercase font-bold">- Deductions (Online+Exp+Bank)</span>
                  <h4 className="text-base font-bold text-orange-400 font-mono mt-1">
                    ₹ {(phonePeOnline + recordedExpenses + bankDeposit).toFixed(2)}
                  </h4>
                </div>
              </div>

              <div className="p-5 bg-gradient-to-r from-emerald-900/60 via-teal-900/60 to-emerald-900/60 border border-emerald-500/40 text-white rounded-3xl shadow-xl flex justify-between items-center flex-wrap gap-4">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-emerald-200 font-bold block">
                    Net Physical Cash Balance in Drawer
                  </span>
                  <h3 className="text-3xl font-extrabold font-mono text-emerald-400 mt-1">
                    ₹ {netDrawerCash.toFixed(2)}
                  </h3>
                </div>
                <div className="text-right text-xs">
                  <span className="text-[10px] text-emerald-200 block">Digital Split Recorded:</span>
                  <span className="text-xs font-mono font-bold text-white">
                    UPI/PhonePe: ₹{phonePeOnline.toFixed(2)} | Bank Shift: ₹{bankDeposit.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 6. STOCK SKUs */}
          {type === 'stock_skus' && (
            <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
              <table className="w-full text-left text-xs">
                <thead className="bg-white/10 text-blue-300 font-bold border-b border-white/10 sticky top-0 text-[11px]">
                  <tr>
                    <th className="p-3">Product Name</th>
                    <th className="p-3">Generic & Category</th>
                    <th className="p-3">Rack / Batch</th>
                    <th className="p-3 text-right">In-Hand Stock</th>
                    <th className="p-3 text-right">Purchase Rate (₹)</th>
                    <th className="p-3 text-right">MRP (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-200">
                  {filteredMeds.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        No medicines found matching your search.
                      </td>
                    </tr>
                  ) : (
                    filteredMeds.map(m => (
                      <tr key={m.id} className="hover:bg-white/5 transition">
                        <td className="p-3">
                          <span className="font-bold text-white block">{m.name}</span>
                          <span className="text-[10px] text-slate-400">{m.dist || 'Standard'}</span>
                        </td>
                        <td className="p-3">
                          <span className="text-slate-300 block">{m.generic}</span>
                          <span className="text-[10px] text-indigo-300 font-medium">{m.category}</span>
                        </td>
                        <td className="p-3 font-mono">
                          <span className="text-sky-300 font-bold">{m.rack}</span>
                          <span className="block text-[10px] text-slate-400">{m.batch}</span>
                        </td>
                        <td className="p-3 text-right font-mono font-bold">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[11px] ${
                              (m.stock || 0) <= 0
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : (m.stock || 0) <= 10
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'text-white'
                            }`}
                          >
                            {m.stock} Units
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono text-slate-300">
                          ₹ {(Number(m.rate) || Number(m.mrp || 0) * 0.7).toFixed(2)}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-emerald-400">
                          ₹ {Number(m.mrp || 0).toFixed(2)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* 7. PATIENT CV */}
          {type === 'patient_cv' && selectedPatient && (() => {
            // Match invoices from salesHistory for this patient
            const patientSales = salesHistory.filter(
              s =>
                (s.patientId && s.patientId.toLowerCase() === selectedPatient.id.toLowerCase()) ||
                (s.phone && selectedPatient.phone && s.phone === selectedPatient.phone) ||
                (s.cust && s.cust.toLowerCase() === selectedPatient.name.toLowerCase()) ||
                (s.patient && s.patient.toLowerCase() === selectedPatient.name.toLowerCase())
            );

            // Match OPD visits for this patient
            const patientOPD = opdVisits.filter(
              v =>
                (v.phone && selectedPatient.phone && v.phone === selectedPatient.phone) ||
                (v.name && v.name.toLowerCase() === selectedPatient.name.toLowerCase())
            );

            const dueAmt = Number(selectedPatient.totalDue || (selectedPatient as any).due || (selectedPatient as any).dueAmount || 0);

            const handleWhatsAppDueReminder = () => {
              if (!selectedPatient.phone) {
                alert('No phone number recorded for this patient');
                return;
              }
              const formatted = formatWhatsAppPhone(selectedPatient.phone);
              const msg = `Dear ${selectedPatient.name},\nThis is a gentle reminder regarding your outstanding medicine due balance of ₹${dueAmt.toFixed(2)} at Pearl Care Pharmacy (Patient ID: ${selectedPatient.id}).\nKindly clear the pending balance at your convenience.\nThank you!`;
              const url = `https://api.whatsapp.com/send?phone=${formatted}&text=${encodeURIComponent(msg)}`;
              window.open(url, '_blank');
            };

            return (
              <div className="space-y-4">
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl space-y-3 backdrop-blur-md">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Patient ID & Name:</span>
                      <span className="font-bold text-white block">{selectedPatient.name}</span>
                      <span className="font-mono text-xs text-teal-300 bg-teal-500/20 px-1.5 py-0.5 rounded font-bold inline-block mt-0.5">
                        {selectedPatient.id}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Mobile & Age:</span>
                      <span className="font-mono font-bold text-slate-200 block">{selectedPatient.phone}</span>
                      <span className="text-slate-400 text-[11px]">
                        {selectedPatient.age || '50'} Yrs &bull; {selectedPatient.gender || 'Male'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Address & Doctor:</span>
                      <span className="font-medium text-slate-200 block truncate" title={selectedPatient.addr || selectedPatient.address || 'Local Area'}>
                        {selectedPatient.addr || selectedPatient.address || 'Local Area'}
                      </span>
                      <span className="text-indigo-300 font-semibold text-[11px] block">
                        {selectedPatient.doc || selectedPatient.doctor || 'Self Prescribed / OTC'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-semibold">Due Register Balance:</span>
                      <span className={`font-bold font-mono text-base block ${dueAmt > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        ₹ {dueAmt.toFixed(2)}
                      </span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded inline-block mt-0.5 ${dueAmt > 0 ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                        {dueAmt > 0 ? 'DUE PENDING' : 'CLEAR / NO DUES'}
                      </span>
                    </div>
                  </div>

                  {/* Due Register Quick Actions */}
                  <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-white/10 text-xs">
                    <div className="flex items-center gap-2 flex-wrap">
                      {selectedPatient.phone && (
                        <a
                          href={`tel:${selectedPatient.phone}`}
                          className="bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition text-[11px]"
                        >
                          <Phone className="w-3.5 h-3.5" /> Call Patient
                        </a>
                      )}
                      {onEditPatient && (
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onEditPatient(selectedPatient);
                          }}
                          className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition text-[11px] cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-amber-400" /> Edit Profile
                        </button>
                      )}
                      {dueAmt > 0 && onCollectDue && (
                        <button
                          type="button"
                          onClick={() => {
                            onCollectDue(selectedPatient.id);
                          }}
                          className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition text-[11px] cursor-pointer"
                        >
                          <HandCoins className="w-3.5 h-3.5 text-rose-400" /> Collect Due
                        </button>
                      )}
                      {dueAmt > 0 && selectedPatient.phone && (
                        <button
                          type="button"
                          onClick={handleWhatsAppDueReminder}
                          className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition text-[11px] cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-400" /> Send Due Reminder
                        </button>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {selectedPatient.totalVisits || 1} Total Recorded Visits &bull; Last Date: {selectedPatient.lastDate || 'Recent'}
                    </span>
                  </div>

                  {selectedPatient.reason && (
                    <div className="pt-2 border-t border-white/10 text-[11px] text-slate-300 flex items-center gap-1.5">
                      <span className="text-slate-400 font-semibold">Clinical Note:</span>
                      <span>{selectedPatient.reason}</span>
                    </div>
                  )}
                </div>

                <div>
                  <h5 className="font-bold text-white mb-2 text-xs flex items-center justify-between">
                    <span>Pharmacy Purchase & Billing Invoices:</span>
                    <span className="text-[11px] font-normal text-slate-400">
                      {patientSales.length} Invoices Found
                    </span>
                  </h5>
                  <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-white/10 text-slate-300 font-bold border-b border-white/10 text-[11px]">
                        <tr>
                          <th className="p-2.5">Date</th>
                          <th className="p-2.5">Invoice #</th>
                          <th className="p-2.5">Medicines Dispensed</th>
                          <th className="p-2.5 text-center">Payment</th>
                          <th className="p-2.5 text-right">Bill Total (₹)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-slate-200">
                        {patientSales.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="p-4 text-center text-slate-400">
                              No prior POS sales recorded for this patient profile yet.
                            </td>
                          </tr>
                        ) : (
                          patientSales.map(s => (
                            <tr key={s.id} className="hover:bg-white/5 transition">
                              <td className="p-2.5 font-mono text-slate-400">{s.date}</td>
                              <td className="p-2.5 font-mono font-bold text-indigo-300">{s.inv || s.invoiceNo || s.id}</td>
                              <td className="p-2.5 text-slate-200">{s.items || s.name}</td>
                              <td className="p-2.5 text-center font-mono text-[11px] text-slate-300">{s.mode}</td>
                              <td className="p-2.5 font-mono font-bold text-white text-right">
                                ₹ {Number(s.amt || s.total || 0).toFixed(2)}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {patientOPD.length > 0 && (
                  <div>
                    <h5 className="font-bold text-white mb-2 text-xs">Doctor Consultations & OPD Visits:</h5>
                    <div className="overflow-x-auto border border-white/10 rounded-2xl bg-white/5 backdrop-blur-md">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-white/10 text-slate-300 font-bold border-b border-white/10 text-[11px]">
                          <tr>
                            <th className="p-2.5">Visit Date</th>
                            <th className="p-2.5">Doctor</th>
                            <th className="p-2.5">BP / Vitals</th>
                            <th className="p-2.5">Next Re-visit</th>
                            <th className="p-2.5 text-right">Fees (₹)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-slate-200">
                          {patientOPD.map(v => (
                            <tr key={v.id} className="hover:bg-white/5 transition">
                              <td className="p-2.5 font-mono text-slate-400">{v.date}</td>
                              <td className="p-2.5 font-bold text-indigo-300">{v.doc}</td>
                              <td className="p-2.5 font-mono text-slate-300">{v.bp || '--'} mmHg</td>
                              <td className="p-2.5 font-mono text-emerald-300">{v.rvdate || '--'}</td>
                              <td className="p-2.5 font-mono font-bold text-white text-right">
                                ₹ {Number(v.fee || 0).toFixed(2)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {selectedPatient.bloodTests && selectedPatient.bloodTests.length > 0 && (
                  <div className="p-4 bg-sky-500/10 border border-sky-500/20 rounded-2xl text-xs space-y-1.5 backdrop-blur-md">
                    <p className="font-bold text-sky-300">Advised Diagnostic Tests:</p>
                    <ul className="list-disc pl-4 text-sky-200 text-[11px] space-y-0.5">
                      {selectedPatient.bloodTests.map((t, idx) => (
                        <li key={idx}>{t}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            );
          })()}
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-3 border-t border-white/10">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white/10 hover:bg-white/15 text-slate-200 font-semibold rounded-2xl transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
