import React, { useState, useEffect } from 'react';
import {
  HeartPulse,
  MapPin,
  Phone,
  Plus,
  Stethoscope,
  User,
  UserPlus,
  X,
} from 'lucide-react';
import { PatientRecord } from '../../types';
import { getTodayISODate } from '../../utils/dateUtils';
import { loadDoctors } from '../../data/doctors';
import {
  findPatientById,
  findPatientByPhone,
  getNextSequentialPatientId,
} from '../../utils/patientUtils';

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePatient: (patient: PatientRecord) => void;
  existingPatients: PatientRecord[];
}

export const AddPatientModal: React.FC<AddPatientModalProps> = ({
  isOpen,
  onClose,
  onSavePatient,
  existingPatients,
}) => {
  const [patientId, setPatientId] = useState(() => getNextSequentialPatientId(existingPatients));
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('Male');
  const [addr, setAddr] = useState('');
  const [docSelect, setDocSelect] = useState('Self Prescribed / OTC');
  const [customDoc, setCustomDoc] = useState('');
  const [reason, setReason] = useState('');
  const [initialDue, setInitialDue] = useState('0');

  useEffect(() => {
    if (isOpen && !phone.trim()) {
      setPatientId(getNextSequentialPatientId(existingPatients));
    }
  }, [isOpen, existingPatients]);

  if (!isOpen) return null;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPhone(val);

    const match = findPatientByPhone(val, existingPatients);
    if (match) {
      setPatientId(match.id);
      setName(match.name || '');
      if (match.age) setAge(String(match.age));
      if (match.gender) setGender(match.gender);
      if (match.addr || match.address) setAddr(match.addr || match.address || '');
      if (match.doc && match.doc !== 'Self Prescribed / OTC') setDocSelect(match.doc);
      else if (match.doctor && match.doctor !== 'Self Prescribed / OTC') setDocSelect(match.doctor);
    } else {
      setPatientId(getNextSequentialPatientId(existingPatients));
    }
  };

  const handlePatientIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setPatientId(val);

    const match = findPatientById(val, existingPatients);
    if (match) {
      setName(match.name || '');
      if (match.phone && match.phone !== 'N/A') setPhone(match.phone);
      if (match.age) setAge(String(match.age));
      if (match.gender) setGender(match.gender);
      if (match.addr || match.address) setAddr(match.addr || match.address || '');
      if (match.doc && match.doc !== 'Self Prescribed / OTC') setDocSelect(match.doc);
      else if (match.doctor && match.doctor !== 'Self Prescribed / OTC') setDocSelect(match.doctor);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (!phone.trim()) {
      alert('Please enter patient mobile number');
      return;
    }

    const finalDoc = docSelect === 'CUSTOM' ? customDoc.trim() || 'Other Doctor' : docSelect;
    const today = getTodayISODate();
    const parsedDue = parseFloat(initialDue) || 0;
    const formattedAgeGender = `${age ? age + ' Yrs' : '--'} / ${gender}`;

    const newPatient: PatientRecord = {
      id: patientId.trim() || getNextSequentialPatientId(existingPatients),
      name: name.trim(),
      phone: phone.trim(),
      age: age ? parseInt(age, 10) : 35,
      gender,
      ageGender: formattedAgeGender,
      addr: addr.trim() || 'Local Area',
      address: addr.trim() || 'Local Area',
      doc: finalDoc,
      doctor: finalDoc,
      reason: reason.trim() || 'General Consultation / Regular Patient',
      totalDue: parsedDue,
      dueAmount: parsedDue,
      lastDate: today,
      lastVisitDate: today,
      totalVisits: 1,
      purchaseHistory: [],
    };

    onSavePatient(newPatient);
    onClose();

    // Reset form
    setName('');
    setPhone('');
    setAge('');
    setGender('Male');
    setAddr('');
    setReason('');
    setInitialDue('0');
    setDocSelect('Self Prescribed / OTC');
    setCustomDoc('');
    setPatientId(getNextSequentialPatientId(existingPatients));
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <UserPlus className="w-4 h-4" />
            </div>
            <span>Register New Patient Profile (নতুন রোগী প্রোফাইল)</span>
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Patient ID <span className="text-slate-500 font-normal">(আইডি)</span>
              </label>
              <input
                type="text"
                value={patientId}
                onChange={e => setPatientId(e.target.value)}
                placeholder="P/107"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-indigo-300 outline-none focus:border-indigo-400"
                required
              />
            </div>

            <div className="col-span-2">
              <label className="font-semibold text-slate-300 block mb-1">
                Full Name <span className="text-slate-500 font-normal">(রোগীর পুরো নাম)</span> *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Animesh Maity"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white font-bold placeholder:text-slate-500 outline-none focus:border-indigo-400"
                required
                autoFocus
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Mobile Number <span className="text-slate-500 font-normal">(মোবাইল)</span> *
              </label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="10-digit mobile"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white placeholder:text-slate-500 outline-none focus:border-indigo-400"
                required
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">Age (বয়স)</label>
              <input
                type="number"
                value={age}
                onChange={e => setAge(e.target.value)}
                placeholder="e.g. 48"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">Gender (লিঙ্গ)</label>
              <select
                value={gender}
                onChange={e => setGender(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400"
              >
                <option value="Male">Male (পুরুষ)</option>
                <option value="Female">Female (মহিলা)</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Full Address <span className="text-slate-500 font-normal">(গ্রাম / ঠিকানা)</span>
            </label>
            <input
              type="text"
              value={addr}
              onChange={e => setAddr(e.target.value)}
              placeholder="e.g. 119 Negua, Egara, Purba Medinipur"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-indigo-400"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Assigned / Consulting Doctor <span className="text-slate-500 font-normal">(ডাক্তার)</span>
            </label>
            <div className="flex gap-2">
              <select
                value={docSelect}
                onChange={e => setDocSelect(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400"
              >
                <option value="Self Prescribed / OTC">Self Prescribed / OTC (কাউন্টার সেল)</option>
                {loadDoctors().map((d, i) => (
                  <option key={i} value={d}>{d}</option>
                ))}
                <option value="CUSTOM">-- Type Custom Doctor --</option>
              </select>
              {docSelect === 'CUSTOM' && (
                <input
                  type="text"
                  value={customDoc}
                  onChange={e => setCustomDoc(e.target.value)}
                  placeholder="Doctor name..."
                  className="w-full p-2.5 bg-indigo-500/10 border border-indigo-500/30 rounded-xl text-white outline-none"
                  required
                />
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Medical Notes / Reason <span className="text-slate-500 font-normal">(রোগের লক্ষণ)</span>
              </label>
              <input
                type="text"
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="e.g. Hypertension / Diabetes"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-indigo-400"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Initial Due Amount <span className="text-slate-500 font-normal">(বাকি টাকা ₹)</span>
              </label>
              <input
                type="number"
                step="0.01"
                value={initialDue}
                onChange={e => setInitialDue(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-rose-400 font-bold outline-none focus:border-indigo-400"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl shadow-lg shadow-teal-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save Patient Profile</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
