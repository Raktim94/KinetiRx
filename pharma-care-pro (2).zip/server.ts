import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Helper to execute Gemini generation with auto-retry and model fallbacks during high demand spikes (503/429)
async function generateWithRetry(
  ai: GoogleGenAI,
  params: {
    contents: any[];
    config?: any;
    primaryModel?: string;
  }
) {
  const candidateModels = [
    params.primaryModel || 'gemini-3.7-flash',
    'gemini-flash-latest',
    'gemini-3.7-flash',
  ];

  let lastErr: any = null;

  for (let attempt = 0; attempt < candidateModels.length; attempt++) {
    const model = candidateModels[attempt];
    try {
      const resp = await ai.models.generateContent({
        model: model,
        contents: params.contents,
        config: params.config,
      });
      return resp;
    } catch (err: any) {
      lastErr = err;
      const errMsg = err?.message || String(err);
      console.warn(`[Gemini OCR API] Attempt ${attempt + 1} with model ${model} failed: ${errMsg}`);

      const isRecoverable =
        err?.status === 503 ||
        err?.status === 429 ||
        err?.status === 'UNAVAILABLE' ||
        errMsg.includes('503') ||
        errMsg.includes('429') ||
        errMsg.includes('high demand') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('fetch failed');

      if (attempt < candidateModels.length - 1) {
        const delayMs = isRecoverable ? (attempt + 1) * 800 : 400;
        await new Promise(r => setTimeout(r, delayMs));
      }
    }
  }

  throw lastErr;
}

// -------------------------------------------------------------
// CENTRALIZED MULTI-DEVICE PERSISTENT STATE STORE
// -------------------------------------------------------------
const STATE_FILE_PATH = path.join(process.cwd(), 'app_state.json');
const BACKUP_STATE_FILE_PATH = path.join(process.cwd(), 'app_state_backup.json');

interface ServerAppState {
  medicines: any[];
  patientsDue: any[];
  salesHistory: any[];
  dailyRegister: any;
  expenses: any[];
  neededMeds: any[];
  opdVisits: any[];
  patients: any[];
  distributors: any[];
  marketingCampaigns: any[];
  worksheetTasks: any[];
  employees: any[];
  invoiceConfig: any;
  adminPass: string;
  resetPass: string;
  version: number;
  updatedAt: string;
}

function getCleanInitialState(): ServerAppState {
  const todayISO = new Date().toISOString().slice(0, 10);
  return {
    medicines: [],
    patientsDue: [],
    salesHistory: [],
    dailyRegister: {
      date: todayISO,
      prevBD: 0,
      todaySell: 0,
      phonePe: 0,
      expenses: 0,
      bankShift: 0,
      isLocked: false,
      openingCash: 0,
      totalSales: 0,
      cashSales: 0,
      upiSales: 0,
      cardSales: 0,
      totalExpenses: 0,
      denominations: { 2000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0 },
      closingPhysicalCash: 0,
      cashDifference: 0,
      isDrawerClosed: false,
    },
    expenses: [],
    neededMeds: [],
    opdVisits: [],
    patients: [],
    distributors: [],
    marketingCampaigns: [],
    worksheetTasks: [],
    employees: [
      {
        id: 'EMP-1',
        name: 'Staff Manager',
        desig: 'Manager & Pharmacist',
        pass: '1122',
        phone: '9876543210',
        role: 'admin',
        pin: '1122',
        permissions: [
          'dashboard',
          'pos',
          'daily-sales',
          'due-khata',
          'medicine-orders',
          'inventory',
          'inward-ocr',
          'opd',
          'patients',
          'expenses',
          'business-dev',
          'employee-mgmt',
          'invoice-settings',
          'system-reset',
        ],
      },
    ],
    invoiceConfig: {
      name: 'PHARMA CARE PRO & DIAGNOSTIC CENTRE',
      storeName: 'PHARMA CARE PRO & DIAGNOSTIC CENTRE',
      subtitle: 'Complete Healthcare, Pharmacy & Diagnostic Solution',
      dl: 'DL-WB-2026-001 / DL-19A',
      gst: '19ABCDE1234F1Z5',
      phone: '+91 98765 43210',
      waGroup: '',
      addr: 'Main Road, Purba Medinipur, West Bengal',
      terms: '* Medicines once sold will not be returned without cash memo. Thank you for your visit!',
      logoUrl: '',
      retentionMonths: 6,
      retentionPolicyNotice: 'The invoices should be stored for six months. After six months, the invoices will be deleted.',
      autoPurgeOldInvoices: true,
      lastPurgeDate: todayISO,
      director: 'Pharmacy Owner',
      pharmacist: 'Registered Pharmacist',
      currency: '₹',
      printerType: 'thermal_80mm',
      headerTheme: 'modern_minimal',
    },
    adminPass: '1122',
    resetPass: '1122',
    version: 1,
    updatedAt: new Date().toISOString(),
  };
}

let activeServerState: ServerAppState = loadServerState();

function loadServerState(): ServerAppState {
  try {
    if (fs.existsSync(STATE_FILE_PATH)) {
      const raw = fs.readFileSync(STATE_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.version === 'number') {
        // Normalize legacy adminPass if forgotten or default
        if (!parsed.adminPass || parsed.adminPass === 'admin123' || parsed.adminPass === '1234') {
          parsed.adminPass = '1122';
        }
        if (Array.isArray(parsed.employees)) {
          parsed.employees = parsed.employees.map((emp: any) => {
            if (emp.role === 'admin' && (emp.pass === 'admin123' || emp.pass === '1234')) {
              return { ...emp, pass: '1122', pin: '1122' };
            }
            return emp;
          });
        }
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load server state file, checking backup:', err);
    try {
      if (fs.existsSync(BACKUP_STATE_FILE_PATH)) {
        const raw = fs.readFileSync(BACKUP_STATE_FILE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.version === 'number') {
          return parsed;
        }
      }
    } catch (e2) {}
  }
  const clean = getCleanInitialState();
  saveServerState(clean);
  return clean;
}

function saveServerState(state: ServerAppState) {
  try {
    fs.writeFileSync(STATE_FILE_PATH, JSON.stringify(state, null, 2), 'utf-8');
    fs.writeFileSync(BACKUP_STATE_FILE_PATH, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist server state to disk:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // -------------------------------------------------------------
  // CENTRALIZED STATE SYNC & REALTIME MULTI-DEVICE ENDPOINTS
  // -------------------------------------------------------------
  app.get('/api/state/sync', (req, res) => {
    res.json({
      success: true,
      version: activeServerState.version,
      updatedAt: activeServerState.updatedAt,
      state: activeServerState,
    });
  });

  app.post('/api/state/sync', (req, res) => {
    try {
      const { state: incomingState } = req.body;
      if (!incomingState || typeof incomingState !== 'object') {
        return res.status(400).json({ error: 'Missing state object' });
      }

      // Merge incoming state fields
      activeServerState = {
        ...activeServerState,
        ...incomingState,
        version: (activeServerState.version || 0) + 1,
        updatedAt: new Date().toISOString(),
      };

      saveServerState(activeServerState);

      return res.json({
        success: true,
        version: activeServerState.version,
        updatedAt: activeServerState.updatedAt,
        state: activeServerState,
      });
    } catch (err: any) {
      console.error('State sync error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  // Dedicated Reset Password Update Endpoint
  app.post('/api/auth/update-reset-pass', (req, res) => {
    try {
      const { newPass } = req.body;
      const cleanPass = (newPass || '1122').trim();
      activeServerState.resetPass = cleanPass;
      activeServerState.adminPass = cleanPass;
      activeServerState.version = (activeServerState.version || 0) + 1;
      activeServerState.updatedAt = new Date().toISOString();
      saveServerState(activeServerState);

      return res.json({
        success: true,
        resetPass: cleanPass,
        version: activeServerState.version,
      });
    } catch (err: any) {
      console.error('Reset pass update error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  // Dedicated Admin Password Update Endpoint (compatible)
  app.post('/api/auth/update-admin-pass', (req, res) => {
    try {
      const { newPass } = req.body;
      const cleanPass = (newPass || '1122').trim();
      activeServerState.resetPass = cleanPass;
      activeServerState.adminPass = cleanPass;
      activeServerState.version = (activeServerState.version || 0) + 1;
      activeServerState.updatedAt = new Date().toISOString();
      saveServerState(activeServerState);

      return res.json({
        success: true,
        resetPass: cleanPass,
        adminPass: cleanPass,
        version: activeServerState.version,
      });
    } catch (err: any) {
      console.error('Admin/Reset pass update error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/state/reset', (req, res) => {
    try {
      const { organizationData, adminPass } = req.body;
      const todayISO = new Date().toISOString().slice(0, 10);
      const finalAdminPass = (adminPass || '1122').trim();
      const finalStoreName = (organizationData?.storeName || organizationData?.name || 'PHARMA CARE PRO').trim().toUpperCase();
      const finalDirectorName = (organizationData?.director || organizationData?.directorName || 'Director & Admin').trim();

      const freshAdminEmployee = {
        id: 'EMP-ADMIN-' + Date.now(),
        name: finalDirectorName,
        desig: 'Director & Admin',
        pass: finalAdminPass,
        phone: organizationData?.phone || '9876543210',
        role: 'admin',
        pin: finalAdminPass,
        permissions: [
          'dashboard',
          'pos',
          'daily-sales',
          'due-khata',
          'medicine-orders',
          'inventory',
          'inward-ocr',
          'opd',
          'patients',
          'expenses',
          'business-dev',
          'employee-mgmt',
          'invoice-settings',
          'system-reset',
        ],
      };

      activeServerState = {
        medicines: [],
        patientsDue: [],
        salesHistory: [],
        dailyRegister: {
          date: todayISO,
          prevBD: 0,
          todaySell: 0,
          phonePe: 0,
          expenses: 0,
          bankShift: 0,
          isLocked: false,
          openingCash: Number(organizationData?.openingCash || 0),
          totalSales: 0,
          cashSales: 0,
          upiSales: 0,
          cardSales: 0,
          totalExpenses: 0,
          denominations: { 2000: 0, 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0 },
          closingPhysicalCash: 0,
          cashDifference: 0,
          isDrawerClosed: false,
        },
        expenses: [],
        neededMeds: [],
        opdVisits: [],
        patients: [],
        distributors: [],
        marketingCampaigns: [],
        worksheetTasks: [],
        employees: [freshAdminEmployee],
        invoiceConfig: {
          name: finalStoreName,
          storeName: finalStoreName,
          subtitle: organizationData?.subtitle?.trim() || 'Complete Healthcare, Pharmacy & Diagnostic Solution',
          dl: organizationData?.dlNo?.trim() || 'DL-WB-2026-001',
          gst: organizationData?.gstin?.trim() || '',
          phone: organizationData?.phone?.trim() || '',
          waGroup: '',
          addr: organizationData?.address?.trim() || '',
          terms: organizationData?.welcomeNotes?.trim() || '* Medicines once sold will not be returned without cash memo. Thank you for your visit!',
          logoUrl: '',
          retentionMonths: 6,
          retentionPolicyNotice: 'The invoices should be stored for six months. After six months, the invoices will be deleted.',
          autoPurgeOldInvoices: true,
          lastPurgeDate: todayISO,
          director: finalDirectorName,
          pharmacist: organizationData?.pharmacistName?.trim() || 'Registered Pharmacist',
          currency: organizationData?.currency?.trim() || '₹',
          printerType: 'thermal_80mm',
          headerTheme: 'modern_minimal',
        },
        adminPass: finalAdminPass,
        resetPass: activeServerState.resetPass || '1122',
        version: (activeServerState.version || 0) + 1,
        updatedAt: new Date().toISOString(),
      };

      saveServerState(activeServerState);

      return res.json({
        success: true,
        version: activeServerState.version,
        updatedAt: activeServerState.updatedAt,
        state: activeServerState,
      });
    } catch (err: any) {
      console.error('State reset error:', err);
      return res.status(500).json({ error: err.message });
    }
  });

  // API Endpoint: Intelligent Distributor Purchase Invoice OCR & Extraction
  app.post('/api/ocr/parse-bill', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg', textContent, distributorHint } = req.body;

      const ai = getAI();

      if (!ai) {
        // Return fallback indicator so client uses internal multi-format parsing engine
        return res.json({
          success: false,
          fallback: true,
          message: 'GEMINI_API_KEY not configured on server. Using built-in pharmaceutical OCR engine.',
        });
      }

      const prompt = `You are an expert Indian Pharmaceutical Purchase Invoice OCR Parser and ERP Ingestion Specialist.
Analyze the provided medicine distributor purchase invoice / bill image or text carefully.
Extract all structured data strictly conforming to JSON.

Key Extraction Guidelines for Indian Pharma Bills:
1. Distributor Header Details:
   - "distributor": Name of wholesale distributor / pharma supplier (e.g. "BLAIR REMEDIES PVT. LTD.", "NEW UMA MEDICINE DISTRIBUTOR", "SUN PHARMA DISTRIBUTORS", "ABBOTT HEALTHCARE", "CIPLA PHARMA", "MAA SARADA PHARMACEUTICALS", etc.)
   - "gstin": Distributor's 15-digit GSTIN (e.g. "06AAGCB6632E1ZX", "19BUOPM8157K1ZP") or "N/A"
   - "phone": Contact phone / mobile number (e.g. "9728712333", "8967484607") or "N/A"
   - "address": Address of distributor (e.g. "Food Park, Saha, Ambala Cantt, Haryana" or "Negua, Egera, Purba Medinipur, WB")
   - "invNo": Invoice / Bill Number (e.g. "A002223", "1CC-002289", "1CC-002163")
   - "invDate": Invoice date in YYYY-MM-DD format (convert e.g. 19-06-2026 or 13/08/2026 to "2026-06-19" or "2026-08-13")
   - "totalCost": Net payable / Grand total invoice amount in INR (e.g. 3534.00, 4136.00, 5879.00)

2. Medicine Line Items:
   Extract EVERY single medicine row in the table.
   For each item extract:
   - "name": Clean commercial medicine trade name (e.g. "ASHTER LOTION", "ASHTER-250 TABS", "ISTADIL-5 SOLUTION", "KETOYARD-C SOAP", "LULIGHT LOTION", "RAPIGLOW LOTION", "SITAHEER-TRIO TABLET", "TATCOB-N TAB", "TELTRIL-40", "TELTRIL-A TAB", "ESOLENT-DSR", "DAPAMAC TRIO 500", "NEFROSAVE TAB", "VOGLIMAC GM 2 TABLET", "GEMER DS 4 TAB", "NEXPRO-L CAP", "ADMENTA 5MG", "ROSUMAC CV 10", "ALSITA MP 500 TAB", "PENTIDS 400MG TAB", "NUROKIND PLUS CAP", "AMLOKIND-5MG", "ALEX LOZ.", "GEMER-P2", "S-VOCITA LS TAB", "STATPURE CV 10", "CILACAR T 20/40 TAB", "BIO-D3 STRONG", "THYROX 25 MG TABLETS", "OROFER-XT", "MET XL 12.5MG", "GLYCHEK-M FORTE TAB", "UDILIV 300 MG TAB", "REMO MV 500")
   - "company": Manufacturing or marketing pharma company name (e.g. "Blair Remedies", "Macleods Pharma", "Sun Pharma", "Abbott", "Mankind", "Fourrts", "Torrent", "Micro Labs", "J.B. Chemicals", "Emcure", "Ajanta Pharma", "Indoco Remedies", "Glenmark")
   - "salt": Active generic pharmaceutical molecule or composition (e.g. "Paracetamol 650mg", "Pantoprazole + Domperidone", "Luliconazole 1%", "Telmisartan + Amlodipine", "Dapagliflozin + Metformin", "Rosuvastatin + Clopidogrel", "Ursodeoxycholic Acid 300mg", etc.)
   - "pack": Packaging unit (e.g. "10*10", "10'S", "60ML", "75GMS", "30ML", "100ML", "10*7 B", "5*10", "15TAB", "30'S")
   - "hsn": HSN code (e.g. "300490", "30049099", "34011110", "33049930", "30049079", "30049034", "300660")
   - "batch": Batch number from the bill (e.g. "GE0848A", "PNT5-1798B", "MT262608", "O7FZZ002", "XT2426009")
   - "exp": Expiry date normalized to YYYY-MM (e.g. "4/28" -> "2028-04", "05/28" -> "2028-05", "10/27" -> "2027-10")
   - "qty": Quantity / billed number of packs/strips/bottles (number, e.g. 2, 4, 10)
   - "rate": Wholesale purchase rate per pack in INR (number, e.g. 32.00, 139.82, 216.07)
   - "dmrp" or "omrp": D.M.R.P or Old MRP if present (number, else 0)
   - "mrp": Maximum retail price per pack in INR (number, e.g. 220.00, 183.51, 283.59)
   - "scheme": Scheme bonus (string, e.g. "0.00")
   - "disc": Trade discount % (number, e.g. 0.0, 4.0, 10.0)
   - "gst": GST rate % (number, e.g. 5, 12, 18)

Return ONLY a valid JSON object matching this structure:
{
  "distributor": "BLAIR REMEDIES PVT. LTD.",
  "gstin": "06AAGCB6632E1ZX",
  "phone": "9728712333",
  "address": "Plot No 117, Food Park, Saha, Ambala Cantt, Haryana",
  "invNo": "A002223",
  "invDate": "2026-06-19",
  "totalCost": 3534.00,
  "items": [
    {
      "name": "ASHTER LOTION",
      "company": "Blair Remedies",
      "salt": "Topical Skin Lotion",
      "pack": "60ML",
      "hsn": "300490",
      "batch": "GE0848A",
      "exp": "2028-04",
      "qty": 2,
      "rate": 32.0,
      "dmrp": 0.0,
      "mrp": 220.0,
      "scheme": "0.00",
      "disc": 0.0,
      "gst": 5.0
    }
  ]
}`;

      let contents: any[] = [];

      if (imageBase64) {
        let cleanMimeType = mimeType || 'image/jpeg';
        let base64Data = imageBase64;
        if (typeof imageBase64 === 'string' && imageBase64.startsWith('data:')) {
          const match = imageBase64.match(/^data:([^;]+);base64,(.+)$/);
          if (match) {
            cleanMimeType = match[1];
            base64Data = match[2];
          } else {
            base64Data = imageBase64.replace(/^data:[^;]+;base64,/, '');
          }
        }

        contents = [
          {
            role: 'user',
            parts: [
              { text: prompt },
              {
                inlineData: {
                  mimeType: cleanMimeType,
                  data: base64Data,
                },
              },
            ],
          },
        ];
      } else if (textContent) {
        contents = [
          {
            role: 'user',
            parts: [
              { text: `${prompt}\n\nInvoice Text Content:\n${textContent}` },
            ],
          },
        ];
      } else {
        return res.status(400).json({ error: 'No imageBase64 or textContent provided' });
      }

      const response = await generateWithRetry(ai, {
        primaryModel: 'gemini-3.7-flash',
        contents: contents,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.1,
        },
      });

      let responseText = (response.text || '').trim();
      
      // Clean possible markdown code fences
      responseText = responseText.replace(/```json\s*/gi, '').replace(/```\s*$/gi, '').trim();
      const jsonStart = responseText.indexOf('{');
      const jsonEnd = responseText.lastIndexOf('}');
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
        responseText = responseText.slice(jsonStart, jsonEnd + 1);
      }

      try {
        const parsedJSON = JSON.parse(responseText);
        if (parsedJSON && Array.isArray(parsedJSON.items) && parsedJSON.items.length > 0) {
          // Sanitize numerical fields
          parsedJSON.items = parsedJSON.items.map((it: any) => ({
            ...it,
            qty: Number(it.qty) || 1,
            rate: Number(it.rate) || 0,
            mrp: Number(it.mrp) || 0,
            dmrp: Number(it.dmrp) || 0,
            gst: Number(it.gst) || 5,
            disc: Number(it.disc) || 0,
          }));
          if (!parsedJSON.totalCost || parsedJSON.totalCost <= 0) {
            parsedJSON.totalCost = parsedJSON.items.reduce((sum: number, it: any) => sum + (it.rate * it.qty), 0);
          }
          parsedJSON.totalCost = Number(Number(parsedJSON.totalCost).toFixed(2));
        }

        return res.json({
          success: true,
          data: parsedJSON,
        });
      } catch (parseError) {
        console.warn('Direct JSON parse failed on Gemini response:', parseError);
        return res.json({
          success: false,
          rawText: responseText,
          data: null,
          message: 'AI response was not valid JSON format.',
        });
      }
    } catch (err: any) {
      console.error('OCR Extraction Error:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'Failed to process purchase bill OCR',
      });
    }
  });

  // API Endpoint: AI Pharmacist Assistant
  app.post('/api/ai/ask', async (req, res) => {
    try {
      const { prompt, medicineContext } = req.body;
      const ai = getAI();

      if (!ai) {
        return res.json({
          success: false,
          fallback: true,
          message: 'AI assistant is operating in offline mode.',
          response: `Clinical Pharmacist Advisory: For ${prompt}, recommend checking inventory for standard broad-spectrum or symptomatic medications.`,
        });
      }

      const systemInstruction = `You are Pharma Care Pro's clinical AI pharmacist assistant.
Provide concise, accurate clinical guidance on medicine indications, dosage precautions, salt substitutions, interactions, and inventory recommendations.
Current inventory context: ${medicineContext || 'Standard Indian Pharmacy Formulary'}.`;

      const response = await generateWithRetry(ai, {
        primaryModel: 'gemini-3.7-flash',
        contents: [
          {
            role: 'user',
            parts: [{ text: `${systemInstruction}\n\nUser Question: ${prompt}` }],
          },
        ],
        config: {
          temperature: 0.2,
        },
      });

      return res.json({
        success: true,
        response: response.text,
      });
    } catch (err: any) {
      console.error('AI Pharmacist Error:', err);
      return res.status(500).json({
        success: false,
        error: err.message || 'AI request failed',
      });
    }
  });

  // Vite development middleware or static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pharma Care Pro server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
