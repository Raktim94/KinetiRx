import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Edit3,
  Tag,
  Save,
  RotateCcw,
  Check,
  FolderPlus,
  Layers,
  Sparkles,
  Search,
} from 'lucide-react';
import { MedicineGroup, Medicine } from '../../types';
import { initialMedicineGroups } from '../../data/medicineGroups';

interface ManageMedicineGroupsModalProps {
  isOpen: boolean;
  onClose: () => void;
  groups: MedicineGroup[];
  onSaveGroups: (groups: MedicineGroup[]) => void;
  selectedGroupId: string | null;
  onSelectGroup: (groupId: string | null) => void;
  medicines: Medicine[];
}

export const ManageMedicineGroupsModal: React.FC<ManageMedicineGroupsModalProps> = ({
  isOpen,
  onClose,
  groups,
  onSaveGroups,
  selectedGroupId,
  onSelectGroup,
  medicines,
}) => {
  const [editingGroup, setEditingGroup] = useState<MedicineGroup | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Group Form State
  const [groupName, setGroupName] = useState('');
  const [groupBengali, setGroupBengali] = useState('');
  const [groupKeywords, setGroupKeywords] = useState('');
  const [selectedMedNames, setSelectedMedNames] = useState<string[]>([]);
  const [groupNotes, setGroupNotes] = useState('');
  const [searchInventory, setSearchInventory] = useState('');

  if (!isOpen) return null;

  // Open Create Form
  const handleOpenCreate = () => {
    setIsCreatingNew(true);
    setEditingGroup(null);
    setGroupName('');
    setGroupBengali('');
    setGroupKeywords('');
    setSelectedMedNames([]);
    setGroupNotes('');
    setSearchInventory('');
  };

  // Open Edit Form
  const handleOpenEdit = (group: MedicineGroup) => {
    setEditingGroup(group);
    setIsCreatingNew(false);
    setGroupName(group.name);
    setGroupBengali(group.bengaliName || '');
    setGroupKeywords(group.keywords.join(', '));
    setSelectedMedNames(group.medicineNames || []);
    setGroupNotes(group.notes || '');
    setSearchInventory('');
  };

  // Save (Create or Update) Group
  const handleSaveGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) {
      alert('Please enter group name (e.g. Delivery, Type 2 Diabetes, Newborn, Viral Fever)');
      return;
    }

    const parsedKeywords = groupKeywords
      .split(',')
      .map(k => k.trim().toLowerCase())
      .filter(Boolean);

    if (parsedKeywords.length === 0) {
      parsedKeywords.push(groupName.toLowerCase().trim());
    }

    const newOrUpdatedGroup: MedicineGroup = {
      id: editingGroup?.id || `grp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: groupName.trim(),
      bengaliName: groupBengali.trim() || undefined,
      keywords: parsedKeywords,
      medicineNames: selectedMedNames,
      notes: groupNotes.trim() || undefined,
    };

    let updated: MedicineGroup[];
    if (editingGroup) {
      updated = groups.map(g => (g.id === editingGroup.id ? newOrUpdatedGroup : g));
    } else {
      updated = [...groups, newOrUpdatedGroup];
    }

    onSaveGroups(updated);
    onSelectGroup(newOrUpdatedGroup.id);
    setIsCreatingNew(false);
    setEditingGroup(null);
  };

  // Delete Group (NO LOCKS - Any group can be deleted)
  const handleDeleteGroup = (groupId: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete the group "${name}"?`)) {
      return;
    }

    const updated = groups.filter(g => g.id !== groupId);
    onSaveGroups(updated);
    if (selectedGroupId === groupId) {
      onSelectGroup(null);
    }
  };

  // Reset to Factory Default Groups
  const handleResetDefaults = () => {
    if (window.confirm('Reset all direct medicine groups to standard clinical presets?')) {
      onSaveGroups(initialMedicineGroups);
      onSelectGroup(null);
    }
  };

  // Toggle medicine in selectedMedNames
  const toggleMedicineSelection = (medName: string) => {
    setSelectedMedNames(prev =>
      prev.includes(medName) ? prev.filter(n => n !== medName) : [...prev, medName]
    );
  };

  const filteredInventory = medicines.filter(
    m =>
      !searchInventory ||
      m.name.toLowerCase().includes(searchInventory.toLowerCase()) ||
      (m.salt && m.salt.toLowerCase().includes(searchInventory.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-4xl w-full border border-white/15 text-slate-100 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex justify-between items-center bg-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Direct Medicine Groups & Protocols</span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-semibold px-2 py-0.5 rounded-full border border-indigo-500/30">
                  {groups.length} Groups Active
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Direct category groups (Delivery, Type 2 Diabetes, Viral Fever, Joint Pain, Newborn, etc.) for rapid 1-click POS dispensing
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Create or Edit Group Form */}
          {isCreatingNew || editingGroup ? (
            <form onSubmit={handleSaveGroup} className="space-y-4 bg-white/5 border border-indigo-500/30 p-4 sm:p-5 rounded-2xl">
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <FolderPlus className="w-4 h-4 text-indigo-400" />
                  <span>
                    {editingGroup ? `Edit Group: ${editingGroup.name}` : 'Create Direct Medicine Group (সরাসরি নতুন গ্রুপ)'}
                  </span>
                </h4>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingNew(false);
                    setEditingGroup(null);
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Group Name * (e.g. Delivery, Type 2 Diabetes, Viral Fever, Newborn)
                  </label>
                  <input
                    type="text"
                    value={groupName}
                    onChange={e => setGroupName(e.target.value)}
                    placeholder="e.g. Delivery, Type 2 Diabetes, Joint Pain, Newborn"
                    className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs font-bold"
                    required
                    autoFocus
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Bengali / Sub-Label (বাংলা নাম - ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={groupBengali}
                    onChange={e => setGroupBengali(e.target.value)}
                    placeholder="e.g. ডেলিভারি, ডায়াবেটিস, নবজাতক যত্ন, জ্বর ও সর্দি"
                    className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Matching Medicine Keywords / Salts (কমা দিয়ে একাধিক সল্ট বা নাম লিখুন)
                </label>
                <input
                  type="text"
                  value={groupKeywords}
                  onChange={e => setGroupKeywords(e.target.value)}
                  placeholder="e.g. oxytocin, drotin, misoprostol, folic acid, calcium, iron"
                  className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs font-mono text-indigo-300"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  When this group is clicked at POS, all medicines matching these keywords in their brand name, salt/generic, or category will instantly appear.
                </p>
              </div>

              {/* Link Specific Inventory Medicines */}
              {medicines.length > 0 && (
                <div className="space-y-2 pt-1">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-300">
                      Link Specific Inventory Items ({selectedMedNames.length} selected)
                    </label>
                    <div className="relative w-48">
                      <Search className="w-3 h-3 absolute left-2.5 top-2 text-slate-400" />
                      <input
                        type="text"
                        value={searchInventory}
                        onChange={e => setSearchInventory(e.target.value)}
                        placeholder="Search medicines..."
                        className="w-full pl-7 pr-2 py-1 bg-white/5 border border-white/10 rounded-lg text-white text-[11px] outline-none"
                      />
                    </div>
                  </div>

                  <div className="max-h-36 overflow-y-auto bg-slate-950/50 border border-white/10 rounded-xl p-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {filteredInventory.slice(0, 40).map(m => {
                      const isSelected = selectedMedNames.includes(m.name);
                      return (
                        <div
                          key={m.id}
                          onClick={() => toggleMedicineSelection(m.name)}
                          className={`p-2 rounded-lg border text-xs cursor-pointer flex items-center justify-between transition ${
                            isSelected
                              ? 'bg-indigo-500/20 border-indigo-500 text-indigo-200 font-bold'
                              : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <span className="truncate pr-1">{m.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Protocol Notes / Description (ঐচ্ছিক নোট)
                </label>
                <input
                  type="text"
                  value={groupNotes}
                  onChange={e => setGroupNotes(e.target.value)}
                  placeholder="e.g. Standard maternal care protocol, postpartum dosage"
                  className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-indigo-400 text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingNew(false);
                    setEditingGroup(null);
                  }}
                  className="px-3.5 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-lg shadow-indigo-950/50 transition cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{editingGroup ? 'Update Group' : 'Save Direct Group'}</span>
                </button>
              </div>
            </form>
          ) : (
            /* Action Bar and Groups List */
            <>
              <div className="flex flex-wrap justify-between items-center gap-2 pb-3 border-b border-white/10">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Direct Medicine Groups List</span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    Click any group to filter at POS, or click edit/delete to customize.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleOpenCreate}
                    className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Create Direct Group (নতুন গ্রুপ)</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleResetDefaults}
                    className="px-3 py-2 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 rounded-xl text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
                    title="Reset to Factory Presets"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                    <span>Reset Defaults</span>
                  </button>
                </div>
              </div>

              {/* Group Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {groups.length === 0 ? (
                  <div className="col-span-2 p-8 text-center bg-white/5 rounded-2xl border border-white/5 text-slate-400 text-xs">
                    No medicine groups available. Click "+ Create Direct Group" above or "Reset Defaults".
                  </div>
                ) : (
                  groups.map(group => {
                    const isSelected = selectedGroupId === group.id;
                    return (
                      <div
                        key={group.id}
                        className={`p-4 rounded-2xl border transition flex flex-col justify-between gap-3 ${
                          isSelected
                            ? 'bg-indigo-600/15 border-indigo-500/50 shadow-lg'
                            : 'bg-white/5 hover:bg-white/[0.08] border-white/10'
                        }`}
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-white text-sm">{group.name}</span>
                              {group.bengaliName && (
                                <span className="text-[11px] text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded-lg border border-indigo-500/20">
                                  {group.bengaliName}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 bg-white/5 px-2 py-0.5 rounded-md font-mono">
                              {group.keywords.length} salts
                            </span>
                          </div>

                          {/* Keywords */}
                          <div className="flex items-center gap-1 flex-wrap text-[10px] text-slate-300">
                            {group.keywords.slice(0, 5).map((kw, i) => (
                              <span
                                key={i}
                                className="bg-white/10 text-slate-200 px-1.5 py-0.5 rounded font-mono"
                              >
                                {kw}
                              </span>
                            ))}
                            {group.keywords.length > 5 && (
                              <span className="text-slate-400">+{group.keywords.length - 5} more</span>
                            )}
                          </div>

                          {group.notes && (
                            <p className="text-[10px] text-slate-400 italic truncate">
                              {group.notes}
                            </p>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center justify-between pt-2 border-t border-white/10">
                          <button
                            type="button"
                            onClick={() => {
                              onSelectGroup(group.id);
                              onClose();
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-600 text-white'
                                : 'bg-white/10 hover:bg-white/20 text-slate-200'
                            }`}
                          >
                            <Sparkles className="w-3 h-3 text-indigo-300" />
                            <span>{isSelected ? 'Currently Selected' : 'Use at POS'}</span>
                          </button>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(group)}
                              className="p-1.5 text-indigo-300 hover:text-white bg-white/5 hover:bg-indigo-600/30 rounded-xl border border-white/10 transition cursor-pointer"
                              title="Edit Group"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteGroup(group.id, group.name)}
                              className="p-1.5 text-rose-400 hover:text-white bg-white/5 hover:bg-rose-600/30 rounded-xl border border-white/10 transition cursor-pointer"
                              title="Delete Group"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-white/5 flex justify-between items-center text-xs">
          <span className="text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Select any direct group at POS to instantly display all matching medicines.</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-lg transition cursor-pointer"
          >
            Done & Return to POS
          </button>
        </div>
      </div>
    </div>
  );
};
