import React, { useState } from 'react';
import {
  CreditCard,
  Download,
  Eye,
  HandCoins,
  MessageCircle,
  Phone,
  Search,
  User,
} from 'lucide-react';
import { DailyRegister, PatientRecord, SalesRecord } from '../../types';
import { getTodayISODate } from '../../utils/dateUtils';
import { exportToCSV, formatWhatsAppPhone } from '../../utils/exportCsv';

interface DueKhataTabProps {
  patients: PatientRecord[];
  setPatients: React.Dispatch<React.SetStateAction<PatientRecord[]>>;
  patientsDue?: PatientRecord[];
  setPatientsDue?: React.Dispatch<React.SetStateAction<PatientRecord[]>>;
  setDailyRegister?: React.Dispatch<React.SetStateAction<DailyRegister>>;
  setSalesHistory?: React.Dispatch<React.SetStateAction<SalesRecord[]>>;
  onViewPatientProfile?: (p: PatientRecord) => void;
  shopName: string;
  shopPhone: string;
}

export const DueKhataTab: React.FC<DueKhataTabProps> = ({
  patients,
  setPatients,
  patientsDue,
  setPatientsDue,
  setDailyRegister,
  setSalesHistory,
  onViewPatientProfile,
  shopName,
  shopPhone,
}) => {
  const [search, setSearch] = useState('');

  // Authoritative due list from unified patients registry
  const allPatientSource = Array.isArray(patients) && patients.length > 0 ? patients : (patientsDue || []);
  const duePatients = allPatientSource.filter(p => (p.totalDue || p.dueAmount || 0) > 0);

  const filtered = duePatients.filter(
    p =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.phone.includes(search) ||
      (p.addr && p.addr.toLowerCase().includes(search.toLowerCase())) ||
      (p.doc && p.doc.toLowerCase().includes(search.toLowerCase()))
  );

  const totalDueSum = duePatients.reduce((sum, p) => sum + (p.totalDue || p.dueAmount || 0), 0);

  const handleSendWhatsAppReminder = (p: PatientRecord) => {
    const formatted = formatWhatsAppPhone(p.phone);
    if (!formatted || formatted.length < 10) {
      alert(`Invalid phone number for ${p.name}`);
      return;
    }
    const dueAmt = (p.totalDue || p.dueAmount || 0).toFixed(2);
    const msg = `Dear ${p.name},\nThis is a gentle payment reminder from ${shopName} that your pending account due balance is ₹${dueAmt} (Patient ID: ${p.id}).\nKindly clear your pending dues at your earliest convenience.\nHelpline: ${shopPhone}\nThank you!`;
    const url = `https://api.whatsapp.com/send?phone=${formatted}&text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleCollectDue = (patientId: string) => {
    const p = allPatientSource.find(item => item.id === patientId);
    if (!p) return;

    const currentDue = p.totalDue || p.dueAmount || 0;
    const collectedInput = prompt(
      `Collect due payment for ${p.name} (Current Outstanding: ₹${currentDue.toFixed(2)}):`,
      currentDue.toString()
    );

    if (collectedInput !== null) {
      const amount = parseFloat(collectedInput);
      if (!isNaN(amount) && amount > 0) {
        const todayStr = getTodayISODate();
        const newDue = Math.max(0, currentDue - amount);

        // 1. Update Patient Registry
        const updateFn = (prev: PatientRecord[]) =>
          prev.map(item => {
            if (item.id === patientId) {
              return {
                ...item,
                totalDue: newDue,
                dueAmount: newDue,
                lastDate: todayStr,
                lastVisitDate: todayStr,
                reason: newDue === 0 ? 'Dues Cleared Fully' : `Partial Due Paid (Bal: ₹${newDue.toFixed(2)})`,
              };
            }
            return item;
          });

        setPatients(updateFn);
        if (setPatientsDue) setPatientsDue(updateFn);

        // 2. Add Collection to Daily Register
        if (setDailyRegister) {
          setDailyRegister(prev => ({
            ...prev,
            todaySell: Number(((prev.todaySell || 0) + amount).toFixed(2)),
            cashSales: Number(((prev.cashSales || 0) + amount).toFixed(2)),
            totalSales: Number(((prev.totalSales || 0) + amount).toFixed(2)),
          }));
        }

        // 3. Add to Sales History Log
        if (setSalesHistory) {
          const settlementRecord: SalesRecord = {
            id: `DUE-COL-${Date.now()}`,
            inv: `DUE-REC-${p.id}`,
            invoiceNo: `DUE-REC-${p.id}`,
            date: todayStr,
            time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
            cust: p.name,
            patient: p.name,
            patientId: p.id,
            phone: p.phone,
            items: `Due Settlement Collection (Prev: ₹${currentDue.toFixed(2)}, Now: ₹${newDue.toFixed(2)})`,
            mode: 'Cash (Due Collection)',
            total: amount,
            amt: amount,
            paidAmount: amount,
            dueAmount: 0,
            status: 'Settled',
          };
          setSalesHistory(prev => [settlementRecord, ...prev]);
        }

        alert(`Successfully collected ₹${amount.toFixed(2)} from ${p.name}. Remaining Due: ₹${newDue.toFixed(2)}`);
      }
    }
  };

  const handleExportCSV = () => {
    exportToCSV(
      'patient_due_register',
      ['Patient ID', 'Patient Name', 'Phone', 'Address', 'Doctor Reference', 'Reason', 'Last Transaction Date', 'Total Due (INR)'],
      duePatients.map(p => [
        p.id,
        p.name,
        p.phone,
        p.addr || p.address || '',
        p.doc || p.doctor || '',
        p.reason || 'Pending Medicine Bill',
        p.lastDate || p.lastVisitDate || '--',
        (p.totalDue || p.dueAmount || 0).toFixed(2),
      ])
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="p-6 rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-white/15 shadow-2xl flex justify-between items-center flex-wrap gap-4 text-slate-100">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <CreditCard className="w-4 h-4" />
            </div>
            <span>Patient Due Register (বাকির খাতা)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Real-time customer credit balances, automated WhatsApp due notifications, and instant cash collection tracking.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="bg-rose-500/20 border border-rose-500/30 px-3.5 py-2 rounded-2xl text-xs font-bold text-rose-300 backdrop-blur-md">
            Total Outstanding: <span className="font-mono text-sm text-rose-200">₹ {totalDueSum.toFixed(2)}</span>
          </div>

          <button
            onClick={handleExportCSV}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-2xl text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="due-search"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search name, ID, phone..."
              className="pl-9 pr-3 py-2 bg-slate-950/70 border border-white/10 rounded-2xl text-xs w-56 text-white placeholder:text-slate-500 outline-none focus:border-rose-400 backdrop-blur-md"
            />
          </div>
        </div>
      </div>

      {/* Due table */}
      <div className="bg-slate-900/90 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-2xl overflow-hidden text-xs text-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white/10 border-b border-white/10 text-[11px] font-bold text-slate-300 uppercase backdrop-blur-md">
              <tr>
                <th className="p-3.5">Patient Name & ID</th>
                <th className="p-3.5">Phone & Address</th>
                <th className="p-3.5">Doctor / Reference</th>
                <th className="p-3.5">Reason / Clinical Note</th>
                <th className="p-3.5">Last Transaction</th>
                <th className="p-3.5 text-rose-400 font-bold">Total Due (₹)</th>
                <th className="p-3.5 text-center">Fast Actions</th>
              </tr>
            </thead>
            <tbody id="due-khata-rows" className="divide-y divide-white/5 text-slate-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No pending due records found. All accounts are currently clear!
                  </td>
                </tr>
              ) : (
                filtered.map(p => (
                  <tr key={p.id} className="hover:bg-white/5 transition">
                    <td className="p-3.5">
                      <span className="font-bold text-white block text-sm">{p.name}</span>
                      <span className="text-[10px] text-teal-300 font-mono font-bold bg-teal-500/20 px-1.5 py-0.5 rounded inline-block mt-0.5">
                        {p.id}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="font-mono block text-slate-200 font-bold">{p.phone}</span>
                      <span className="text-[11px] text-slate-400">{p.addr || p.address || 'Local Area'}</span>
                    </td>
                    <td className="p-3.5 text-indigo-300 font-medium">{p.doc || p.doctor || 'Self Prescribed / OTC'}</td>
                    <td className="p-3.5 text-slate-400">{p.reason || 'Medicine Bill Dues'}</td>
                    <td className="p-3.5 text-slate-400 font-mono">{p.lastDate || p.lastVisitDate || 'Recent'}</td>
                    <td className="p-3.5 font-extrabold text-rose-400 font-mono text-sm">
                      ₹ {(p.totalDue || p.dueAmount || 0).toFixed(2)}
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5 flex-wrap">
                        {onViewPatientProfile && (
                          <button
                            type="button"
                            onClick={() => onViewPatientProfile(p)}
                            className="bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/30 px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition backdrop-blur-sm cursor-pointer"
                            title="View Patient CV & History"
                          >
                            <Eye className="w-3.5 h-3.5 text-teal-400" /> CV
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleSendWhatsAppReminder(p)}
                          className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition backdrop-blur-sm cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-400" /> Remind
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCollectDue(p.id)}
                          className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition backdrop-blur-sm cursor-pointer"
                        >
                          <HandCoins className="w-3.5 h-3.5 text-rose-400" /> Collect
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

