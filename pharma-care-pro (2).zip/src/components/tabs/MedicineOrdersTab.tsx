import React, { useState } from 'react';
import {
  AlertTriangle,
  Clock,
  Download,
  Edit3,
  FileCheck2,
  ListPlus,
  MessageCircle,
  Package,
  Pill,
  Phone,
  Plus,
  Search,
  ShoppingCart,
  Trash2,
  Truck,
  User,
  UserCheck,
} from 'lucide-react';
import { Distributor, Medicine, NeededMedOrder, PatientRecord } from '../../types';
import { exportToCSV, formatWhatsAppPhone } from '../../utils/exportCsv';
import { EditNeedMedModal } from '../modals/EditNeedMedModal';
import { LowStockReorderModal } from '../modals/LowStockReorderModal';

interface MedicineOrdersTabProps {
  neededMeds: NeededMedOrder[];
  setNeededMeds: React.Dispatch<React.SetStateAction<NeededMedOrder[]>>;
  onOpenAddNeedModal: () => void;
  distributors?: Distributor[];
  setDistributors?: React.Dispatch<React.SetStateAction<Distributor[]>>;
  patients?: PatientRecord[];
  medicines?: Medicine[];
  onViewPatientProfile?: (p: PatientRecord) => void;
  shopName?: string;
  shopPhone?: string;
}

export const MedicineOrdersTab: React.FC<MedicineOrdersTabProps> = ({
  neededMeds,
  setNeededMeds,
  onOpenAddNeedModal,
  distributors = [],
  setDistributors,
  patients = [],
  medicines = [],
  onViewPatientProfile,
  shopName = 'MEDIX SMART PHARMACY',
  shopPhone = '9876543210',
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [orderToEdit, setOrderToEdit] = useState<NeededMedOrder | null>(null);
  const [isLowStockModalOpen, setIsLowStockModalOpen] = useState(false);

  // Count low stock medicines
  const lowStockCount = medicines.filter(
    m => !m.isLabTest && m.itemType !== 'lab_test' && (m.stock || 0) <= 10
  ).length;

  const handleUpdateStatus = (id: string, newStatus: NeededMedOrder['status']) => {
    setNeededMeds(prev =>
      prev.map(item => (item.id === id ? { ...item, status: newStatus } : item))
    );
  };

  const filteredOrders = neededMeds.filter(n => {
    const q = search.toLowerCase();
    const matchesSearch =
      !search ||
      n.med.toLowerCase().includes(q) ||
      n.name.toLowerCase().includes(q) ||
      (n.patientId && n.patientId.toLowerCase().includes(q)) ||
      n.phone.includes(search) ||
      n.dist.toLowerCase().includes(q) ||
      (n.items && n.items.some(i => i.med.toLowerCase().includes(q)));

    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getDistributorInfo = (distName: string): Distributor | undefined => {
    return distributors.find(
      d =>
        d.name.toLowerCase() === distName.toLowerCase() ||
        distName.toLowerCase().includes(d.name.toLowerCase()) ||
        d.name.toLowerCase().includes(distName.toLowerCase())
    );
  };

  const handleWhatsAppDistributor = (order: NeededMedOrder) => {
    // Find distributor to get registered phone
    const distMatch = getDistributorInfo(order.dist);

    const distPhone = distMatch?.phone && distMatch.phone !== 'N/A' ? distMatch.phone : '';
    const formattedPhone = formatWhatsAppPhone(distPhone);

    // Format itemized list if multiple medicines exist
    let itemsText = '';
    if (order.items && order.items.length > 0) {
      itemsText = order.items
        .map(
          (item, idx) =>
            `${idx + 1}. *${item.med}* - Quantity: *${item.qty} ${item.unit || 'Strips'}*`
        )
        .join('\n');
    } else {
      itemsText = `1. *${order.med}* - Quantity: *${order.qty} Units*`;
    }

    const msg =
      `*URGENT MEDICINE ORDER / বিশেষ ওষুধের রিকুইজিশন*\n\n` +
      `🏢 *To Distributor:* ${order.dist}\n` +
      `📦 *Ordered Items List:*\n${itemsText}\n\n` +
      `👤 *Patient Reference:* ${order.name} ${order.patientId ? `(ID: ${order.patientId})` : ''}\n` +
      `⏰ *Commitment Deadline:* ${order.time}\n` +
      `📋 *Order ID:* ${order.id}\n` +
      (order.notes ? `📝 *Remarks:* ${order.notes}\n` : '') +
      `\n` +
      `🏥 *From:* ${shopName}\n` +
      `📞 *Contact:* ${shopPhone}\n\n` +
      `_Please confirm availability and dispatch schedule. Thank you!_`;

    if (formattedPhone && formattedPhone.length >= 10) {
      const url = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(msg)}`;
      window.open(url, '_blank');
    } else {
      // Prompt user if distributor phone is not registered yet and offer to save
      const inputPhone = prompt(
        `Distributor "${order.dist}" mobile number not found in registry.\nEnter mobile number to send WhatsApp order & save to supplier registry:`,
        ''
      );
      if (inputPhone) {
        const cleaned = formatWhatsAppPhone(inputPhone);
        if (cleaned) {
          // Auto-save phone number to distributor in registry
          if (setDistributors && distMatch) {
            setDistributors(prev => {
              const updated = prev.map(d =>
                d.id === distMatch.id ? { ...d, phone: inputPhone.trim() } : d
              );
              try {
                localStorage.setItem('pcp_distributors_v2', JSON.stringify(updated));
              } catch (err) {}
              return updated;
            });
          }

          const url = `https://api.whatsapp.com/send?phone=${cleaned}&text=${encodeURIComponent(msg)}`;
          window.open(url, '_blank');
        }
      }
    }
  };

  const handleDeleteOrder = (id: string, medName: string) => {
    if (confirm(`Are you sure you want to remove special order for "${medName}"?`)) {
      setNeededMeds(prev => prev.filter(o => o.id !== id));
    }
  };

  const handleExportCSV = () => {
    exportToCSV(
      'special_medicine_orders',
      [
        'Order ID',
        'Patient ID',
        'Medicine Required / Items',
        'Patient Name',
        'Phone Number',
        'Supplier / Distributor',
        'Total Quantity',
        'Commitment Delivery Time',
        'Order Status',
      ],
      neededMeds.map(n => [
        n.id,
        n.patientId || 'N/A',
        n.items && n.items.length > 0
          ? n.items.map(i => `${i.med} (${i.qty} ${i.unit || 'Strips'})`).join('; ')
          : n.med,
        n.name,
        n.phone,
        n.dist,
        n.qty,
        n.time,
        n.status,
      ])
    );
  };

  const handlePatientClick = (patientId?: string) => {
    if (!patientId || !onViewPatientProfile) return;
    const found = patients.find(p => p.id.toLowerCase() === patientId.toLowerCase());
    if (found) {
      onViewPatientProfile(found);
    }
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="p-6 rounded-3xl bg-slate-900/90 backdrop-blur-2xl border border-white/15 shadow-2xl flex justify-between items-center flex-wrap gap-4 text-slate-100">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <span>Special Medicine Need Orders (জরুরি ওষুধ বুকিং)</span>
            </h2>
            <span className="bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-mono px-3 py-0.5 rounded-full font-bold">
              {neededMeds.length} Orders
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Order multiple out-of-stock medicines per requisition, monitor low-stock inventory, assign registered distributors, and dispatch purchase orders via WhatsApp with 1-click.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Low Stock Reorder Button */}
          <button
            id="btn-low-stock-reorder"
            onClick={() => setIsLowStockModalOpen(true)}
            className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 px-3.5 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            title="View low stock medicines and order from distributors"
          >
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span>Low Stock Re-order ({lowStockCount})</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-semibold px-3.5 py-2 rounded-2xl text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export Excel</span>
          </button>

          <button
            id="btn-add-need-order"
            onClick={onOpenAddNeedModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Note Special Medicine Order</span>
          </button>
        </div>
      </div>

      {/* SEARCH & FILTERS */}
      <div className="flex justify-between items-center gap-3 flex-wrap bg-white/5 p-3 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by Patient ID, Patient Name, Medicine, Phone, or Distributor..."
            className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-white/10 rounded-xl text-xs text-white placeholder:text-slate-500 outline-none focus:border-indigo-400"
          />
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-medium">Status:</label>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="p-2 rounded-xl text-xs font-semibold bg-slate-900 border border-white/15 text-white outline-none focus:border-indigo-400"
          >
            <option value="all">All Statuses</option>
            <option value="Distributor Ordered">Distributor Ordered</option>
            <option value="Processing">Processing</option>
            <option value="Pending">Pending</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* ORDERS TABLE */}
      <div className="bg-slate-900/90 backdrop-blur-2xl border border-white/15 rounded-3xl shadow-2xl overflow-hidden text-xs text-slate-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-white/10 border-b border-white/10 text-[11px] font-bold text-slate-300 uppercase backdrop-blur-md">
              <tr>
                <th className="p-3.5">Medicines Required</th>
                <th className="p-3.5">Patient Details (রোগীর তথ্য)</th>
                <th className="p-3.5">Distributor Assigned</th>
                <th className="p-3.5 text-emerald-400 font-bold">Commitment Delivery Time</th>
                <th className="p-3.5 text-center">Total Quantity</th>
                <th className="p-3.5">Order Status</th>
                <th className="p-3.5 text-center">WhatsApp & Actions</th>
              </tr>
            </thead>
            <tbody id="need-med-rows" className="divide-y divide-white/5 text-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No special need medicine orders found. Click "+ Note Special Medicine Order" or "Low Stock Re-order" to create one.
                  </td>
                </tr>
              ) : (
                filteredOrders.map(n => (
                  <tr key={n.id} className="hover:bg-white/5 transition">
                    <td className="p-3.5">
                      <div className="space-y-1">
                        <span className="font-bold text-white text-sm block">{n.med}</span>

                        {/* Multi-item Breakdown if order contains multiple medicines */}
                        {n.items && n.items.length > 0 && (
                          <div className="space-y-0.5 pt-1">
                            {n.items.map((item, idx) => (
                              <div
                                key={item.id || idx}
                                className="flex items-center gap-1.5 text-[11px] text-slate-300 font-mono bg-white/5 px-2 py-0.5 rounded-md border border-white/5"
                              >
                                <Pill className="w-3 h-3 text-indigo-400 shrink-0" />
                                <span className="font-bold text-slate-200">{item.med}</span>
                                <span className="text-emerald-400 font-bold ml-auto">
                                  {item.qty} {item.unit || 'Strips'}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}

                        {n.notes && (
                          <span className="text-[10px] text-amber-300/90 italic block">
                            Note: {n.notes}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {n.patientId ? (
                          <button
                            onClick={() => handlePatientClick(n.patientId)}
                            className="font-mono text-xs font-bold text-teal-300 bg-teal-500/15 border border-teal-500/30 px-1.5 py-0.5 rounded hover:bg-teal-500/25 transition cursor-pointer"
                            title="Click to view Patient Profile CV"
                          >
                            {n.patientId}
                          </button>
                        ) : (
                          <span className="font-mono text-[10px] text-slate-400 bg-white/10 px-1.5 py-0.5 rounded">
                            Walk-in
                          </span>
                        )}
                        <span className="font-bold text-slate-200">{n.name}</span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                        Ph: {n.phone}
                      </span>
                    </td>

                    <td className="p-3.5 font-semibold text-indigo-300">
                      {(() => {
                        const dInfo = getDistributorInfo(n.dist);
                        return (
                          <div>
                            <div className="flex items-center gap-1.5">
                              <Truck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                              <span className="font-bold text-white">{n.dist}</span>
                            </div>
                            {dInfo?.phone && dInfo.phone !== 'N/A' ? (
                              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1 mt-0.5">
                                <Phone className="w-2.5 h-2.5" />
                                <span>{dInfo.phone}</span>
                              </span>
                            ) : (
                              <span className="text-[9px] text-slate-500 font-mono block mt-0.5">
                                Phone: Not Linked
                              </span>
                            )}
                          </div>
                        );
                      })()}
                    </td>

                    <td className="p-3.5 text-emerald-300 font-bold">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{n.time}</span>
                      </div>
                    </td>

                    <td className="p-3.5 text-center font-bold font-mono">
                      <span className="bg-white/10 text-slate-200 px-2.5 py-1 rounded-lg border border-white/10">
                        {n.qty} Units
                      </span>
                    </td>

                    <td className="p-3.5">
                      <select
                        value={n.status}
                        onChange={e =>
                          handleUpdateStatus(
                            n.id,
                            e.target.value as NeededMedOrder['status']
                          )
                        }
                        className={`p-2 rounded-xl font-bold text-xs bg-slate-900 border text-white outline-none focus:border-indigo-400 ${
                          n.status === 'Delivered'
                            ? 'border-emerald-500/40 text-emerald-300'
                            : n.status === 'Processing'
                            ? 'border-amber-500/40 text-amber-300'
                            : n.status === 'Cancelled'
                            ? 'border-rose-500/40 text-rose-300'
                            : 'border-white/15'
                        }`}
                      >
                        <option value="Distributor Ordered">Distributor Ordered</option>
                        <option value="Processing">Processing</option>
                        <option value="Pending">Pending</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>

                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleWhatsAppDistributor(n)}
                          className="bg-emerald-600/25 hover:bg-emerald-600/40 border border-emerald-500/40 text-emerald-300 px-2.5 py-1.5 rounded-xl font-bold text-[11px] flex items-center gap-1 transition cursor-pointer"
                          title="Send instant WhatsApp Purchase Order to Distributor"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                          <span>WhatsApp</span>
                        </button>
                        <button
                          onClick={() => setOrderToEdit(n)}
                          className="p-1.5 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 rounded-xl transition cursor-pointer"
                          title="Edit Order Details"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteOrder(n.id, n.med)}
                          className="p-1.5 hover:bg-rose-500/20 text-slate-500 hover:text-rose-300 rounded-xl transition cursor-pointer"
                          title="Delete Order"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* EDIT SPECIAL ORDER MODAL */}
      <EditNeedMedModal
        isOpen={!!orderToEdit}
        onClose={() => setOrderToEdit(null)}
        order={orderToEdit}
        distributors={distributors}
        setDistributors={setDistributors}
        onUpdateOrder={updated => {
          setNeededMeds(prev => prev.map(item => (item.id === updated.id ? updated : item)));
        }}
      />

      {/* LOW STOCK REORDER MODAL */}
      <LowStockReorderModal
        isOpen={isLowStockModalOpen}
        onClose={() => setIsLowStockModalOpen(false)}
        medicines={medicines}
        distributors={distributors}
        setDistributors={setDistributors}
        onSaveNeedMed={order => {
          setNeededMeds(prev => [order, ...prev]);
        }}
        onBulkCreateSpecialOrders={orders => {
          setNeededMeds(prev => [...orders, ...prev]);
        }}
        shopName={shopName}
        shopPhone={shopPhone}
      />
    </div>
  );
};
