import React, { useState, useEffect } from 'react';
import {
  Edit3,
  HeartPulse,
  IdCard,
  MapPin,
  Phone,
  Save,
  Stethoscope,
  User,
  X,
} from 'lucide-react';
import { PatientRecord } from '../../types';

interface EditPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientRecord | null;
  onUpdatePatient: (updated: PatientRecord) => void;
}

export const EditPatientModal: React.FC<EditPatientModalProps> = ({
  isOpen,
  onClose,
  patient,
  onUpdatePatient,
}) => {
  const [patientId, setPatientId] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('Male');
  const [addr, setAddr] = useState('');
  const [doc, setDoc] = useState('');
  const [reason, setReason] = useState('');
  const [totalDue, setTotalDue] = useState('0');

  useEffect(() => {
    if (patient) {
      setPatientId(patient.id || '');
      setName(patient.name || '');
      setPhone(patient.phone || '');
      setAge(patient.age ? String(patient.age) : '');
      setGender(patient.gender || 'Male');
      setAddr(patient.addr || patient.address || '');
      setDoc(patient.doc || patient.doctor || 'Self Prescribed / OTC');
      setReason(patient.reason || '');
      setTotalDue(String(patient.totalDue !== undefined ? patient.totalDue : patient.dueAmount || 0));
    }
  }, [patient, isOpen]);

  if (!isOpen || !patient) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (!phone.trim()) {
      alert('Please enter patient phone number');
      return;
    }

    const parsedDue = parseFloat(totalDue) || 0;
    const formattedAgeGender = `${age ? age + ' Yrs' : '--'} / ${gender}`;

    const updatedPatient: PatientRecord = {
      ...patient,
      id: patientId.trim() || patient.id,
      name: name.trim(),
      phone: phone.trim(),
      age: age ? parseInt(age, 10) : patient.age || 35,
      gender,
      ageGender: formattedAgeGender,
      addr: addr.trim() || 'Local Area',
      address: addr.trim() || 'Local Area',
      doc: doc.trim() || 'Self Prescribed / OTC',
      doctor: doc.trim() || 'Self Prescribed / OTC',
      reason: reason.trim() || 'Regular Patient',
      totalDue: parsedDue,
      dueAmount: parsedDue,
    };

    onUpdatePatient(updatedPatient);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Edit3 className="w-4 h-4" />
            </div>
            <span>Edit Patient Profile (রোগীর তথ্য সংশোধন)</span>
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Patient ID <span className="text-slate-500 font-normal">(আইডি)</span>
              </label>
              <input
                type="text"
                value={patientId}
                onChange={e => setPatientId(e.target.value)}
                placeholder="101"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-teal-300 outline-none focus:border-teal-400"
                required
              />
            </div>

            <div className="col-span-2">
              <label className="font-semibold text-slate-300 block mb-1">
                Full Name <span className="text-slate-500 font-normal">(রোগীর নাম)</span> *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Kasida Bibi"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white font-bold placeholder:text-slate-500 outline-none focus:border-teal-400"
                required
                autoFocus
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Mobile Number <span className="text-slate-500 font-normal">(মোবাইল)</span> *
              </label>
              <input
                type="text"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="10-digit mobile"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono text-white placeholder:text-slate-500 outline-none focus:border-teal-400"
                required
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">Age (বয়স)</label>
              <input
                type="number"
                value={age}
                onChange={e => setAge(e.target.value)}
                placeholder="e.g. 48"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white outline-none focus:border-teal-400"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">Gender (লিঙ্গ)</label>
              <select
                value={gender}
                onChange={e => setGender(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-teal-400"
              >
                <option value="Male">Male (পুরুষ)</option>
                <option value="Female">Female (মহিলা)</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Full Address <span className="text-slate-500 font-normal">(ঠিকানা / গ্রাম)</span>
            </label>
            <input
              type="text"
              value={addr}
              onChange={e => setAddr(e.target.value)}
              placeholder="e.g. Tamluk, Purba Medinipur"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-teal-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Assigned Doctor <span className="text-slate-500 font-normal">(ডাক্তার)</span>
              </label>
              <input
                type="text"
                value={doc}
                onChange={e => setDoc(e.target.value)}
                placeholder="Doctor name or OTC"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-teal-400"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Outstanding Due (₹) <span className="text-rose-400 font-bold">(বাকি)</span>
              </label>
              <input
                type="number"
                step="any"
                value={totalDue}
                onChange={e => setTotalDue(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl font-mono font-bold text-rose-300 outline-none focus:border-rose-400"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Clinical Notes / History <span className="text-slate-500 font-normal">(রোগের বিবরণ)</span>
            </label>
            <textarea
              rows={2}
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="e.g. Diabetic checkup, BP monitoring, regular monthly prescription"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-teal-400"
            />
          </div>

          <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 rounded-xl font-semibold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl shadow-lg shadow-teal-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
