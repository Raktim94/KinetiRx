import React, { useState } from 'react';
import { Calendar, IndianRupee, Plus, Wallet, X } from 'lucide-react';
import { ExpenseRecord } from '../../types';
import { getTodayISODate } from '../../utils/dateUtils';

interface AddExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveExpense: (expense: ExpenseRecord) => void;
  defaultDate?: string;
}

export const AddExpenseModal: React.FC<AddExpenseModalProps> = ({
  isOpen,
  onClose,
  onSaveExpense,
  defaultDate,
}) => {
  const today = getTodayISODate();
  const [date, setDate] = useState(defaultDate || today);
  const [cat, setCat] = useState('Sample Transport');
  const [customCat, setCustomCat] = useState('');
  const [desc, setDesc] = useState('');
  const [amt, setAmt] = useState('');
  const [paymentSource, setPaymentSource] = useState<'Cash' | 'PhonePe' | 'Bank'>('Cash');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc.trim()) {
      alert('Please enter expense description / remarks');
      return;
    }
    const val = parseFloat(amt);
    if (isNaN(val) || val <= 0) {
      alert('Please enter a valid expense amount');
      return;
    }

    const finalCat = cat === 'CUSTOM' ? customCat.trim() || 'General Expense' : cat;

    const newExpense: ExpenseRecord = {
      id: 'E-' + Date.now(),
      date: date || today,
      cat: finalCat,
      desc: desc.trim(),
      amt: val,
    };

    onSaveExpense(newExpense);
    onClose();
    setDesc('');
    setAmt('');
    setCustomCat('');
    setCat('Sample Transport');
    setPaymentSource('Cash');
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-white/15 text-xs text-slate-100 animate-in zoom-in-95">
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Wallet className="w-4 h-4" />
            </div>
            <span>Log Daily Expenditure (দৈনিক খরচ ভাউচার)</span>
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Expense Date <span className="text-slate-500 font-normal">(তারিখ)</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white font-mono outline-none focus:border-orange-400"
                required
              />
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Payment Source <span className="text-slate-500 font-normal">(পেমেন্ট মাধ্যম)</span>
              </label>
              <select
                value={paymentSource}
                onChange={e => setPaymentSource(e.target.value as any)}
                className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-orange-400"
              >
                <option value="Cash">Cash from Drawer (ড্রয়ার ক্যাশ)</option>
                <option value="PhonePe">UPI / Online / PhonePe</option>
                <option value="Bank">Direct Bank Outflow</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Expense Category <span className="text-slate-500 font-normal">(ক্যাটেগরি)</span>
            </label>
            <div className="space-y-2">
              <select
                value={cat}
                onChange={e => setCat(e.target.value)}
                className="w-full p-2.5 bg-slate-900 border border-white/10 rounded-xl text-white outline-none focus:border-orange-400 font-medium"
              >
                <option value="Sample Transport">Sample Transport / Bus Fare (নমুনা পরিবহন)</option>
                <option value="Maintenance / Repairs">Maintenance & Repairs (মেরামত / রক্ষণাবেক্ষণ)</option>
                <option value="Bank Deposit Cash">Bank Deposit (ব্যাংক জমা / Cash Out)</option>
                <option value="Staff Daily Wage">Staff Daily Wage / Salary Advance (কর্মী বেতন)</option>
                <option value="Tea & Miscellaneous">Tea & Snacks / Refreshments (চা ও জলখাবার)</option>
                <option value="Electricity & Utility">Electricity & Utility Bills (বিদ্যুৎ বিল)</option>
                <option value="Distributor Cash Paid">Distributor Cash Payment (ডিলার ক্যাশ পেমেন্ট)</option>
                <option value="CUSTOM">-- Type Custom Category --</option>
              </select>
              {cat === 'CUSTOM' && (
                <input
                  type="text"
                  value={customCat}
                  onChange={e => setCustomCat(e.target.value)}
                  placeholder="Enter category name..."
                  className="w-full p-2.5 bg-orange-500/10 border border-orange-500/30 rounded-xl text-white outline-none"
                  required
                />
              )}
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Description / Remarks <span className="text-slate-500 font-normal">(খরচের বিবরণ)</span> *
            </label>
            <input
              type="text"
              value={desc}
              onChange={e => setDesc(e.target.value)}
              placeholder="e.g. Transport fare for diagnostic sample delivery to Contai"
              className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-slate-500 outline-none focus:border-orange-400 focus:bg-white/10"
              required
              autoFocus
            />
          </div>

          <div>
            <label className="font-semibold text-slate-300 block mb-1">
              Amount (টাকা ₹) *
            </label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                value={amt}
                onChange={e => setAmt(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 bg-white/5 border border-white/10 rounded-xl font-mono font-bold text-orange-300 placeholder:text-slate-500 outline-none focus:border-orange-400 focus:bg-white/10 text-base"
                required
              />
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-300 text-[11px]">
            💡 This expenditure will be automatically recorded in the <b>Daily Sales Register</b> and deducted from the Physical Cash Drawer balance.
          </div>

          <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl font-medium transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl shadow-lg shadow-orange-950/40 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save & Update Daily Register</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
