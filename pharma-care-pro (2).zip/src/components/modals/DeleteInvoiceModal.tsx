import React, { useState } from 'react';
import { AlertCircle, ArrowLeft, CheckCircle2, IndianRupee, Lock, Package, ShieldAlert, Trash2, X } from 'lucide-react';
import { CurrentUser, SalesRecord } from '../../types';

interface DeleteInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: SalesRecord | null;
  currentUser?: CurrentUser;
  onConfirmDelete: (invoice: SalesRecord) => void;
}

export const DeleteInvoiceModal: React.FC<DeleteInvoiceModalProps> = ({
  isOpen,
  onClose,
  invoice,
  currentUser,
  onConfirmDelete,
}) => {
  const [adminPin, setAdminPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !invoice) return null;

  // Check if current user has Admin role
  const isAdmin = !currentUser || currentUser.role === 'admin' || currentUser.id === 'admin' || currentUser.id === 'emp-admin-1';
  const invNo = invoice.inv || invoice.invoiceNo || invoice.id;
  const grandTotal = Number(invoice.total || invoice.amt || 0);
  const paidAmt = Number(invoice.paidAmount !== undefined ? invoice.paidAmount : grandTotal);
  const dueAmt = Number(invoice.dueAmount || 0);

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      setErrorMsg('⛔ শুধুমাত্র অ্যাডমিন (Admin) ইনভয়েস ডিলিট করতে পারবেন। কর্মীরা ইনভয়েস মুছতে পারবেন না।');
      return;
    }

    onConfirmDelete(invoice);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900/95 backdrop-blur-2xl rounded-3xl shadow-2xl max-w-lg w-full p-6 space-y-5 border border-rose-500/30 text-xs text-slate-100 animate-in zoom-in-95">
        {/* MODAL HEADER */}
        <div className="flex justify-between items-center border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shadow-lg shadow-rose-950/40">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Delete Invoice (ভুল ইনভয়েস বাতিল ও ডিলিট)</span>
              </h3>
              <p className="text-[11px] text-rose-300 font-medium">
                Admin Exclusive Security Action • অ্যাডমিন অনুমোদন আবশ্যক
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-6 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white">ইনভয়েস সফলভাবে ডিলিট করা হয়েছে!</h4>
            <p className="text-xs text-slate-300">
              ওষুধের স্টক ফেরত দেওয়া হয়েছে এবং হিসাব আপডেট করা হয়েছে।
            </p>
          </div>
        ) : (
          <form onSubmit={handleConfirm} className="space-y-4">
            {/* ROLE PERMISSION CHECK BANNER */}
            {!isAdmin ? (
              <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-200 flex items-start gap-2.5">
                <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-xs">অ্যাক্সেস সীমাবদ্ধ (Access Denied)</p>
                  <p className="text-[11px] leading-relaxed text-rose-300/90">
                    আপনি সাধারণ কর্মী (Employee) প্রোফাইলে লগইন আছেন। দোকানের নীতি অনুযায়ী কোনো ভুল বিল বা ইনভয়েস একমাত্র <b>অ্যাডমিন (Admin)</b> আইডি দিয়েই ডিলিট করা যাবে।
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-200 flex items-start gap-2 text-[11px]">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  <b>অ্যাডমিন প্রিভিলেজ সক্রিয়:</b> ভুল ইনভয়েসটি ডিলিট করলে এর সমস্ত আইটেমের স্টক স্বয়ংক্রিয়ভাবে ইনভেন্টরিতে ফেরত (Restocked) যুক্ত হবে।
                </span>
              </div>
            )}

            {/* INVOICE SUMMARY CARD */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5 font-medium">
              <div className="flex justify-between items-center border-b border-white/10 pb-2">
                <span className="text-slate-400">Invoice Number:</span>
                <span className="font-mono font-bold text-indigo-300 text-sm">{invNo}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-400 block text-[10px]">Date & Time:</span>
                  <span className="text-white font-mono">{invoice.date}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Patient / Buyer:</span>
                  <span className="text-white font-semibold">{invoice.cust || invoice.patient || 'Counter Customer'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Payment Mode:</span>
                  <span className="text-sky-300 font-semibold">{invoice.mode}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Doctor Ref:</span>
                  <span className="text-slate-300">{invoice.doctor || 'Self Prescribed / OTC'}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10 flex justify-between items-center">
                <span className="text-slate-300">Grand Total:</span>
                <span className="font-mono font-bold text-emerald-400 text-base">
                  ₹ {grandTotal.toFixed(2)}
                </span>
              </div>

              {dueAmt > 0 && (
                <div className="flex justify-between items-center text-[11px] text-rose-300 bg-rose-500/10 p-2 rounded-xl border border-rose-500/20">
                  <span>Pending Due to be cancelled:</span>
                  <span className="font-mono font-bold">₹ {dueAmt.toFixed(2)}</span>
                </div>
              )}
            </div>

            {/* AUTOMATIC RESTOCK CONSEQUENCES */}
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-1 text-[11px] text-emerald-200">
              <span className="font-bold block text-emerald-300 flex items-center gap-1">
                <Package className="w-3.5 h-3.5" />
                <span>স্বয়ংক্রিয় স্টক ও ব্যালান্স রিভার্সাল:</span>
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-slate-300 text-[10px] pl-1">
                <li>ইনভয়েসে থাকা ওষুধের পরিমাণ ইনভেন্টরিতে ফেরত যুক্ত হবে</li>
                <li>ডেইলি সেলস রেজিস্টার (Daily Sales) থেকে বিক্রয় পরিমাণ হ্রাস পাবে</li>
                {dueAmt > 0 && <li>রোগীর বাকি ডিউ খাতা থেকে ₹{dueAmt.toFixed(2)} বাদ যাবে</li>}
              </ul>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-300 text-[11px]">
                {errorMsg}
              </div>
            )}

            {/* ACTION BUTTONS */}
            <div className="flex justify-end gap-2.5 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl font-semibold transition cursor-pointer"
              >
                Cancel / বাতিল
              </button>

              <button
                type="submit"
                disabled={!isAdmin}
                className={`px-5 py-2.5 rounded-xl font-bold transition flex items-center gap-2 cursor-pointer shadow-lg ${
                  isAdmin
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950/50'
                    : 'bg-slate-800 text-slate-500 border border-white/10 cursor-not-allowed opacity-60'
                }`}
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Delete & Restore Stock (মুছুন)</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
