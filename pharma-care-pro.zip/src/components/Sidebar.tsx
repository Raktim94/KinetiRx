import React, { useState } from 'react';
import {
  Activity,
  Boxes,
  Calculator,
  ChevronDown,
  CreditCard,
  FileCheck2,
  FileText,
  Hospital,
  IdCard,
  LogOut,
  Megaphone,
  Receipt,
  RotateCcw,
  ScanLine,
  ShieldCheck,
  Stethoscope,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { CurrentUser, TabType } from '../types';

interface SidebarProps {
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  currentUser?: CurrentUser;
  onOpenSwitchUser?: () => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  dueKhataCount?: number;
  neededMedsCount?: number;
  opdCount?: number;
  userPermissions?: TabType[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  currentUser,
  onOpenSwitchUser,
  isOpenMobile = false,
  onCloseMobile = () => {},
  dueKhataCount = 0,
  neededMedsCount = 0,
  opdCount = 0,
  userPermissions,
}) => {
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    accounting: true,
    clinical: true,
    stock: true,
    admin: true,
  });

  const toggleGroup = (group: string) => {
    setOpenGroups(prev => ({ ...prev, [group]: !prev[group] }));
  };

  const isPermitted = (tab: TabType) => {
    if (!currentUser && !userPermissions) return true;
    if (currentUser?.role === 'admin') return true;
    const permissions = userPermissions || currentUser?.permissions || [];
    return permissions.includes(tab);
  };

  const handleTabClick = (tab: TabType) => {
    if (isPermitted(tab)) {
      setCurrentTab(tab);
      onCloseMobile();
    } else {
      alert('Access Denied: You do not have permission to view this module.');
    }
  };

  const activeUserRole =
    currentUser?.role === 'admin' ? 'Super Admin' : currentUser?.name || 'Director';

  const isTabActive = (tab: TabType) => {
    if (tab === 'daily-sales' && (currentTab === 'daily-sales' || currentTab === 'daily-calc')) return true;
    if (tab === 'inward-ocr' && (currentTab === 'inward-ocr' || currentTab === 'inward')) return true;
    return currentTab === tab;
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          id="mobile-sidebar-backdrop"
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-40 lg:hidden transition-opacity"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed lg:static top-0 left-0 bottom-0 z-40 w-72 bg-white/5 backdrop-blur-2xl border-r border-white/10 text-slate-300 flex flex-col shrink-0 transition-transform duration-200 ease-in-out ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-white/5">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-400 text-white flex items-center justify-center shadow-lg shadow-indigo-500/25">
              <Hospital className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                Pharma Care Pro
              </h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <p className="text-xs text-slate-400 font-medium">{activeUserRole}</p>
              </div>
            </div>
          </div>
          <button
            id="close-mobile-nav-btn"
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 lg:hidden"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Sections */}
        <nav className="flex-1 p-3.5 space-y-3 overflow-y-auto text-xs custom-scrollbar">
          {/* GROUP 1: ACCOUNTING & POS */}
          <div className="space-y-1">
            <button
              type="button"
              onClick={() => toggleGroup('accounting')}
              className="w-full flex justify-between items-center px-3 py-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-white/5 select-none text-left"
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5 text-indigo-400" />
                Accounting & POS <span className="text-[9px] font-normal text-slate-500">(হিসাব ও বিলিং)</span>
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 ${
                  openGroups.accounting ? 'rotate-0' : '-rotate-90'
                }`}
              />
            </button>

            {openGroups.accounting && (
              <div className="space-y-1 pl-1">
                {isPermitted('dashboard') && (
                  <button
                    id="nav-dashboard"
                    onClick={() => handleTabClick('dashboard')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('dashboard')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Activity className={`w-4 h-4 ${isTabActive('dashboard') ? 'text-indigo-300' : 'text-indigo-400'}`} />
                      <span>Dashboard & Analytics</span>
                    </div>
                  </button>
                )}

                {(isPermitted('daily-sales') || isPermitted('daily-calc')) && (
                  <button
                    id="nav-daily-calc"
                    onClick={() => handleTabClick('daily-sales')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('daily-sales')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Calculator className={`w-4 h-4 ${isTabActive('daily-sales') ? 'text-amber-300' : 'text-amber-400'}`} />
                      <span>Daily Sales Register</span>
                    </div>
                  </button>
                )}

                {isPermitted('pos') && (
                  <button
                    id="nav-pos"
                    onClick={() => handleTabClick('pos')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('pos')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Receipt className={`w-4 h-4 ${isTabActive('pos') ? 'text-emerald-300' : 'text-emerald-400'}`} />
                      <span>Smart Pharmacy POS</span>
                    </div>
                    <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      Live
                    </span>
                  </button>
                )}

                {isPermitted('due-khata') && (
                  <button
                    id="nav-due-khata"
                    onClick={() => handleTabClick('due-khata')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('due-khata')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <CreditCard className={`w-4 h-4 ${isTabActive('due-khata') ? 'text-rose-300' : 'text-rose-400'}`} />
                      <span>Due Register (বাকি)</span>
                    </div>
                    {dueKhataCount > 0 && (
                      <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {dueKhataCount}
                      </span>
                    )}
                  </button>
                )}
              </div>
            )}
          </div>

          {/* GROUP 2: CLINICAL & PATIENTS */}
          <div className="space-y-1 pt-1">
            <button
              type="button"
              onClick={() => toggleGroup('clinical')}
              className="w-full flex justify-between items-center px-3 py-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-white/5 select-none text-left"
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5 text-cyan-400" />
                Clinical & Patients <span className="text-[9px] font-normal text-slate-500">(রোগী ও ওপিডি)</span>
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 ${
                  openGroups.clinical ? 'rotate-0' : '-rotate-90'
                }`}
              />
            </button>

            {openGroups.clinical && (
              <div className="space-y-1 pl-1">
                {isPermitted('opd') && (
                  <button
                    id="nav-opd"
                    onClick={() => handleTabClick('opd')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('opd')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Stethoscope className={`w-4 h-4 ${isTabActive('opd') ? 'text-cyan-300' : 'text-cyan-400'}`} />
                      <span>OPD & Re-visits</span>
                    </div>
                    {opdCount > 0 && (
                      <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {opdCount}
                      </span>
                    )}
                  </button>
                )}

                {isPermitted('patients') && (
                  <button
                    id="nav-patients"
                    onClick={() => handleTabClick('patients')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('patients')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <IdCard className={`w-4 h-4 ${isTabActive('patients') ? 'text-teal-300' : 'text-teal-400'}`} />
                      <span>Patient Profiles</span>
                    </div>
                  </button>
                )}

                {isPermitted('medicine-orders') && (
                  <button
                    id="nav-medicine-orders"
                    onClick={() => handleTabClick('medicine-orders')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('medicine-orders')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <FileCheck2 className={`w-4 h-4 ${isTabActive('medicine-orders') ? 'text-indigo-300' : 'text-indigo-400'}`} />
                      <span>Special Need Orders</span>
                    </div>
                    {neededMedsCount > 0 && (
                      <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {neededMedsCount}
                      </span>
                    )}
                  </button>
                )}
              </div>
            )}
          </div>

          {/* GROUP 3: STOCK & OPERATIONS */}
          <div className="space-y-1 pt-1">
            <button
              type="button"
              onClick={() => toggleGroup('stock')}
              className="w-full flex justify-between items-center px-3 py-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-white/5 select-none text-left"
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Boxes className="w-3.5 h-3.5 text-blue-400" />
                Stock & Operations <span className="text-[9px] font-normal text-slate-500">(স্টক ও খরচ)</span>
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 ${
                  openGroups.stock ? 'rotate-0' : '-rotate-90'
                }`}
              />
            </button>

            {openGroups.stock && (
              <div className="space-y-1 pl-1">
                {isPermitted('inventory') && (
                  <button
                    id="nav-inventory"
                    onClick={() => handleTabClick('inventory')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('inventory')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Boxes className={`w-4 h-4 ${isTabActive('inventory') ? 'text-blue-300' : 'text-blue-400'}`} />
                      <span>Medicine Stock</span>
                    </div>
                  </button>
                )}

                {(isPermitted('inward-ocr') || isPermitted('inward')) && (
                  <button
                    id="nav-inward"
                    onClick={() => handleTabClick('inward-ocr')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('inward-ocr')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <ScanLine className={`w-4 h-4 ${isTabActive('inward-ocr') ? 'text-amber-300' : 'text-amber-400'}`} />
                      <span>OCR Purchase Bills</span>
                    </div>
                  </button>
                )}

                {isPermitted('expenses') && (
                  <button
                    id="nav-expenses"
                    onClick={() => handleTabClick('expenses')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('expenses')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Wallet className={`w-4 h-4 ${isTabActive('expenses') ? 'text-orange-300' : 'text-orange-400'}`} />
                      <span>Daily Expenditures</span>
                    </div>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* GROUP 4: ADMIN & SETTINGS */}
          <div className="space-y-1 pt-1">
            <button
              type="button"
              onClick={() => toggleGroup('admin')}
              className="w-full flex justify-between items-center px-3 py-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-white/5 select-none text-left"
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                Admin & Settings <span className="text-[9px] font-normal text-slate-500">(ম্যানেজমেন্ট)</span>
              </span>
              <ChevronDown
                className={`w-3.5 h-3.5 text-slate-500 transition-transform duration-200 ${
                  openGroups.admin ? 'rotate-0' : '-rotate-90'
                }`}
              />
            </button>

            {openGroups.admin && (
              <div className="space-y-1 pl-1">
                {isPermitted('business-dev') && (
                  <button
                    id="nav-business-dev"
                    onClick={() => handleTabClick('business-dev')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('business-dev')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Megaphone className={`w-4 h-4 ${isTabActive('business-dev') ? 'text-purple-300' : 'text-purple-400'}`} />
                      <span>Doctor Campaigns</span>
                    </div>
                  </button>
                )}

                {isPermitted('employee-mgmt') && (
                  <button
                    id="nav-employee-mgmt"
                    onClick={() => handleTabClick('employee-mgmt')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('employee-mgmt')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Users className={`w-4 h-4 ${isTabActive('employee-mgmt') ? 'text-pink-300' : 'text-pink-400'}`} />
                      <span>Employee Control</span>
                    </div>
                  </button>
                )}

                {isPermitted('invoice-settings') && (
                  <button
                    id="nav-invoice-settings"
                    onClick={() => handleTabClick('invoice-settings')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('invoice-settings')
                        ? 'bg-white/15 border border-white/20 text-white font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <FileText className={`w-4 h-4 ${isTabActive('invoice-settings') ? 'text-emerald-300' : 'text-emerald-400'}`} />
                      <span>Invoice Settings</span>
                    </div>
                  </button>
                )}

                {isPermitted('system-reset') && (
                  <button
                    id="nav-system-reset"
                    onClick={() => handleTabClick('system-reset')}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all font-medium ${
                      isTabActive('system-reset')
                        ? 'bg-white/15 border border-rose-500/40 text-rose-200 font-semibold shadow-lg backdrop-blur-xl'
                        : 'text-slate-400 hover:text-rose-300 hover:bg-rose-500/10 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <RotateCcw className={`w-4 h-4 ${isTabActive('system-reset') ? 'text-rose-300 animate-spin-reverse' : 'text-rose-400'}`} />
                      <span>Reset & 5-Day Backup</span>
                    </div>
                    <span className="bg-rose-500/20 text-rose-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-rose-500/30">
                      Admin
                    </span>
                  </button>
                )}
              </div>
            )}
          </div>
        </nav>

        {/* Sidebar Status Pill (Storage / System Health) */}
        <div className="px-3 py-2">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-white/10 to-transparent border border-white/10 backdrop-blur-xl">
            <div className="flex justify-between items-center mb-1.5">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Cloud Sync & DB</p>
              <span className="text-[10px] font-mono text-emerald-400 font-semibold">Online</span>
            </div>
            <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden mb-1.5">
              <div className="h-full w-[78%] bg-indigo-500 rounded-full" />
            </div>
            <p className="text-[11px] text-slate-300 font-mono">100% Encrypted Local ERP</p>
          </div>
        </div>

        {/* Sidebar Footer with Switch User Button */}
        <div className="p-3 border-t border-white/10 bg-white/5 backdrop-blur-md text-[11px] flex items-center justify-between">
          {onOpenSwitchUser && (
            <button
              id="switch-user-btn"
              onClick={onOpenSwitchUser}
              className="text-indigo-300 hover:text-white flex items-center gap-1.5 font-semibold transition px-2.5 py-1.5 rounded-xl hover:bg-white/10 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Switch User</span>
            </button>
          )}
          <span className="text-slate-400 font-mono text-[10px] bg-white/5 px-2 py-0.5 rounded-lg border border-white/10 ml-auto">
            v11.0 Glass
          </span>
        </div>
      </aside>
    </>
  );
};
