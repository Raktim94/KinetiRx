import React, { useState, useEffect } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowRight,
  Check,
  CheckCircle2,
  Clock,
  Database,
  Download,
  Eye,
  EyeOff,
  FileCheck2,
  History,
  KeyRound,
  Lock,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Store,
  Trash2,
  Unlock,
  Upload,
  Users,
  X,
} from 'lucide-react';
import {
  CurrentUser,
  Distributor,
  DailyRegisterState,
  Employee,
  ExpenseRecord,
  InvoiceConfig,
  MarketingCampaign,
  Medicine,
  NeededMedOrder,
  OPDVisit,
  OrganizationOnboardingData,
  PatientRecord,
  SalesRecord,
  SystemBackupSnapshot,
  WorksheetTask,
} from '../../types';

interface SystemResetTabProps {
  currentUser?: CurrentUser;
  resetSecurityPass: string;
  onSaveResetPassword: (newPass: string) => Promise<void> | void;
  invoiceConfig: InvoiceConfig;
  medicines: Medicine[];
  salesHistory: SalesRecord[];
  dailyRegister: DailyRegisterState;
  expenses: ExpenseRecord[];
  patients: PatientRecord[];
  neededMeds: NeededMedOrder[];
  opdVisits: OPDVisit[];
  marketingCampaigns: MarketingCampaign[];
  worksheetTasks: WorksheetTask[];
  employees: Employee[];
  distributors: Distributor[];
  backupSnapshots: SystemBackupSnapshot[];
  onExecuteFactoryReset: (
    onboardingData: OrganizationOnboardingData,
    newResetPass: string
  ) => void;
  onRestoreSnapshot: (snapshot: SystemBackupSnapshot) => void;
  onCreateManualSnapshot: (label?: string) => void;
  onDeleteSnapshot: (snapshotId: string) => void;
  onRestoreFromFile: (fileContent: string) => boolean;
  onBackToEmployeeControl?: () => void;
}

export const SystemResetTab: React.FC<SystemResetTabProps> = ({
  currentUser,
  resetSecurityPass,
  onSaveResetPassword,
  invoiceConfig,
  medicines,
  salesHistory,
  dailyRegister,
  expenses,
  patients,
  neededMeds,
  opdVisits,
  marketingCampaigns,
  worksheetTasks,
  employees,
  distributors,
  backupSnapshots,
  onExecuteFactoryReset,
  onRestoreSnapshot,
  onCreateManualSnapshot,
  onDeleteSnapshot,
  onRestoreFromFile,
  onBackToEmployeeControl,
}) => {
  // Separate Reset Lock & Unlock State (default unlocked for direct authorized administrator access)
  const [isResetUnlocked, setIsResetUnlocked] = useState(true);
  const [resetPassInput, setResetPassInput] = useState('');
  const [showPassInput, setShowPassInput] = useState(false);
  const [unlockError, setUnlockError] = useState<string | null>(null);

  // Set / Change Reset Password Modal State
  const [isSetPassModalOpen, setIsSetPassModalOpen] = useState(false);
  const [currentPassInput, setCurrentPassInput] = useState('');
  const [newPassInput, setNewPassInput] = useState('');
  const [confirmNewPassInput, setConfirmNewPassInput] = useState('');
  const [showModalPass, setShowModalPass] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [modalSuccess, setModalSuccess] = useState<string | null>(null);

  // Active Sub-Tab View: 'backups' | 'reset_wipe' | 'file_transfer'
  const [activeSubTab, setActiveSubTab] = useState<'backups' | 'reset_wipe' | 'file_transfer'>('backups');

  const [confirmResetText, setConfirmResetText] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [snapshotToRestore, setSnapshotToRestore] = useState<SystemBackupSnapshot | null>(null);
  const [restorePassInput, setRestorePassInput] = useState('');
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [newSnapshotLabel, setNewSnapshotLabel] = useState('');
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Verify Reset Password to Unlock
  const handleUnlockReset = () => {
    const cleanInput = resetPassInput.trim();
    const cleanTarget = (resetSecurityPass || '1122').trim();

    if (cleanInput === cleanTarget) {
      setIsResetUnlocked(true);
      setUnlockError(null);
      setResetPassInput('');
      setStatusMessage({ type: 'success', text: '🔓 Reset Security Lock successfully UNLOCKED.' });
      setTimeout(() => setStatusMessage(null), 3500);
    } else {
      setIsResetUnlocked(false);
      setUnlockError('Incorrect Reset Password. Please enter the valid password configured for reset.');
    }
  };

  // Explicit Lock Reset Action
  const handleLockReset = () => {
    setIsResetUnlocked(false);
    setResetPassInput('');
    setUnlockError(null);
    setStatusMessage({ type: 'success', text: '🔒 Reset Security is now LOCKED.' });
    setTimeout(() => setStatusMessage(null), 3000);
  };

  // Handle Setting or Changing the Reset Password
  const handleSaveNewResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalError(null);
    setModalSuccess(null);

    const cleanCurrent = currentPassInput.trim();
    const cleanNew = newPassInput.trim();
    const cleanConfirm = confirmNewPassInput.trim();
    const activePass = (resetSecurityPass || '1122').trim();

    // Verify current password unless already unlocked
    if (!isResetUnlocked && activePass && cleanCurrent !== activePass) {
      setModalError('Current Reset Password is incorrect.');
      return;
    }

    if (!cleanNew || cleanNew.length < 2) {
      setModalError('New Reset Password must be at least 2 characters.');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setModalError('New passwords do not match. Please verify.');
      return;
    }

    try {
      await onSaveResetPassword(cleanNew);
      setModalSuccess('✅ Reset password successfully updated!');
      setCurrentPassInput('');
      setNewPassInput('');
      setConfirmNewPassInput('');
      setTimeout(() => {
        setIsSetPassModalOpen(false);
        setModalSuccess(null);
        setStatusMessage({ type: 'success', text: 'New Reset Password has been saved securely.' });
      }, 1500);
    } catch (err: any) {
      setModalError('Failed to save reset password. Please try again.');
    }
  };

  // Helper to calculate time remaining until 5-day expiration
  const getRemainingTimeText = (expiresAtIso: string) => {
    const diffMs = new Date(expiresAtIso).getTime() - new Date().getTime();
    if (diffMs <= 0) {
      return { expired: true, text: 'Expired (> 5 Days)' };
    }
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60)) / (1000 * 60));

    if (diffDays > 0) {
      return { expired: false, text: `${diffDays}d ${diffHours}h remaining` };
    }
    return { expired: false, text: `${diffHours}h ${diffMins}m remaining` };
  };

  // Handle Factory Reset Execution
  const handleExecuteReset = (e: React.FormEvent) => {
    e.preventDefault();

    if (!isResetUnlocked) {
      setStatusMessage({
        type: 'error',
        text: 'Please unlock the Reset Security Lock before executing a system reset.',
      });
      return;
    }

    if (confirmResetText.trim().toUpperCase() !== 'RESET') {
      setStatusMessage({
        type: 'error',
        text: 'Please type "RESET" in the confirmation box to confirm system reset.',
      });
      return;
    }

    const orgData: OrganizationOnboardingData = {
      storeName: invoiceConfig.storeName || invoiceConfig.name || 'M.R.S. MEDICAL & DIAGNOSTIC CENTRE',
      subtitle: invoiceConfig.subtitle || '',
      phone: invoiceConfig.phone || '',
      address: invoiceConfig.addr || '',
      gstin: invoiceConfig.gstin || invoiceConfig.gst || '',
      dlNo: invoiceConfig.dl || '',
      currency: invoiceConfig.currency || '₹',
      openingCash: 0,
      directorName: invoiceConfig.director || 'Admin (Director)',
      pharmacistName: invoiceConfig.pharmacist || '',
      welcomeNotes: invoiceConfig.welcomeNotes || '',
      adminPassword: resetSecurityPass,
    };

    onExecuteFactoryReset(orgData, resetSecurityPass);
    setConfirmResetText('');
    setStatusMessage({
      type: 'success',
      text: '🎉 System successfully reset! 5-Day backup snapshot saved. Store settings retained from Invoice Settings.',
    });
  };

  // Handle Snapshot Restore Confirmation
  const handleConfirmRestore = () => {
    if (!snapshotToRestore) return;
    const cleanInput = restorePassInput.trim();
    const cleanTarget = (resetSecurityPass || '1122').trim();

    if (cleanInput !== cleanTarget) {
      setRestoreError('Incorrect Reset Password. Valid reset password required to restore backup.');
      return;
    }

    const remaining = getRemainingTimeText(snapshotToRestore.expiresAt);
    if (remaining.expired) {
      const proceed = confirm(
        'Warning: This backup was taken more than 5 days ago. Do you still want to restore this older backup snapshot?'
      );
      if (!proceed) return;
    }

    onRestoreSnapshot(snapshotToRestore);
    setSnapshotToRestore(null);
    setRestorePassInput('');
    setRestoreError(null);
    setStatusMessage({
      type: 'success',
      text: `✅ Backup "${snapshotToRestore.label}" successfully restored!`,
    });
  };

  // Download Offline Backup JSON
  const handleDownloadJSON = (snapshot?: SystemBackupSnapshot) => {
    const dataToExport = snapshot
      ? snapshot.payload
      : {
          exportDate: new Date().toISOString(),
          medicines,
          salesHistory,
          dailyRegister,
          expenses,
          patients,
          neededMeds,
          opdVisits,
          marketingCampaigns,
          worksheetTasks,
          employees,
          invoiceConfig,
          distributors,
          resetSecurityPass,
        };

    const fileName = `pharma_care_backup_${new Date().toISOString().slice(0, 10)}.json`;
    const jsonStr = JSON.stringify(dataToExport, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setStatusMessage({ type: 'success', text: `Downloaded backup file: ${fileName}` });
  };

  // Upload Offline Backup JSON
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isResetUnlocked) {
      setStatusMessage({
        type: 'error',
        text: 'Please unlock the Reset Security Lock before restoring from a file.',
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const content = event.target?.result as string;
        const success = onRestoreFromFile(content);
        if (success) {
          setStatusMessage({
            type: 'success',
            text: `✅ File "${file.name}" restored successfully!`,
          });
        } else {
          setStatusMessage({
            type: 'error',
            text: 'Failed to restore: Invalid backup file format.',
          });
        }
      } catch (err) {
        setStatusMessage({
          type: 'error',
          text: 'Error parsing JSON file. Please ensure it is a valid backup.',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6 text-slate-100 max-w-6xl mx-auto pb-12">
      {/* 1. TOP HEADER BANNER */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-950/50 via-slate-900/80 to-purple-950/40 backdrop-blur-2xl border border-rose-500/30 shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5 flex-wrap">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <RotateCcw className="w-4 h-4" />
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight">
              System Reset & Rolling 5-Day Backup Hub
            </h3>
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Reset data, clear demo records, configure fresh organization handover, and maintain rolling 5-day safety snapshots protected by a dedicated Reset Lock.
          </p>
        </div>

        {onBackToEmployeeControl && (
          <button
            onClick={onBackToEmployeeControl}
            className="bg-white/10 hover:bg-white/20 text-white font-semibold text-xs px-4 py-2.5 rounded-2xl border border-white/20 transition flex items-center gap-2 shadow-lg cursor-pointer shrink-0"
          >
            <Users className="w-4 h-4 text-pink-400" />
            <span>Back to Employee Control</span>
          </button>
        )}
      </div>

      {/* STATUS ALERT TOAST */}
      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border flex items-center justify-between text-xs font-semibold backdrop-blur-xl transition-all shadow-xl ${
            statusMessage.type === 'success'
              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-500/20 border-rose-500/40 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-white text-xs ml-4 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* 2. DEDICATED RESET SECURITY LOCK & UNLOCK PANEL */}
      {!isResetUnlocked ? (
        <div
          id="reset-unlock-box"
          className="p-6 rounded-3xl bg-white/5 backdrop-blur-2xl border border-rose-500/30 shadow-2xl space-y-4"
        >
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Reset Security Lock</span>
                  <span className="bg-rose-500/20 text-rose-300 text-[10px] px-2 py-0.5 rounded-full font-bold border border-rose-500/30">
                    LOCKED
                  </span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Factory reset, data wipes, and snapshot restores are locked to prevent accidental loss. Enter your Reset Password to unlock.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setModalError(null);
                setModalSuccess(null);
                setCurrentPassInput('');
                setNewPassInput('');
                setConfirmNewPassInput('');
                setIsSetPassModalOpen(true);
              }}
              className="text-xs text-indigo-300 hover:text-white underline underline-offset-2 flex items-center gap-1"
            >
              <KeyRound className="w-3 h-3" />
              <span>Set / Change Reset Password</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
            <div className="relative flex-1">
              <input
                type={showPassInput ? 'text' : 'password'}
                id="input-reset-pass-unlock"
                value={resetPassInput}
                onChange={e => {
                  setResetPassInput(e.target.value);
                  setUnlockError(null);
                }}
                onKeyDown={e => e.key === 'Enter' && handleUnlockReset()}
                placeholder="Enter Reset Password"
                className="w-full pl-4 pr-10 py-2.5 bg-slate-900/80 border border-white/15 rounded-2xl text-white text-xs outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-500/20 font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassInput(!showPassInput)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                title={showPassInput ? 'Hide password' : 'Show password'}
              >
                {showPassInput ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <button
              id="btn-unlock-reset-controls"
              onClick={handleUnlockReset}
              className="bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-bold px-6 py-2.5 rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 transition cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>Unlock Reset Module</span>
            </button>
          </div>

          {unlockError && (
            <p className="text-xs text-rose-400 font-medium flex items-center gap-1.5 mt-1">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{unlockError}</span>
            </p>
          )}
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-indigo-950/40 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-emerald-200 flex items-center gap-2">
                <span>Reset Functionality is UNLOCKED</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                You can now configure fresh organization details, run factory wipes, take snapshots, or restore backups.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setModalError(null);
                setModalSuccess(null);
                setCurrentPassInput('');
                setNewPassInput('');
                setConfirmNewPassInput('');
                setIsSetPassModalOpen(true);
              }}
              className="bg-white/10 hover:bg-white/15 text-slate-200 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer border border-white/10"
            >
              <KeyRound className="w-3.5 h-3.5 text-indigo-300" />
              <span>Change Password</span>
            </button>

            <button
              onClick={handleLockReset}
              className="bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40 px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-rose-400" />
              <span>Lock Reset Now</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. NAVIGATION SUB-TABS */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-3 flex-wrap">
        <button
          id="subtab-backups"
          onClick={() => setActiveSubTab('backups')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
            activeSubTab === 'backups'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/30'
              : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border border-white/10'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>5-Day Rolling Backups & Restore</span>
          <span className="bg-white/20 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">
            {backupSnapshots.length}
          </span>
        </button>

        <button
          id="subtab-reset-wipe"
          onClick={() => setActiveSubTab('reset_wipe')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
            activeSubTab === 'reset_wipe'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30 border border-rose-400/30'
              : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border border-white/10'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>System Data Wipe & Factory Reset</span>
        </button>

        <button
          id="subtab-file-transfer"
          onClick={() => setActiveSubTab('file_transfer')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
            activeSubTab === 'file_transfer'
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30 border border-purple-400/30'
              : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border border-white/10'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Manual Snapshot & JSON Export/Import</span>
        </button>
      </div>

      {/* 4A. SUBTAB: FACTORY RESET & DATA WIPE */}
      {activeSubTab === 'reset_wipe' && (
        <div className="space-y-6">
          {/* Current System Overview Card */}
          <div className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-400" />
              <span>Current System Data Summary (Will be backed up for 5 Days before wipe)</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 text-center">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Medicine SKUs</p>
                <p className="text-base font-bold text-white font-mono mt-0.5">{medicines.length}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Sales Invoices</p>
                <p className="text-base font-bold text-emerald-400 font-mono mt-0.5">{salesHistory.length}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Patients</p>
                <p className="text-base font-bold text-teal-400 font-mono mt-0.5">{patients.length}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">OPD Records</p>
                <p className="text-base font-bold text-cyan-400 font-mono mt-0.5">{opdVisits.length}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Expenses</p>
                <p className="text-base font-bold text-orange-400 font-mono mt-0.5">{expenses.length}</p>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                <p className="text-[10px] text-slate-400">Staff Accounts</p>
                <p className="text-base font-bold text-purple-400 font-mono mt-0.5">{employees.length}</p>
              </div>
            </div>
          </div>

          {/* Clean Setup & Confirmation Card */}
          <form onSubmit={handleExecuteReset} className="space-y-6">
            <div className="p-5 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-white/10 shadow-xl space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Store & Invoice Configuration
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Your pharmacy name (<span className="text-white font-medium">{invoiceConfig.storeName || invoiceConfig.name || 'M.R.S. MEDICAL & DIAGNOSTIC CENTRE'}</span>), contact details, DL number, and GSTIN from <strong>Invoice Settings</strong> will be preserved automatically.
                  </p>
                </div>
              </div>
            </div>

            {/* Confirmation & Reset Action Box */}
            <div className="p-6 rounded-3xl bg-rose-950/40 backdrop-blur-2xl border border-rose-500/40 shadow-2xl space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-rose-200">
                    Confirm System Reset & Rolling 5-Day Safety Snapshot
                  </h4>
                  <p className="text-xs text-rose-300/80 leading-relaxed mt-0.5">
                    Clicking execute will clear all demo/current inventory items, sales invoices, expenses, patients, and OPD records. An automated full backup snapshot will be saved in your 5-day archive so you can restore it anytime if needed.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="font-semibold text-xs text-rose-200 block mb-1">
                    Type <span className="font-mono bg-rose-500/30 px-1.5 py-0.5 rounded text-white">RESET</span> to confirm:
                  </label>
                  <input
                    type="text"
                    id="input-confirm-reset"
                    value={confirmResetText}
                    onChange={e => setConfirmResetText(e.target.value)}
                    placeholder="Type RESET"
                    className="w-full p-2.5 bg-slate-950/90 border border-rose-500/50 rounded-xl text-white text-xs font-mono outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-500/30"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    id="btn-execute-factory-reset"
                    disabled={!isResetUnlocked || confirmResetText.trim().toUpperCase() !== 'RESET'}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg ${
                      isResetUnlocked && confirmResetText.trim().toUpperCase() === 'RESET'
                        ? 'bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white shadow-rose-950/50 cursor-pointer'
                        : 'bg-white/10 text-slate-500 border border-white/10 cursor-not-allowed'
                    }`}
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Execute System Reset & Save 5-Day Backup</span>
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* 4B. SUBTAB 2: 5-DAY ROLLING BACKUPS & RESTORE LIST */}
      {activeSubTab === 'backups' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-indigo-400" />
                <span>5-Day Active Backup Snapshots</span>
              </h4>
              <p className="text-xs text-slate-400">
                Snapshots created during reset or manual capture. Stored for 5 days with instant one-click restore.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newSnapshotLabel}
                onChange={e => setNewSnapshotLabel(e.target.value)}
                placeholder="Snapshot label (optional)"
                className="px-3 py-1.5 bg-slate-900/80 border border-white/15 rounded-xl text-white text-xs outline-none focus:border-indigo-400 font-mono"
              />
              <button
                id="btn-create-instant-snapshot"
                onClick={() => {
                  onCreateManualSnapshot(newSnapshotLabel.trim() || undefined);
                  setNewSnapshotLabel('');
                  setStatusMessage({ type: 'success', text: '✅ Instant backup snapshot created successfully!' });
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-950/40 transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Take Snapshot Now</span>
              </button>
            </div>
          </div>

          {backupSnapshots.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center mx-auto">
                <Database className="w-6 h-6" />
              </div>
              <h5 className="text-sm font-bold text-white">No Backup Snapshots Saved Yet</h5>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Whenever you perform a factory reset, or click "Take Snapshot Now", a full 5-day backup is created here automatically.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {backupSnapshots.map(snap => {
                const remaining = getRemainingTimeText(snap.expiresAt);
                const createdDate = new Date(snap.createdAt).toLocaleString('en-IN', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });
                const expiresDate = new Date(snap.expiresAt).toLocaleString('en-IN', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={snap.id}
                    className="p-5 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 hover:border-white/20 transition-all shadow-xl space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="text-sm font-bold text-white">{snap.label}</h5>
                          {snap.reason === 'pre_reset_auto' && (
                            <span className="bg-rose-500/20 text-rose-300 text-[10px] px-2 py-0.5 rounded-full font-semibold border border-rose-500/30">
                              Pre-Reset Auto Backup
                            </span>
                          )}
                          {snap.reason === 'manual_snapshot' && (
                            <span className="bg-indigo-500/20 text-indigo-300 text-[10px] px-2 py-0.5 rounded-full font-semibold border border-indigo-500/30">
                              Manual Snapshot
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                          <span>Captured: {createdDate}</span>
                          <span>•</span>
                          <span>Expires: {expiresDate}</span>
                        </div>
                      </div>

                      {/* Remaining Badge */}
                      <div className="flex items-center gap-2">
                        {remaining.expired ? (
                          <span className="bg-slate-800 text-slate-400 text-xs px-3 py-1 rounded-xl border border-white/10 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-slate-500" />
                            <span>Expired (&gt; 5 Days)</span>
                          </span>
                        ) : (
                          <span className="bg-emerald-500/20 text-emerald-300 text-xs px-3 py-1 rounded-xl border border-emerald-500/30 font-semibold flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Active: {remaining.text}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Snapshot Stats Bar */}
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs text-slate-300 bg-slate-900/60 p-3 rounded-2xl border border-white/10 font-mono">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Medicines:</span>
                        <span className="font-bold text-white">{snap.counts.medicines} SKUs</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Sales:</span>
                        <span className="font-bold text-emerald-400">{snap.counts.sales} Invoices</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Patients:</span>
                        <span className="font-bold text-teal-400">{snap.counts.patients} Registered</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">OPD Consults:</span>
                        <span className="font-bold text-cyan-400">{snap.counts.opdVisits} Visits</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Expenses:</span>
                        <span className="font-bold text-orange-400">{snap.counts.expenses} Records</span>
                      </div>
                    </div>

                    {/* Snapshot Actions */}
                    <div className="flex items-center justify-between pt-2 border-t border-white/10 flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleDownloadJSON(snap)}
                          className="px-3 py-1.5 bg-white/10 hover:bg-white/15 text-slate-200 rounded-xl text-xs flex items-center gap-1.5 font-medium transition cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 text-indigo-300" />
                          <span>Export JSON</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onDeleteSnapshot(snap.id)}
                          className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-1 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>

                        <button
                          id={`btn-restore-snap-${snap.id}`}
                          onClick={() => {
                            setSnapshotToRestore(snap);
                            setRestorePassInput('');
                            setRestoreError(null);
                          }}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Restore This Backup</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 4C. SUBTAB 3: MANUAL SNAPSHOT & JSON EXPORT/IMPORT */}
      {activeSubTab === 'file_transfer' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Download JSON Backup */}
          <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Download Full System Backup (.JSON)</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Save an encrypted copy of your entire database (Medicines, Sales Invoices, Expenses, Clinical OPD, Patients, Staff, and Store Settings) to your local device.
              </p>
            </div>
            <button
              id="btn-download-full-json"
              onClick={() => handleDownloadJSON()}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-950/40 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON Backup File</span>
            </button>
          </div>

          {/* Restore from JSON Backup */}
          <div className="p-6 rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/30 text-purple-400 flex items-center justify-center">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Restore From Backup File (.JSON)</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Upload a previously exported JSON backup file to completely restore your pharmacy database. Requires Reset module to be unlocked.
              </p>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".json"
              className="hidden"
            />

            <button
              id="btn-upload-json-backup"
              onClick={() => {
                if (!isResetUnlocked) {
                  setStatusMessage({
                    type: 'error',
                    text: 'Please unlock the Reset Security Lock before uploading a restore file.',
                  });
                  return;
                }
                fileInputRef.current?.click();
              }}
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-purple-950/40 transition cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Upload & Restore Backup File</span>
            </button>
          </div>
        </div>
      )}

      {/* 5. RESTORE CONFIRMATION MODAL */}
      {snapshotToRestore && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 border-b border-white/10 pb-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Restore Backup Snapshot</h4>
                <p className="text-xs text-slate-400">{snapshotToRestore.label}</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
              <p className="text-slate-300">
                You are about to restore this backup created on{' '}
                <span className="font-mono text-emerald-300">
                  {new Date(snapshotToRestore.createdAt).toLocaleString()}
                </span>
                . Current data will be replaced by the snapshot's contents.
              </p>
              <div className="font-mono text-slate-400 grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
                <span>• {snapshotToRestore.counts.medicines} Medicines</span>
                <span>• {snapshotToRestore.counts.sales} Sales Invoices</span>
                <span>• {snapshotToRestore.counts.patients} Patients</span>
                <span>• {snapshotToRestore.counts.opdVisits} OPD Consultations</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 block">
                Enter Reset Password to confirm restore:
              </label>
              <input
                type="password"
                value={restorePassInput}
                onChange={e => {
                  setRestorePassInput(e.target.value);
                  setRestoreError(null);
                }}
                placeholder="Reset Password"
                className="w-full p-2.5 bg-slate-950 border border-white/15 rounded-xl text-white text-xs font-mono outline-none focus:border-emerald-400"
              />
              {restoreError && (
                <p className="text-xs text-rose-400 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{restoreError}</span>
                </p>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  setSnapshotToRestore(null);
                  setRestorePassInput('');
                  setRestoreError(null);
                }}
                className="px-4 py-2 bg-white/10 hover:bg-white/15 text-slate-300 rounded-xl text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRestore}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Confirm & Restore</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. SET / CHANGE RESET PASSWORD MODAL */}
      {isSetPassModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-indigo-500/40 rounded-3xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">Set Reset Password</h4>
                  <p className="text-xs text-slate-400">Configure dedicated security password for system reset</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSetPassModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewResetPassword} className="space-y-4 text-xs">
              {!isResetUnlocked && (
                <div>
                  <label className="font-semibold text-slate-300 block mb-1">
                    Current Reset Password <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type={showModalPass ? 'text' : 'password'}
                    value={currentPassInput}
                    onChange={e => setCurrentPassInput(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full p-2.5 bg-slate-950 border border-white/15 rounded-xl text-white font-mono outline-none focus:border-indigo-400"
                    required
                  />
                </div>
              )}

              <div>
                <label className="font-semibold text-slate-300 block mb-1">
                  New Reset Password <span className="text-emerald-400">*</span>
                </label>
                <input
                  type={showModalPass ? 'text' : 'password'}
                  value={newPassInput}
                  onChange={e => setNewPassInput(e.target.value)}
                  placeholder="Enter new reset password"
                  className="w-full p-2.5 bg-slate-950 border border-white/15 rounded-xl text-white font-mono outline-none focus:border-indigo-400"
                  required
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">
                  Confirm New Reset Password <span className="text-emerald-400">*</span>
                </label>
                <input
                  type={showModalPass ? 'text' : 'password'}
                  value={confirmNewPassInput}
                  onChange={e => setConfirmNewPassInput(e.target.value)}
                  placeholder="Re-enter new reset password"
                  className="w-full p-2.5 bg-slate-950 border border-white/15 rounded-xl text-white font-mono outline-none focus:border-indigo-400"
                  required
                />
              </div>

              <div className="flex items-center justify-between text-slate-400">
                <button
                  type="button"
                  onClick={() => setShowModalPass(!showModalPass)}
                  className="text-[11px] hover:text-white flex items-center gap-1.5 cursor-pointer"
                >
                  {showModalPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showModalPass ? 'Hide password characters' : 'Show password characters'}</span>
                </button>
              </div>

              {modalError && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{modalError}</span>
                </div>
              )}

              {modalSuccess && (
                <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{modalSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsSetPassModalOpen(false)}
                  className="px-4 py-2 bg-white/10 hover:bg-white/15 text-slate-300 rounded-xl font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-950/40 transition cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Reset Password</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
